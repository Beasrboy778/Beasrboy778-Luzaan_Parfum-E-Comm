
import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, ShieldCheck, Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const LoginWelcomeModal: React.FC = () => {
  const { user, showWelcomeModal, setShowWelcomeModal } = useAuth();

  useEffect(() => {
    if (showWelcomeModal) {
      const timer = setTimeout(() => {
        setShowWelcomeModal(false);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [showWelcomeModal, setShowWelcomeModal]);

  if (!user) return null;

  const isAdmin = user.role === 'admin';

  return (
    <AnimatePresence>
      {showWelcomeModal && (
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          exit={{ opacity: 0 }} 
          className="fixed inset-0 z-[9999] flex items-center justify-center p-6 bg-transparent pointer-events-none"
        >
          <motion.div 
            initial={{ scale: 0.9, y: 20, opacity: 0 }} 
            animate={{ scale: 1, y: 0, opacity: 1 }} 
            exit={{ scale: 0.9, y: -20, opacity: 0 }}
            className="bg-white w-full max-w-sm rounded-[2.5rem] shadow-[0_0_100px_rgba(0,0,0,0.2)] p-10 text-center border border-stone-100 pointer-events-auto relative overflow-hidden"
          >
            {/* Animated Ritual Icon */}
            <motion.div 
              initial={{ rotate: -20, scale: 0 }} 
              animate={{ rotate: 0, scale: 1 }} 
              transition={{ type: 'spring', damping: 12 }}
              className={`w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-xl ${isAdmin ? 'bg-brand-black text-brand-gold' : 'bg-brand-crimson text-white'}`}
            >
              {isAdmin ? <ShieldCheck size={40} /> : <Sparkles size={40} />}
            </motion.div>

            <div className="space-y-4">
              <span className={`text-[10px] font-black uppercase tracking-[0.6em] block ${isAdmin ? 'text-brand-gold' : 'text-brand-crimson'}`}>
                {isAdmin ? 'Administrative Authority' : 'Private Access Granted'}
              </span>
              
              <h2 className="font-serif text-4xl text-brand-black italic leading-tight">
                Welcome Back, <br/>
                <span className="font-bold not-italic text-5xl tracking-tighter">{user.name.split(' ')[0]}</span>
              </h2>

              <p className="text-stone-400 text-sm font-serif italic max-w-[240px] mx-auto leading-relaxed">
                {isAdmin 
                  ? "The Archive core is synchronized and awaiting your command." 
                  : "Your olfactory preferences have been restored to the session."}
              </p>
            </div>

            {/* Ritual Progress Bar at bottom */}
            <div className="absolute bottom-0 left-0 w-full h-1.5 bg-stone-50">
              <motion.div 
                initial={{ width: '0%' }} 
                animate={{ width: '100%' }} 
                transition={{ duration: 3.5, ease: 'linear' }}
                className={`h-full ${isAdmin ? 'bg-brand-gold shadow-[0_0_10px_#CFA75E]' : 'bg-brand-crimson shadow-[0_0_10px_#660F1A]'}`}
              />
            </div>
            
            {/* Subtle brand mark */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 opacity-5 pointer-events-none">
                <span className="font-display text-7xl font-black">L</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
