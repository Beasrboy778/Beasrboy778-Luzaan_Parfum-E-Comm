
import React, { useState, useEffect, useRef } from 'react';
import { X, Search, ArrowRight, TrendingUp } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { PRODUCTS } from '../services/mockData';
// @ts-ignore
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useCurrency } from '../context/CurrencyContext';

export const SearchOverlay: React.FC = () => {
  const { isSearchOpen, toggleSearch } = useShop();
  const { formatPrice } = useCurrency();
  const [searchTerm, setSearchTerm] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
    if (!isSearchOpen) {
      setSearchTerm('');
    }
  }, [isSearchOpen]);

  const filteredProducts = searchTerm.length > 1 
    ? PRODUCTS.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
    : [];

  const popularSearches = ['Oud', 'Rose', 'Gift Set', 'Sandalwood'];

  return (
    <AnimatePresence>
      {isSearchOpen && (
        // FIX: Suppress incorrect TypeScript error for valid framer-motion props.
        // @ts-ignore
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-brand-cream/98 backdrop-blur-xl z-[80] flex flex-col"
        >
          {/* Header */}
          <div className="flex justify-end p-6">
            <button 
              onClick={toggleSearch} 
              className="p-2 text-brand-black hover:text-brand-crimson transition-colors rounded-full hover:bg-stone-100"
            >
              <X size={32} strokeWidth={1} />
            </button>
          </div>

          {/* Search Input */}
          <div className="w-full max-w-4xl mx-auto px-6 mt-12">
            <div className="relative border-b-2 border-stone-200 focus-within:border-brand-black transition-colors">
              <input
                ref={inputRef}
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search for fragrances..."
                className="w-full bg-transparent py-4 text-3xl md:text-5xl font-serif text-brand-black placeholder-stone-300 outline-none"
              />
              <button className="absolute right-0 top-1/2 -translate-y-1/2 text-brand-black">
                <Search size={32} strokeWidth={1} />
              </button>
            </div>
          </div>

          {/* Results Area */}
          <div className="flex-1 w-full max-w-4xl mx-auto px-6 mt-12 overflow-y-auto pb-12 custom-scrollbar">
            
            {/* Empty State / Popular Searches */}
            {searchTerm.length === 0 && (
              <div className="space-y-8">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-widest text-stone-400 mb-4 flex items-center">
                    <TrendingUp size={14} className="mr-2" /> Trending Now
                  </h3>
                  <div className="flex flex-wrap gap-3">
                    {popularSearches.map(term => (
                      <button 
                        key={term}
                        onClick={() => setSearchTerm(term)}
                        className="px-4 py-2 bg-white border border-stone-200 text-stone-600 hover:border-brand-black hover:text-brand-black transition-colors rounded-sm text-sm"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Results Grid */}
            {searchTerm.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {filteredProducts.length > 0 ? (
                  filteredProducts.map(product => (
                    <Link 
                      key={product.id} 
                      to={`/product/${product.id}`}
                      onClick={toggleSearch}
                      className="flex gap-4 group"
                    >
                      {/* THUMBNAIL FIX: Square white box, object-contain */}
                      <div className="w-20 h-20 bg-white border border-stone-200 overflow-hidden flex-shrink-0 p-1 flex items-center justify-center rounded-lg">
                        <img src={product.images[0]} alt={product.name} className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500" />
                      </div>
                      <div className="flex flex-col justify-center">
                        <h4 className="font-serif text-xl text-brand-black group-hover:text-brand-crimson transition-colors">{product.name}</h4>
                        <p className="text-sm text-stone-500">{product.category}</p>
                        <p className="text-sm font-medium mt-1">{formatPrice(product.price)}</p>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="col-span-2 text-center py-12">
                    <p className="text-lg text-stone-500 font-serif">No fragrances found matching "{searchTerm}"</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
