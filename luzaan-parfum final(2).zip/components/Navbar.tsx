
import React, { useState, useEffect } from 'react';
// @ts-ignore
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { ShoppingBag, Search, User, Heart, ChevronDown, Menu, X, Globe, Sparkles, MoreVertical, LayoutDashboard } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import { motion, AnimatePresence } from 'framer-motion';
import { AuraLoader } from './AuraLoader';
import { Logo } from './Logo';

const NavIcon = ({ icon: Icon, onClick, badge, size = 18, className = "" }: any) => (
  <button 
    onClick={onClick}
    className={`p-2.5 text-brand-black/70 hover:text-brand-black transition-all relative flex items-center justify-center group ${className}`}
  >
    <Icon size={size} strokeWidth={1.2} className="group-hover:scale-110 transition-transform" />
    {badge > 0 && (
      <span className="absolute top-1.5 right-1.5 bg-brand-crimson text-white text-[7px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-bold border border-white shadow-sm">
        {badge}
      </span>
    )}
  </button>
);

const AnnouncementBar = () => {
    const { designSettings } = useShop();
    if (!designSettings.announcementBarActive || !designSettings.announcementBarText) return null;

    return (
        <div className="bg-brand-black text-white text-[9px] font-black uppercase tracking-[0.2em] py-2.5 text-center relative z-[110] border-b border-white/10">
            <Link to={designSettings.announcementBarLink || '/shop'} className="hover:text-brand-gold transition-colors">
                {designSettings.announcementBarText}
            </Link>
        </div>
    );
};

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLocationOpen, setIsLocationOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isChangingCountry, setIsChangingCountry] = useState(false);
  
  const { cartCount, toggleCart, toggleSearch, isCartOpen, designSettings, storeSettings } = useShop();
  const { isAuthenticated, user } = useAuth();
  const { country, setCountry } = useCurrency();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => { document.body.style.overflow = 'unset'; };
  }, [isMobileMenuOpen]);

  const handleCountrySelect = (c: any) => {
    if (c === country) {
      setIsLocationOpen(false);
      setIsMobileMenuOpen(false);
      return;
    }
    setIsChangingCountry(true);
    setCountry(c);
    setIsLocationOpen(false);
    setIsMobileMenuOpen(false);
    setTimeout(() => setIsChangingCountry(false), 1200);
  };

  const hasAnnouncement = designSettings.announcementBarActive;
  const topOffset = hasAnnouncement ? 'top-[35px]' : 'top-0'; 
  const navHeight = isScrolled ? 'h-20' : 'h-24';
  const bgClasses = isScrolled ? "glass-nav shadow-sm" : "bg-transparent";
  const countries = ['United States', 'United Kingdom', 'Europe', 'India', 'Canada', 'Australia'];

  return (
    <>
      <AnimatePresence>
        {isChangingCountry && <AuraLoader fullScreen text={`Synchronizing ${country} Archive...`} />}
      </AnimatePresence>

      <AnnouncementBar />

      <nav className={`fixed left-0 right-0 z-[100] transition-all duration-700 ease-in-out ${bgClasses} ${navHeight} ${isScrolled ? 'top-0' : topOffset} ${isCartOpen ? 'opacity-0 pointer-events-none -translate-y-full' : 'opacity-100 translate-y-0'}`}>
        <div className="max-w-ultra mx-auto px-6 lg:px-12 h-full flex items-center justify-between">
          
          <div className="flex items-center gap-12">
            <Logo size={isScrolled ? "text-xl" : "text-2xl"} />
            
            <div className="hidden xl:flex items-center space-x-10">
              <Link to="/shop" className="text-[9px] font-black uppercase tracking-[0.3em] text-brand-black/50 hover:text-brand-black transition-colors relative group">
                Collection
                <span className="absolute -bottom-1 left-0 w-0 h-px bg-brand-black transition-all group-hover:w-full" />
              </Link>
              <Link to="/discovery" className="text-[9px] font-black uppercase tracking-[0.3em] text-brand-black/50 hover:text-brand-black transition-colors flex items-center gap-2 group">
                <Sparkles size={10} className="text-brand-gold group-hover:rotate-12 transition-transform" />
                Scent Finder
              </Link>
              <Link to="/blog" className="text-[9px] font-black uppercase tracking-[0.3em] text-brand-black/50 hover:text-brand-black transition-colors relative group">
                The Journal
                <span className="absolute -bottom-1 left-0 w-0 h-px bg-brand-black transition-all group-hover:w-full" />
              </Link>
              <Link to="/about" className="text-[9px] font-black uppercase tracking-[0.3em] text-brand-black/50 hover:text-brand-black transition-colors relative group">
                Our Heritage
              </Link>
            </div>
          </div>

          <div className="flex items-center gap-2 md:gap-4">
            {/* DESKTOP COUNTRY DROPDOWN */}
            <div className="hidden lg:block relative">
                <button 
                  onClick={() => setIsLocationOpen(!isLocationOpen)}
                  className="flex items-center gap-2.5 px-4 py-2 bg-white/20 backdrop-blur-md border border-stone-200/30 hover:border-brand-black/20 rounded-full transition-all text-[8px] font-black uppercase tracking-widest text-stone-600 shadow-sm group"
                >
                    <Globe size={11} strokeWidth={1.5} className="group-hover:text-brand-crimson transition-colors" />
                    <span>{country}</span>
                    <ChevronDown size={8} className={`transition-transform duration-500 ${isLocationOpen ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                    {isLocationOpen && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10, scale: 0.95 }} 
                          animate={{ opacity: 1, y: 0, scale: 1 }} 
                          exit={{ opacity: 0, y: 10, scale: 0.95 }} 
                          className="absolute top-full right-0 mt-3 w-48 bg-white/90 backdrop-blur-2xl border border-stone-100 rounded-2xl shadow-xl p-1.5 z-50 overflow-hidden"
                        >
                            {countries.map((c) => (
                                <button 
                                  key={c} 
                                  onClick={() => handleCountrySelect(c)} 
                                  className={`w-full text-left px-4 py-3 rounded-xl text-[8px] font-black uppercase tracking-widest transition-all ${country === c ? 'bg-brand-black text-white' : 'hover:bg-stone-50 text-stone-400 hover:text-brand-black'}`}
                                >
                                    {c}
                                </button>
                            ))}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            <div className="flex items-center gap-0.5 bg-white/20 backdrop-blur-md rounded-full p-1 border border-white/30 shadow-sm">
              {/* ALWAYS VISIBLE ADMIN BUTTON FOR ADMINS */}
              {user?.role === 'admin' && (
                <Link to="/admin">
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 lg:px-4 lg:py-2 flex items-center gap-2 bg-brand-crimson text-white rounded-full shadow-lg"
                  >
                    <LayoutDashboard size={14} />
                    <span className="hidden lg:block text-[8px] font-black uppercase tracking-widest">Admin</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  </motion.div>
                </Link>
              )}

              <NavIcon icon={Search} onClick={toggleSearch} />
              <Link to="/wishlist" className="hidden sm:block"><NavIcon icon={Heart} /></Link>
              <NavIcon icon={User} onClick={() => isAuthenticated ? navigate('/account') : navigate('/login')} />
              <div className="h-4 w-px bg-stone-200/30 mx-1 hidden sm:block" />
              <NavIcon icon={ShoppingBag} onClick={toggleCart} badge={cartCount} />
            </div>
            
            <motion.button 
              whileTap={{ scale: 0.9 }}
              className="xl:hidden p-2.5 text-brand-black ml-1 bg-white/40 backdrop-blur-md rounded-full transition-all shadow-sm border border-white/50 cursor-pointer" 
              onClick={() => setIsMobileMenuOpen(true)}
              aria-label="Open Navigation"
            >
              <MoreVertical size={18} strokeWidth={1.5} />
            </motion.button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            key="mobile-menu-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileMenuOpen(false)}
            className="fixed inset-0 bg-brand-black/60 backdrop-blur-sm z-[2900] xl:hidden"
          />
        )}
        
        {isMobileMenuOpen && (
          <motion.div 
            key="mobile-menu-sidebar"
            initial={{ x: '100%' }} 
            animate={{ x: 0 }} 
            exit={{ x: '100%' }} 
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-y-0 right-0 w-[85vw] max-w-sm bg-[#F9F6F2] backdrop-blur-3xl shadow-[-20px_0_80px_rgba(0,0,0,0.2)] z-[3000] p-8 flex flex-col gap-8 xl:hidden border-l border-white/50 overflow-y-auto"
          >
            <div className="flex justify-between items-center mb-6 shrink-0">
              <Logo size="text-xl" />
              <button 
                onClick={() => setIsMobileMenuOpen(false)} 
                className="p-3 bg-white/50 rounded-full text-stone-400 hover:text-brand-black transition-all border border-white cursor-pointer hover:bg-white relative z-50"
                aria-label="Close Menu"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="space-y-4">
              {user?.role === 'admin' && (
                <Link 
                  to="/admin" 
                  onClick={() => setIsMobileMenuOpen(false)} 
                  className="flex items-center justify-between p-5 bg-brand-black text-brand-gold rounded-2xl shadow-xl group border border-white/10 mb-6"
                >
                  <div className="flex items-center gap-3">
                    <LayoutDashboard size={18} />
                    <span className="text-xs font-black uppercase tracking-[0.3em]">Management Portal</span>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-brand-gold animate-pulse" />
                </Link>
              )}

              <Link to="/shop" onClick={() => setIsMobileMenuOpen(false)} className="block p-4 bg-white/50 rounded-xl text-[10px] font-black uppercase tracking-[0.4em] hover:text-brand-crimson transition-all border border-white/40">Collection</Link>
              <Link to="/discovery" onClick={() => setIsMobileMenuOpen(false)} className="block p-4 bg-white/50 rounded-xl text-[10px] font-black uppercase tracking-[0.4em] text-brand-gold hover:text-brand-crimson transition-all border border-white/40">Scent Finder</Link>
              <Link to="/blog" onClick={() => setIsMobileMenuOpen(false)} className="block p-4 bg-white/50 rounded-xl text-[10px] font-black uppercase tracking-[0.4em] hover:text-brand-crimson transition-all border border-white/40">Stories</Link>
              <Link to="/about" onClick={() => setIsMobileMenuOpen(false)} className="block p-4 bg-white/50 rounded-xl text-[10px] font-black uppercase tracking-[0.4em] hover:text-brand-crimson transition-all border border-white/40">Heritage</Link>
            </div>

            <div className="mt-4 pt-6 border-t border-brand-black/5">
              <p className="text-[8px] font-black uppercase tracking-[0.4em] text-stone-400 mb-4 flex items-center gap-2">
                <Globe size={10} /> Jurisdiction
              </p>
              <div className="grid grid-cols-2 gap-2">
                {countries.map((c) => (
                  <button 
                    key={c} 
                    onClick={() => handleCountrySelect(c)} 
                    className={`text-center px-3 py-3 rounded-xl text-[8px] font-black uppercase tracking-widest transition-all ${country === c ? 'bg-brand-black text-white shadow-md' : 'bg-white border border-white/50 text-stone-400 hover:bg-white hover:text-brand-black'}`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-auto pt-6 border-t border-brand-black/5 shrink-0 pb-safe">
                <Link to={isAuthenticated ? "/account" : "/login"} onClick={() => setIsMobileMenuOpen(false)} className="block w-full bg-brand-black text-white text-center py-5 rounded-[1.5rem] text-[10px] font-black uppercase tracking-[0.4em] shadow-xl active:scale-95 transition-all">
                  {isAuthenticated ? "My Archive" : "Member Login"}
                </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
