
import React, { useState, useEffect } from 'react';
import { Mail, X, CheckCircle, Copy, ArrowRight, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
// @ts-ignore
import { useNavigate } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { useAuth } from '../context/AuthContext';

export const NewsletterModal: React.FC = () => {
  const { siteContent } = useShop();
  const { user, updateUser } = useAuth();
  
  // Safeguard against undefined siteContent
  const newsletter = siteContent?.newsletter;
  
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!newsletter || !newsletter.enabled) return;

    const hasSeenModal = localStorage.getItem('aura_newsletter_seen');
    const isUserSubscribed = user?.isSubscribed;

    // Show after 5 seconds for new, unsubscribed visitors
    if (!hasSeenModal && !isUserSubscribed) {
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [newsletter?.enabled, user]);

  useEffect(() => {
      if (user?.email) setEmail(user.email);
  }, [user]);

  const handleClose = () => {
    setIsOpen(false);
    localStorage.setItem('aura_newsletter_seen', 'true');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (user) {
        updateUser({ isSubscribed: true });
    }
    setSubmitted(true);
  };

  const handleCopyCode = () => {
      if (!newsletter) return;
      navigator.clipboard.writeText(newsletter.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
  };

  if (!newsletter) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[3000] flex items-center justify-center p-4">
            <motion.div 
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onClick={handleClose} className="absolute inset-0 bg-brand-black/60 backdrop-blur-md"
            />
            
            <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative bg-[#F9F6F2] w-full max-w-xl rounded-[2.5rem] shadow-[0_40px_100px_rgba(0,0,0,0.4)] overflow-hidden flex flex-col md:flex-row border border-white/20"
            >
                {/* MOVED: Close Button - Positioned absolute to the card, ensuring visibility over image or content */}
                <button 
                  onClick={handleClose} 
                  className="absolute top-5 right-5 z-50 p-2 bg-white/20 backdrop-blur-md rounded-full text-stone-500 hover:text-brand-black hover:bg-white transition-all hover:rotate-90 border border-white/20 shadow-sm cursor-pointer"
                  aria-label="Close"
                >
                    <X size={20} strokeWidth={2} />
                </button>

                {/* Visual Asset Side - Smaller ratio for compact feel */}
                <div className="relative w-full md:w-[40%] h-48 md:h-auto bg-stone-100 overflow-hidden">
                    <motion.img 
                      initial={{ scale: 1.1 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 1.5 }}
                      src={newsletter.image} 
                      alt="Aura Fragrance" 
                      className="w-full h-full object-cover" 
                    />
                    <div className="absolute inset-0 bg-brand-black/5" />
                </div>
                
                {/* Content Side */}
                <div className="flex-1 p-6 md:p-10 relative flex flex-col justify-center">
                    
                    {submitted ? (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-4">
                            <div className="w-12 h-12 bg-brand-black text-brand-gold rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                                <Sparkles size={20} />
                            </div>
                            <h3 className="font-serif text-2xl text-brand-black mb-1">Welcome</h3>
                            <p className="text-stone-500 text-[8px] font-black uppercase tracking-[0.3em] mb-6">
                                Your private access code is verified.
                            </p>
                            
                            <div className="w-full bg-white border border-stone-200 p-4 rounded-xl mb-6 relative group">
                                <span className="text-[8px] font-black uppercase text-stone-400 tracking-[0.4em] block mb-1">Checkout Honorarium</span>
                                <span className="text-2xl font-mono font-bold tracking-[0.3em] text-brand-black">{newsletter.code}</span>
                                <button 
                                    onClick={handleCopyCode}
                                    className="absolute top-3 right-3 text-stone-300 hover:text-brand-black transition-colors"
                                >
                                    {copied ? <CheckCircle className="text-green-500" size={16} /> : <Copy size={16} />}
                                </button>
                            </div>

                            <button 
                                onClick={() => { handleClose(); navigate('/shop'); }}
                                className="w-full bg-brand-black text-white py-3.5 rounded-lg text-[9px] font-black uppercase tracking-[0.4em] shadow-lg hover:bg-brand-crimson transition-all"
                            >
                                Enter Library
                            </button>
                        </motion.div>
                    ) : (
                        <div className="animate-fade-in pt-4 md:pt-0">
                            <span className="text-brand-crimson font-black text-[9px] uppercase tracking-[0.4em] mb-3 block">
                              {newsletter.offerText}
                            </span>
                            <h2 className="font-serif text-3xl md:text-4xl text-brand-black mb-4 italic leading-tight">
                              {newsletter.title}
                            </h2>
                            <p className="text-stone-500 text-xs leading-relaxed mb-8 font-light italic opacity-80">
                                {newsletter.subtitle}
                            </p>
                            
                            <form onSubmit={handleSubmit} className="space-y-3">
                                <div className="relative group">
                                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-300 group-focus-within:text-brand-black transition-colors" size={16} />
                                    <input 
                                        type="email" 
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        placeholder="Email Address" 
                                        className="w-full bg-white border border-stone-200 pl-10 pr-4 py-3 text-sm outline-none focus:border-brand-black text-brand-black transition-all rounded-lg shadow-sm"
                                        required
                                        disabled={!!user}
                                    />
                                </div>
                                <button 
                                    type="submit" 
                                    className="w-full bg-brand-black text-white py-3.5 font-black uppercase tracking-[0.4em] text-[9px] hover:bg-brand-charcoal transition-all rounded-lg shadow-lg active:scale-95"
                                >
                                    {newsletter.buttonText}
                                </button>
                            </form>
                            <p className="text-[7px] text-stone-400 text-center mt-6 uppercase font-bold tracking-[0.3em]">
                                Secure & Private • Unsubscribe Anytime
                            </p>
                        </div>
                    )}
                </div>
            </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
