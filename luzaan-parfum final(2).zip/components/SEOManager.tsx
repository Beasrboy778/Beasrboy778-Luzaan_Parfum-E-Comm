
import React, { useEffect } from 'react';
import { useShop } from '../context/ShopContext';
// @ts-ignore
import { useLocation } from 'react-router-dom';
import { Product } from '../types';

export const SEOManager: React.FC = () => {
  const { seoSettings, products, blogPosts, storeSettings, designSettings } = useShop();
  const location = useLocation();

  useEffect(() => {
    const path = location.pathname;
    const storeName = storeSettings.storeName || 'Luzaan Parfum';
    const baseUrl = 'https://luzaan.com'; // In prod, env var
    const currentUrl = `${baseUrl}${path}`;

    let title = seoSettings.metaTitle;
    let description = seoSettings.metaDescription;
    let image = seoSettings.ogImage;
    let keywords = seoSettings.keywords.join(', ');
    let canonical = currentUrl;
    let noIndex = false;
    let schema: any = null;

    // --- Dynamic Content Logic ---
    if (path.startsWith('/product/')) {
        const productId = path.split('/').pop();
        const product = products.find(p => p.id === productId);
        if (product) {
            title = product.seo?.metaTitle || `${product.name} - ${product.tagline} | ${storeName}`;
            description = product.seo?.metaDescription || product.description.substring(0, 160);
            if (product.seo?.keywords) keywords = product.seo.keywords.join(', ');
            if (product.images.length > 0) image = product.images[0];
            if (product.seo?.canonicalUrl) canonical = product.seo.canonicalUrl;
            if (product.seo?.noIndex) noIndex = true;

            const productSchema = {
                "@context": "https://schema.org/",
                "@type": "Product",
                "name": product.name,
                "image": product.images,
                "description": product.description,
                "brand": { "@type": "Brand", "name": storeName },
                "offers": {
                    "@type": "Offer",
                    "url": currentUrl,
                    "priceCurrency": storeSettings.currency,
                    "price": product.price,
                    "availability": product.stock && product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock"
                }
            };
            // Add FAQ Schema for Product
            let faqSchema = null;
            if (product.seo?.faqs && product.seo.faqs.length > 0) {
                faqSchema = {
                    "@context": "https://schema.org",
                    "@type": "FAQPage",
                    "mainEntity": product.seo.faqs.map(f => ({
                        "@type": "Question", "name": f.question, "acceptedAnswer": { "@type": "Answer", "text": f.answer }
                    }))
                };
            }
            schema = { "@context": "https://schema.org", "@graph": [productSchema, faqSchema].filter(Boolean) };
        }
    } else if (path.startsWith('/blog/') && path.length > 6) { 
        const blogId = path.split('/').pop();
        const post = blogPosts.find(p => p.id === blogId);
        if (post) {
            title = `${post.title} | ${storeName} Journal`;
            description = post.excerpt;
            image = post.image;
            schema = {
                "@context": "https://schema.org",
                "@type": "BlogPosting",
                "headline": post.title,
                "image": [post.image],
                "datePublished": new Date(post.date).toISOString(),
                "author": { "@type": "Organization", "name": storeName }
            };
        }
    }

    // --- DOM Updates ---
    document.title = title;

    const updateMeta = (name: string, content: string, attr = 'name') => {
        let element = document.querySelector(`meta[${attr}="${name}"]`);
        if (!element) {
            element = document.createElement('meta');
            element.setAttribute(attr, name);
            document.head.appendChild(element);
        }
        element.setAttribute('content', content);
    };

    updateMeta('description', description);
    updateMeta('keywords', keywords);
    updateMeta('robots', noIndex ? 'noindex, nofollow' : 'index, follow');
    
    // Canonical
    let linkCanonical = document.querySelector("link[rel='canonical']") as HTMLLinkElement;
    if (!linkCanonical) {
        linkCanonical = document.createElement('link');
        linkCanonical.rel = 'canonical';
        document.head.appendChild(linkCanonical);
    }
    linkCanonical.href = canonical;

    // Social
    updateMeta('og:title', title, 'property');
    updateMeta('og:description', description, 'property');
    updateMeta('og:image', image, 'property');
    updateMeta('twitter:title', title);
    
    // --- CUSTOM TAGS INJECTION ---
    seoSettings.customMetaTags?.forEach(tag => {
        updateMeta(tag.name, tag.content);
    });

    // --- SCHEMA INJECTION (AEO) ---
    let script = document.querySelector('#ld-json') as HTMLScriptElement;
    if (!script) {
        script = document.createElement('script');
        script.id = 'ld-json';
        script.type = 'application/ld+json';
        document.head.appendChild(script);
    }

    // Enhanced Organization Schema for AEO
    const organizationSchema = {
        "@type": "Organization",
        "name": storeName,
        "alternateName": seoSettings.aeoSettings?.brandAlternateNames || [],
        "url": baseUrl,
        "logo": designSettings.siteLogo || `${baseUrl}/logo.png`,
        "founder": { "@type": "Person", "name": seoSettings.aeoSettings?.founderName || "The Alchemist" },
        "foundingDate": seoSettings.aeoSettings?.foundingDate || "2003",
        "areaServed": seoSettings.aeoSettings?.areaServed || "Global",
        "knowsAbout": seoSettings.aeoSettings?.knowsAbout || ["Perfume", "Oud"],
        "contactPoint": {
            "@type": "ContactPoint",
            "telephone": storeSettings.contactDetails.phone,
            "contactType": "Customer Service",
            "areaServed": seoSettings.aeoSettings?.areaServed || "Global"
        },
        "sameAs": [
            storeSettings.socialLinks.instagram,
            storeSettings.socialLinks.facebook,
            storeSettings.socialLinks.twitter
        ].filter(Boolean)
    };

    const breadcrumbSchema = {
        "@type": "BreadcrumbList",
        "itemListElement": path.split('/').filter(Boolean).map((segment, index) => ({
            "@type": "ListItem",
            "position": index + 1,
            "name": segment.charAt(0).toUpperCase() + segment.slice(1),
            "item": `${baseUrl}/${segment}`
        }))
    };

    const finalSchema = schema ? {
        "@context": "https://schema.org",
        "@graph": [organizationSchema, breadcrumbSchema, ...(schema['@graph'] ? schema['@graph'] : [schema])]
    } : {
        "@context": "https://schema.org",
        "@graph": [organizationSchema, breadcrumbSchema]
    };

    script.text = JSON.stringify(finalSchema);

  }, [location, seoSettings, products, blogPosts, storeSettings, designSettings]);

  return null;
};
