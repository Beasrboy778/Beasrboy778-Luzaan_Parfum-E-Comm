
import React from 'react';
// @ts-ignore
import { Link } from 'react-router-dom';
import { useShop } from '../context/ShopContext';

interface LogoProps {
  className?: string;
  size?: string;
  color?: string;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'text-3xl', color = 'text-brand-black' }) => {
  const { designSettings, storeSettings } = useShop();
  
  if (designSettings.siteLogo) {
      return (
        <Link to="/" className={`block hover:opacity-80 transition-opacity ${className}`}>
            <img src={designSettings.siteLogo} alt={storeSettings.storeName} className="h-10 w-auto object-contain" />
        </Link>
      );
  }

  return (
    <Link to="/" className={`group block hover:opacity-90 transition-opacity ${className}`}>
      <div className={`flex flex-col items-center leading-none ${color}`}>
        {/* LUZAAN: Roman High-Contrast Serif (Cinzel Decorative), No Spacing */}
        <span className={`font-display font-bold ${size} tracking-tighter -mb-1`}>
          LUZAAN
        </span>
        {/* PARFUM: Geometric Sans (Jost/Glacial), Spaced out */}
        <span className="font-glacial font-medium text-[0.35em] tracking-[0.3em] mt-1.5 opacity-80 group-hover:text-brand-crimson transition-colors uppercase">
          PARFUM
        </span>
      </div>
    </Link>
  );
};
