import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check } from 'lucide-react';

interface ToastProps {
  message: string;
  onClose: () => void;
  duration?: number;
}

export const Toast: React.FC<ToastProps> = ({ message, onClose, duration = 3500 }) => {
  useEffect(() => {
    if (message) {
      const timer = setTimeout(onClose, duration);
      return () => clearTimeout(timer);
    }
  }, [message, duration, onClose]);

  return (
    <AnimatePresence>
      {message && (
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 15, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 300, damping: 25 }}
          className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[200] flex items-center gap-4 bg-brand-black/95 backdrop-blur-xl text-brand-cream px-6 py-3 rounded-full shadow-[0_10px_30px_-10px_rgba(0,0,0,0.3)] border border-white/10 min-w-[200px] justify-center"
        >
          <div className="w-4 h-4 rounded-full bg-brand-gold flex items-center justify-center shrink-0 text-brand-black shadow-[0_0_10px_rgba(197,160,89,0.4)]">
            <Check size={10} strokeWidth={3} />
          </div>
          <span className="text-[9px] font-black uppercase tracking-[0.2em]">{message}</span>
        </motion.div>
      )}
    </AnimatePresence>
  );
};