
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Droplet, ImageOff } from 'lucide-react';

interface ImageWithFallbackProps {
  src?: string;
  alt: string;
  className?: string;
  containerClassName?: string;
  style?: React.CSSProperties;
  scale?: number;
  transformOrigin?: string;
}

export const ImageWithFallback: React.FC<ImageWithFallbackProps> = ({ 
  src, 
  alt, 
  className = "", 
  containerClassName = "",
  style,
  scale = 1,
  transformOrigin = "50% 50%"
}) => {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  // Generate a consistent gradient based on the alt text (product name)
  const getGradient = (text: string) => {
    const colors = [
      'from-stone-200 to-stone-300',
      'from-brand-paper to-stone-200',
      'from-brand-cream to-brand-paper',
      'from-stone-100 to-white'
    ];
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = text.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  const isPlaceholder = !src || error;

  return (
    <div className={`relative flex items-center justify-center overflow-hidden ${containerClassName}`}>
      <AnimatePresence>
        {loading && !error && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-brand-paper/20 animate-pulse flex items-center justify-center"
          >
            <div className="w-8 h-8 rounded-full border-2 border-brand-black/5 border-t-brand-gold animate-spin" />
          </motion.div>
        )}
      </AnimatePresence>

      {isPlaceholder ? (
        <div className={`w-full h-full flex flex-col items-center justify-center bg-gradient-to-br ${getGradient(alt)} p-12 transition-all duration-700`}>
          <div className="relative">
             <motion.div 
               animate={{ y: [0, -10, 0], opacity: [0.3, 0.6, 0.3] }}
               transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
               className="text-brand-black/10"
             >
                <Droplet size={120} strokeWidth={0.5} />
             </motion.div>
             <div className="absolute inset-0 flex items-center justify-center opacity-20">
                <ImageOff size={24} className="text-brand-black" />
             </div>
          </div>
          <p className="mt-4 text-[8px] font-black uppercase tracking-[0.4em] text-stone-400 text-center px-4 leading-relaxed">
            Visual record being curated for {alt}
          </p>
        </div>
      ) : (
        <motion.img
          initial={{ opacity: 0, scale: loading ? 1.05 : scale }}
          animate={{ 
            opacity: loading ? 0 : 1, 
            scale: loading ? 1.05 : scale,
            transformOrigin: transformOrigin
          }}
          transition={{ 
            duration: loading ? 0.8 : 0.4, 
            ease: "easeOut" 
          }}
          src={src}
          alt={alt}
          style={{
            ...style,
            imageRendering: 'auto',
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden'
          }}
          className={`${className} ${loading ? 'invisible' : 'visible'}`}
          onLoad={() => setLoading(false)}
          onError={() => {
            setError(true);
            setLoading(false);
          }}
        />
      )}
    </div>
  );
};
