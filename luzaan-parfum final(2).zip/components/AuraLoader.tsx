
import React from 'react';
import { motion } from 'framer-motion';
import { useShop } from '../context/ShopContext';

interface AuraLoaderProps {
  fullScreen?: boolean;
  text?: string;
}

export const AuraLoader: React.FC<AuraLoaderProps> = ({ fullScreen = true, text }) => {
  const { storeSettings } = useShop();
  
  const containerClasses = fullScreen 
    ? "fixed inset-0 z-[300] bg-[#F5F2EF] flex flex-col items-center justify-center overflow-hidden"
    : "relative w-full py-20 flex flex-col items-center justify-center bg-transparent overflow-hidden";

  return (
    <div className={containerClasses}>
       {/* Ambient Glow Background */}
       <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <motion.div 
             animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.5, 0.3] }}
             transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
             className="w-[600px] h-[600px] bg-gradient-radial from-brand-gold/20 via-transparent to-transparent rounded-full blur-[80px]"
          />
       </div>

       <div className="relative z-10 flex flex-col items-center">
          {/* Main Spinner */}
          <div className="relative w-24 h-24 flex items-center justify-center">
             
             {/* Rotating Outer Ring */}
             <motion.div 
               animate={{ rotate: 360 }}
               transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
               className="absolute inset-0 rounded-full border border-brand-black/5 border-t-brand-black/20"
             />
             
             {/* Counter-Rotating Inner Gold Ring */}
             <motion.div 
               animate={{ rotate: -360 }}
               transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
               className="absolute inset-4 rounded-full border border-brand-black/5 border-b-brand-gold"
             />

             {/* Central Breathing Brand Mark */}
             <motion.div 
                animate={{ scale: [0.9, 1.1, 0.9], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="font-display font-bold text-2xl text-brand-black tracking-tighter uppercase"
             >
                {storeSettings.storeName.charAt(0)}
             </motion.div>
          </div>

          {/* Status Label */}
          <motion.div 
             initial={{ opacity: 0, y: 10 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ delay: 0.2 }}
             className="mt-8 flex flex-col items-center gap-3"
          >
             <p className="text-[10px] font-black uppercase tracking-[0.3em] text-brand-charcoal/60 font-sans animate-pulse">
               {text || "Loading Archive"}
             </p>
          </motion.div>
       </div>
    </div>
  );
};
