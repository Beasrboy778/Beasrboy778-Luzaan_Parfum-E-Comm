
import React from 'react';
import { Minus, Plus } from 'lucide-react';

interface QuantitySelectorProps {
  quantity: number;
  onDecrease: () => void;
  onIncrease: () => void;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  max?: number;
}

export const QuantitySelector: React.FC<QuantitySelectorProps> = ({ 
  quantity, 
  onDecrease, 
  onIncrease, 
  size = 'lg',
  className = '',
  max
}) => {
  const sizeClasses = {
    sm: 'h-8 w-24',
    md: 'h-10 w-28',
    lg: 'h-14 w-36'
  };

  const iconSizes = {
    sm: 12,
    md: 14,
    lg: 16
  };

  // If max is provided, check if we reached it
  const isMaxReached = max !== undefined && quantity >= max;

  return (
    <div className={`inline-flex items-center border border-stone-300 rounded-full bg-transparent shrink-0 justify-between px-1 ${sizeClasses[size]} ${className}`}>
      <button 
        onClick={onDecrease}
        className="h-full w-10 text-stone-500 hover:text-brand-black flex items-center justify-center rounded-l-full hover:bg-stone-50 transition-colors focus:outline-none disabled:opacity-30"
        type="button"
        aria-label="Decrease quantity"
        disabled={quantity <= 1}
      >
        <Minus size={iconSizes[size]} />
      </button>
      <span className={`font-medium text-brand-black ${size === 'lg' ? 'text-lg' : 'text-sm'}`}>{quantity}</span>
      <button 
        onClick={onIncrease}
        className={`h-full w-10 flex items-center justify-center rounded-r-full transition-colors focus:outline-none ${isMaxReached ? 'text-stone-300 cursor-not-allowed' : 'text-stone-500 hover:text-brand-black hover:bg-stone-50'}`}
        type="button"
        aria-label="Increase quantity"
        disabled={isMaxReached}
      >
        <Plus size={iconSizes[size]} />
      </button>
    </div>
  );
};
