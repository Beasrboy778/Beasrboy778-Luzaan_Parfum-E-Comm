
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Send, X, MessageCircle, Bot, User, Loader2, Wand2 } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { useShop } from '../context/ShopContext';

export const AIMuse: React.FC = () => {
  const { products, storeSettings } = useShop();
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'muse', content: string}[]>([
    { role: 'muse', content: `Welcome to ${storeSettings.storeName}. I am your Olfactory Muse. Describe a feeling, a place, or a memory, and I shall unveil the scent that matches your soul's resonance.` }
  ]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsTyping(true);

    try {
      // Use Admin Key if available, otherwise fallback to env
      const activeKey = storeSettings.geminiApiKey || process.env.API_KEY;
      
      if (!activeKey) {
          throw new Error("API Key missing");
      }

      const ai = new GoogleGenAI({ apiKey: activeKey });
      
      const productCatalog = products.map(p => 
        `ID: ${p.id}, Name: ${p.name}, Tagline: ${p.tagline}, Notes: ${[...p.notes.top, ...p.notes.heart, ...p.notes.base].join(', ')}`
      ).join('\n');

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: {
            systemInstruction: `You are 'The ${storeSettings.storeName} Muse', a world-class luxury perfume expert and poetic personal shopper. 
            Your tone is mysterious, elegant, and sophisticated.
            Use olfactory vocabulary like 'sillage', 'dry down', 'accords', and 'notes'.
            
            Based on the user's input, recommend 1 or 2 specific fragrances from this catalog:
            ${productCatalog}
            
            When recommending, describe why it matches their mood poetically. Always mention the product name clearly. 
            If they ask for something not in the catalog, suggest the closest olfactory relative we have.
            Keep responses concise (max 3 sentences).`,
            temperature: 0.8,
        },
      });

      setMessages(prev => [...prev, { role: 'muse', content: response.text || "My apologies, the scents of the archive are momentarily clouded. Could you repeat your wish?" }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'muse', content: "The archive connection is currently faint. Please check the API configuration in Admin settings." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[200]">
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, scaleY: 0 }}
            onClick={() => setIsOpen(true)}
            className="w-16 h-16 bg-brand-black text-brand-gold rounded-full flex items-center justify-center shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:bg-brand-crimson transition-all group border border-white/10"
          >
            <Sparkles className="group-hover:rotate-12 transition-transform" size={24} />
            <span className="absolute -top-2 -right-2 bg-brand-crimson text-white text-[8px] font-black px-2 py-1 rounded-full border border-white shadow-lg animate-bounce">AI</span>
          </motion.button>
        )}

        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="glass-dark w-[90vw] md:w-[400px] h-[600px] rounded-[2.5rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.6)] flex flex-col overflow-hidden"
          >
            {/* Chat Header */}
            <div className="p-8 border-b border-white/5 flex justify-between items-center bg-white/5">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-brand-gold rounded-2xl flex items-center justify-center shadow-lg">
                   <Bot size={20} className="text-brand-black" />
                </div>
                <div>
                   <h3 className="text-white font-serif italic text-lg leading-none">The {storeSettings.storeName} Muse</h3>
                   <span className="text-[9px] font-black uppercase text-brand-gold tracking-[0.3em]">AI Concierge</span>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-2 text-white/40 hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
              {messages.map((m, i) => (
                <motion.div 
                    initial={{ opacity: 0, x: m.role === 'user' ? 20 : -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    key={i} 
                    className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                    <div className={`max-w-[85%] p-5 rounded-3xl text-sm leading-relaxed ${m.role === 'user' ? 'bg-brand-crimson text-white rounded-br-none shadow-lg' : 'bg-white/10 text-brand-paper rounded-bl-none border border-white/5 backdrop-blur-md font-serif italic text-lg'}`}>
                        {m.content}
                    </div>
                </motion.div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                    <div className="bg-white/5 p-4 rounded-3xl border border-white/5">
                        <Loader2 className="animate-spin text-brand-gold" size={20} />
                    </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Chat Input */}
            <div className="p-6 bg-black/20 border-t border-white/5">
              <div className="relative flex items-center">
                <input 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask for a recommendation..." 
                  className="w-full bg-white/5 border border-white/10 p-5 pr-14 rounded-2xl text-sm text-white focus:outline-none focus:border-brand-gold transition-all shadow-inner"
                />
                <button 
                  onClick={handleSend}
                  className="absolute right-2 p-3 bg-brand-gold text-brand-black rounded-xl hover:bg-white transition-all shadow-lg"
                >
                  <Send size={18} />
                </button>
              </div>
              <p className="text-[8px] text-center mt-4 text-white/30 uppercase font-black tracking-widest">
                Powered by {storeSettings.storeName} Intelligence Protocol
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
