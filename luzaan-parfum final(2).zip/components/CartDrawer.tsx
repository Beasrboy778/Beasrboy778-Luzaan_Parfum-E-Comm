
import React, { useEffect } from 'react';
import { X, Minus, Plus, Trash2, ArrowRight, ShoppingBag, ShieldAlert } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { useAuth } from '../context/AuthContext';
// @ts-ignore
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useCurrency } from '../context/CurrencyContext';

export const CartDrawer: React.FC = () => {
  const { isCartOpen, toggleCart, cart, removeFromCart, updateQuantity, cartTotal, products } = useShop();
  const { user } = useAuth();
  const { formatPrice } = useCurrency();

  // Handle body scroll lock when cart is open
  useEffect(() => {
    if (isCartOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => { document.body.style.overflow = 'unset'; };
  }, [isCartOpen]);

  const handleUpdateQuantity = (item: any, newQuantity: number) => {
      if (newQuantity < 1) {
          removeFromCart(item.cartItemId);
          return;
      }
      
      const sourceProduct = products.find(p => p.id === item.id);
      const maxStock = sourceProduct ? (sourceProduct.stock || 0) : 100;

      if (newQuantity <= maxStock) {
          updateQuantity(item.cartItemId, newQuantity);
      }
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleCart}
            className="fixed inset-0 bg-brand-black/70 z-[140]"
          />
          
          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 250 }}
            className="fixed top-0 right-0 h-full w-full max-w-lg bg-brand-cream shadow-[-40px_0_100px_rgba(0,0,0,0.4)] z-[150] flex flex-col border-l border-stone-200"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-8 md:p-10 border-b border-brand-black/[0.05] bg-white">
              <div>
                <h2 className="text-3xl font-serif font-bold text-brand-black italic">Your Bag</h2>
                <p className="text-[9px] font-black uppercase tracking-[0.4em] text-brand-gold mt-1">Order Review</p>
              </div>
              <button onClick={toggleCart} className="p-4 rounded-full bg-stone-50 text-brand-black/40 hover:text-brand-black hover:bg-stone-100 transition-all border border-stone-100">
                <X size={24} />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-8 md:p-10 space-y-10 custom-scrollbar bg-brand-cream">
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center space-y-8 py-20">
                  <div className="w-24 h-24 bg-brand-paper/50 rounded-[2.5rem] flex items-center justify-center text-brand-black/10 border border-brand-black/5">
                    <ShoppingBag size={48} strokeWidth={1} />
                  </div>
                  <div className="space-y-4">
                    <p className="text-2xl font-serif italic text-brand-black/30">Your bag is empty.</p>
                    <button 
                      onClick={toggleCart}
                      className="text-[10px] font-black uppercase tracking-[0.5em] text-brand-black border-b-2 border-brand-gold pb-2 hover:text-brand-gold transition-all duration-500"
                    >
                      Browse Scent Shop
                    </button>
                  </div>
                </div>
              ) : (
                cart.map((item) => {
                  const sourceProduct = products.find(p => p.id === item.id);
                  const stock = sourceProduct?.stock || 0;
                  const isMaxed = item.quantity >= stock;

                  return (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    key={item.cartItemId || item.id} 
                    className="flex gap-8 group"
                  >
                    {/* Thumbnail */}
                    <div className="w-28 h-32 bg-white border border-stone-100 flex-shrink-0 overflow-hidden rounded-3xl relative p-3 flex items-center justify-center shadow-sm group-hover:shadow-md transition-all duration-700">
                      <img src={item.images[0]} alt={item.name} className="w-full h-full object-contain drop-shadow-lg" />
                    </div>
                    
                    <div className="flex-1 flex flex-col justify-between py-2">
                      <div>
                        <div className="flex justify-between items-start">
                          <h3 className="text-2xl font-bold text-brand-black font-serif italic tracking-tighter leading-none group-hover:text-brand-gold transition-colors">
                            {item.name}
                          </h3>
                          <button 
                            onClick={() => removeFromCart(item.cartItemId)}
                            className="text-stone-300 hover:text-brand-crimson transition-all p-1"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                        <div className="flex items-center gap-3 text-[9px] font-black uppercase tracking-widest text-brand-charcoal/40 mt-3">
                          <span>{item.size}</span>
                          <span className="w-1 h-1 rounded-full bg-brand-gold/30" />
                          <span>{item.category}</span>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-end mt-4">
                        <div className="flex items-center bg-white rounded-2xl p-1 border border-stone-200">
                          <button 
                            onClick={() => handleUpdateQuantity(item, item.quantity - 1)}
                            className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-stone-50 transition-colors text-brand-charcoal/50"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="px-3 text-xs font-black w-8 text-center text-brand-black">{item.quantity}</span>
                          <button 
                            onClick={() => handleUpdateQuantity(item, item.quantity + 1)}
                            disabled={isMaxed}
                            className={`w-8 h-8 flex items-center justify-center rounded-xl transition-colors ${isMaxed ? 'text-stone-300 cursor-not-allowed' : 'hover:bg-stone-50 text-brand-charcoal/50'}`}
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                        <p className="font-serif font-bold text-xl text-brand-black">{formatPrice(item.price * item.quantity)}</p>
                      </div>
                    </div>
                  </motion.div>
                )})
              )}
            </div>

            {/* Footer */}
            {cart.length > 0 && (
              <div className="p-10 border-t border-stone-200 bg-white space-y-8 shadow-[0_-10px_30px_rgba(0,0,0,0.02)]">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-[0.5em] text-brand-gold mb-1">Subtotal</p>
                    <span className="text-3xl font-serif font-bold text-brand-black italic tracking-tighter">
                      {formatPrice(cartTotal)}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-[8px] font-bold uppercase tracking-widest text-brand-charcoal/40 mb-1">Shipping</p>
                    <p className="text-[10px] font-black uppercase tracking-widest text-brand-black">Calculated next</p>
                  </div>
                </div>
                
                {isAdmin ? (
                    <div className="w-full bg-stone-100 text-stone-500 text-center py-6 font-black tracking-[0.2em] uppercase text-[9px] rounded-full border border-stone-200 cursor-not-allowed flex flex-col items-center gap-2">
                        <ShieldAlert size={16} />
                        <span>Admin Checkout Disabled</span>
                        <span className="text-[8px] font-normal lowercase tracking-wide opacity-70">Please use a customer account to place orders</span>
                    </div>
                ) : (
                    <Link
                      to="/checkout"
                      onClick={toggleCart}
                      className="block w-full"
                    >
                      <motion.button
                         whileHover={{ scale: 1.01 }}
                         whileTap={{ scale: 0.98 }}
                         className="w-full bg-brand-black text-brand-cream text-center py-6 font-black tracking-[0.4em] hover:bg-brand-crimson transition-all duration-500 ease-out uppercase text-[11px] shadow-[0_20px_40px_-10px_rgba(0,0,0,0.2)] flex items-center justify-center gap-4 group rounded-full"
                      >
                        Go to Checkout <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform duration-500" />
                      </motion.button>
                    </Link>
                )}
                
                <p className="text-[8px] text-brand-charcoal/30 text-center font-black uppercase tracking-[0.5em]">
                   Secure Checkout • 100% Guaranteed
                </p>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
