
import React, { useState } from 'react';
// @ts-ignore
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Plus, ArrowUpRight, Star, Sparkles, Diamond } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { useCurrency } from '../context/CurrencyContext';
import { Product } from '../types';
import { ImageWithFallback } from './ImageWithFallback';

interface ProductCardProps {
  product: Product;
  variants?: any;
}

const StarRating = ({ rating, count }: { rating?: number, count?: number }) => {
  const displayRating = rating || 0;
  return (
    <div className="flex items-center gap-2 mt-1.5">
      <div className="flex gap-0.5">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            size={8} 
            className={`${i < Math.floor(displayRating) ? 'fill-brand-gold text-brand-gold' : 'text-stone-200'}`} 
          />
        ))}
      </div>
      {count !== undefined && count > 0 && (
        <span className="text-[7px] font-bold text-stone-300 uppercase tracking-widest">({count})</span>
      )}
    </div>
  );
};

export const ProductCard: React.FC<ProductCardProps> = ({ product, variants }) => {
  const { addToCart, addToWishlist, removeFromWishlist, isInWishlist } = useShop();
  const { formatPrice } = useCurrency();
  const [isHovered, setIsHovered] = useState(false);

  const isWishlisted = isInWishlist(product.id);
  const isOutOfStock = (product.stock || 0) <= 0;
  const hasSale = product.compareAtPrice && product.compareAtPrice > product.price;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isOutOfStock) return;
    const defaultSize = product.sizes && product.sizes.length > 0 ? product.sizes[0] : product.size;
    addToCart(product, 1, true, defaultSize);
  };

  return (
    <motion.div 
      variants={variants} 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative flex flex-col h-full w-full max-w-[420px] mx-auto"
    >
      {/* Image Container with Fixed Aspect Ratio for Uniformity */}
      <div className={`relative aspect-[4/5] bg-white rounded-[2.5rem] overflow-hidden mb-6 shadow-sm transition-all duration-1000 border border-stone-100 cursor-pointer ${isHovered ? 'shadow-2xl ring-1 ring-brand-gold/10 -translate-y-2' : ''}`}>
        <Link to={`/product/${product.id}`} className="w-full h-full block relative z-10">
           <motion.div
             animate={{ scale: isHovered ? 1.05 : 1 }}
             transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
             className="w-full h-full"
           >
              <ImageWithFallback 
                src={product.images[0]} 
                alt={product.name} 
                className={`w-full h-full object-contain p-10 transition-all duration-1000 ${isOutOfStock ? 'grayscale opacity-30' : ''}`} 
              />
           </motion.div>
           
           {/* Quick Scent Stats Overlay */}
           <motion.div 
             initial={{ opacity: 0 }}
             animate={{ opacity: isHovered ? 1 : 0 }}
             className="absolute inset-0 bg-brand-black/60 backdrop-blur-[4px] flex flex-col items-center justify-center p-8 text-center z-20"
           >
              <span className="text-[8px] font-black uppercase tracking-[0.5em] text-brand-gold mb-6">Scent Profile</span>
              <div className="space-y-4 mb-8">
                <div>
                  <p className="text-[7px] font-black uppercase tracking-widest text-white/40 mb-1">Middle Notes</p>
                  <p className="text-xs text-white font-serif italic">{product.notes.heart.slice(0, 2).join(' • ')}</p>
                </div>
                <div>
                  <p className="text-[7px] font-black uppercase tracking-widest text-white/40 mb-1">Base Notes</p>
                  <p className="text-xs text-white font-serif italic">{product.notes.base.slice(0, 2).join(' • ')}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-[0.3em] text-white border-b border-brand-gold pb-1 mt-4">
                View Details <ArrowUpRight size={10} />
              </div>
           </motion.div>
        </Link>

        <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); isWishlisted ? removeFromWishlist(product.id) : addToWishlist(product); }}
          className={`absolute top-5 right-5 p-3.5 rounded-full backdrop-blur-md transition-all duration-500 shadow-lg z-30 ${isWishlisted ? 'bg-brand-crimson text-white scale-110' : 'bg-white/90 text-stone-300 hover:text-brand-black opacity-0 group-hover:opacity-100'}`}>
          <Heart size={16} className={isWishlisted ? 'fill-current' : ''} />
        </button>

        {/* Elegant Minimal Tags - UPDATED SMALLER SIZE & TEXT */}
        <div className="absolute top-4 left-4 flex flex-col gap-1.5 z-30 pointer-events-none">
            {product.isNew && !isOutOfStock && (
              <div className="px-2 py-0.5 bg-white/90 backdrop-blur border border-stone-100 text-brand-black text-[7px] font-bold uppercase tracking-[0.2em] rounded-sm shadow-sm flex items-center gap-1">
                  NEW
              </div>
            )}
            {(product.isBestSeller || product.id === 'f1') && !isOutOfStock && (
              <div className="px-2 py-0.5 bg-brand-gold/10 backdrop-blur border border-brand-gold/20 text-brand-gold text-[7px] font-bold uppercase tracking-[0.2em] rounded-sm shadow-sm flex items-center gap-1">
                  SIGNATURE
              </div>
            )}
            {product.isLimitedEdition && !isOutOfStock && (
              <div className="px-2 py-0.5 bg-brand-black text-white text-[7px] font-bold uppercase tracking-[0.2em] rounded-sm shadow-sm">
                  LIMITED
              </div>
            )}
        </div>
        
        {isOutOfStock && (
            <div className="absolute inset-0 bg-brand-cream/60 flex items-center justify-center pointer-events-none z-30 backdrop-blur-[2px]">
                <span className="bg-white/95 backdrop-blur px-6 py-2.5 rounded-full text-[9px] font-black uppercase tracking-[0.3em] text-stone-400 shadow-lg border border-stone-100">Out of Stock</span>
            </div>
        )}
      </div>

      <div className="flex flex-col flex-1 px-1">
        <div className="flex justify-between items-start mb-4">
            <div className="flex flex-col flex-1 min-w-0 pr-4">
                <span className="text-[8px] font-black uppercase tracking-[0.4em] text-brand-crimson mb-1">{product.category}</span>
                <Link to={`/product/${product.id}`} className="block">
                    <h3 className="font-serif text-xl lg:text-2xl font-bold text-brand-black italic hover:text-brand-crimson transition-colors leading-tight truncate">{product.name}</h3>
                </Link>
                <StarRating rating={product.rating} count={product.reviewCount} />
            </div>
            <div className="text-right">
                <p className="text-xl lg:text-2xl font-serif font-bold text-brand-black leading-none">{formatPrice(product.price)}</p>
                {hasSale && <p className="text-[9px] text-stone-300 line-through mt-1 italic opacity-60">{formatPrice(product.compareAtPrice!)}</p>}
            </div>
        </div>
        
        <p className="text-stone-400 text-xs lg:text-sm font-serif italic mb-6 line-clamp-2 leading-relaxed opacity-80 min-h-[40px]">
           "{product.tagline}"
        </p>
        
        <div className="mt-auto flex gap-3">
            <button 
              onClick={handleAddToCart} 
              disabled={isOutOfStock} 
              className={`flex-1 h-12 lg:h-14 rounded-2xl text-[9px] lg:text-[10px] font-black uppercase tracking-[0.3em] transition-all duration-500 flex items-center justify-center gap-3 shadow-md active:scale-95 ${isOutOfStock ? 'bg-stone-100 text-stone-300 border border-stone-200 cursor-not-allowed shadow-none' : 'bg-brand-black text-white hover:bg-brand-crimson'}`}
            >
                {isOutOfStock ? 'Sold Out' : 'Add to Bag'}
                {!isOutOfStock && <Plus size={14} />}
            </button>
            <Link 
              to={`/product/${product.id}`} 
              className="w-12 h-12 lg:w-14 lg:h-14 rounded-2xl border border-stone-200 flex items-center justify-center text-stone-300 hover:text-brand-black hover:border-brand-black transition-all bg-white shadow-sm"
            >
                <ArrowUpRight size={20} />
            </Link>
        </div>
      </div>
    </motion.div>
  );
};
