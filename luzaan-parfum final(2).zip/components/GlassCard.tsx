
import React from 'react';
import { motion } from 'framer-motion';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  dark?: boolean;
}

export const GlassCard: React.FC<GlassCardProps> = ({ children, className = '', dark = false }) => {
  return (
    // FIX: Suppress incorrect TypeScript error for valid framer-motion props.
    // @ts-ignore
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`${dark ? 'glass-dark' : 'glass'} rounded-2xl shadow-xl ${className}`}
    >
      {children}
    </motion.div>
  );
};
