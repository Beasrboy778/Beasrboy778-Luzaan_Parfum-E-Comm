
import React, { useState } from 'react';
// @ts-ignore
import { Link } from 'react-router-dom';
import { 
  Instagram, Facebook, Twitter, ArrowRight, 
  Droplet, Sparkles, Globe, 
  ChevronUp, Waves, CheckCircle2,
  Mail, MapPin, Phone, Clock
} from 'lucide-react';
import { useCurrency } from '../context/CurrencyContext';
import { useShop } from '../context/ShopContext';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  const { country, currency } = useCurrency();
  const { designSettings, storeSettings } = useShop();
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  const handleSubscribe = (e: React.FormEvent) => {
      e.preventDefault();
      if(email.includes('@')) {
          setIsSubscribed(true);
          setEmail('');
      }
  };

  const countries = [
    { name: 'United States', flag: '🇺🇸' },
    { name: 'United Kingdom', flag: '🇬🇧' },
    { name: 'Europe', flag: '🇪🇺' },
    { name: 'India', flag: '🇮🇳' },
    { name: 'Canada', flag: '🇨🇦' },
    { name: 'Australia', flag: '🇦🇺' }
  ];
  
  const currentFlag = countries.find(c => c.name === country)?.flag || '🌐';

  return (
    <footer className="bg-brand-black text-brand-cream relative overflow-hidden border-t border-white/5 font-sans">
      {/* Background Image Overlay */}
      {designSettings.footerImage && (
          <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
              <img src={designSettings.footerImage} alt="" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-brand-black/80 to-transparent" />
          </div>
      )}

      {/* Top Banner - Ultra Slim */}
      <div className="w-full bg-brand-paper py-2 relative z-10 overflow-hidden">
         <div className="flex animate-marquee whitespace-nowrap text-[6px] font-black uppercase tracking-[0.5em] text-brand-black items-center">
             {[...Array(12)].map((_, i) => (
                <React.Fragment key={i}>
                    <span className="flex items-center gap-2 mx-6"><Waves size={8} /> Olfactory Poetry</span>
                    <span className="flex items-center gap-2 mx-6"><Droplet size={8} /> Pure Extracts</span>
                    <span className="flex items-center gap-2 mx-6"><Sparkles size={8} /> Atelier Crafted</span>
                </React.Fragment>
             ))}
         </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 pt-20 pb-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          
          {/* Column 1: Brand Identity */}
          <div className="space-y-6">
            <Logo color="text-white" size="text-2xl" />
            <p className="text-stone-500 text-[10px] leading-relaxed font-serif italic opacity-80 uppercase tracking-widest font-bold max-w-xs">
              "Scent is the most intense form of memory."
            </p>
            <div className="flex gap-4 pt-2">
                {storeSettings.socialLinks.instagram && (
                    <a href={storeSettings.socialLinks.instagram} target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-stone-400 hover:bg-white hover:text-brand-black transition-all"><Instagram size={14} /></a>
                )}
                {storeSettings.socialLinks.facebook && (
                    <a href={storeSettings.socialLinks.facebook} target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-stone-400 hover:bg-white hover:text-brand-black transition-all"><Facebook size={14} /></a>
                )}
                {storeSettings.socialLinks.twitter && (
                    <a href={storeSettings.socialLinks.twitter} target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-stone-400 hover:bg-white hover:text-brand-black transition-all"><Twitter size={14} /></a>
                )}
            </div>
          </div>

          {/* Column 2: The House (About & Content) */}
          <div className="space-y-6">
            <h4 className="font-black text-[9px] uppercase tracking-[0.4em] text-brand-gold">The House</h4>
            <ul className="space-y-3">
              <li><Link to="/about" className="text-stone-400 hover:text-white transition-all font-bold uppercase tracking-widest text-[9px] flex items-center gap-2 group"><span className="w-0 group-hover:w-2 transition-all h-px bg-brand-crimson"></span>About Us</Link></li>
              <li><Link to="/about" className="text-stone-400 hover:text-white transition-all font-bold uppercase tracking-widest text-[9px] flex items-center gap-2 group"><span className="w-0 group-hover:w-2 transition-all h-px bg-brand-crimson"></span>Our Story</Link></li>
              <li><Link to="/blog" className="text-stone-400 hover:text-white transition-all font-bold uppercase tracking-widest text-[9px] flex items-center gap-2 group"><span className="w-0 group-hover:w-2 transition-all h-px bg-brand-crimson"></span>The Journal</Link></li>
              <li><Link to="/shop" className="text-stone-400 hover:text-white transition-all font-bold uppercase tracking-widest text-[9px] flex items-center gap-2 group"><span className="w-0 group-hover:w-2 transition-all h-px bg-brand-crimson"></span>Collections</Link></li>
            </ul>
          </div>

          {/* Column 3: Concierge & Assistance */}
          <div className="space-y-6">
            <h4 className="font-black text-[9px] uppercase tracking-[0.4em] text-brand-gold">Assistance</h4>
            <ul className="space-y-3">
              <li><Link to="/contact" className="text-stone-400 hover:text-white transition-all font-bold uppercase tracking-widest text-[9px] flex items-center gap-2 group"><span className="w-0 group-hover:w-2 transition-all h-px bg-brand-crimson"></span>Contact Us</Link></li>
              <li><Link to="/faq" className="text-stone-400 hover:text-white transition-all font-bold uppercase tracking-widest text-[9px] flex items-center gap-2 group"><span className="w-0 group-hover:w-2 transition-all h-px bg-brand-crimson"></span>FAQ</Link></li>
              <li><Link to="/shipping" className="text-stone-400 hover:text-white transition-all font-bold uppercase tracking-widest text-[9px] flex items-center gap-2 group"><span className="w-0 group-hover:w-2 transition-all h-px bg-brand-crimson"></span>Shipping Policy</Link></li>
              <li><Link to="/account" className="text-stone-400 hover:text-white transition-all font-bold uppercase tracking-widest text-[9px] flex items-center gap-2 group"><span className="w-0 group-hover:w-2 transition-all h-px bg-brand-crimson"></span>Track Order</Link></li>
            </ul>
          </div>

          {/* Column 4: Visit Us & Newsletter */}
          <div className="space-y-8">
             <div className="space-y-4">
                <h4 className="font-black text-[9px] uppercase tracking-[0.4em] text-brand-gold">Visit Us</h4>
                <div className="space-y-3">
                    <div className="flex gap-3 items-start">
                        <MapPin size={14} className="text-stone-500 mt-0.5 shrink-0" />
                        <p className="text-[9px] font-bold uppercase tracking-widest text-stone-400 leading-relaxed">
                            {storeSettings.contactDetails.addressLine1 || "123 Perfume Lane"}<br />
                            {storeSettings.contactDetails.addressLine2 || "Paris, France"}
                        </p>
                    </div>
                    <div className="flex gap-3 items-center">
                        <Phone size={14} className="text-stone-500 shrink-0" />
                        <p className="text-[9px] font-bold uppercase tracking-widest text-stone-400">{storeSettings.contactDetails.phone || "+33 1 23 45 67 89"}</p>
                    </div>
                    <div className="flex gap-3 items-center">
                        <Clock size={14} className="text-stone-500 shrink-0" />
                        <p className="text-[9px] font-bold uppercase tracking-widest text-stone-400">{storeSettings.contactDetails.hours || "Mon-Fri 9am-6pm"}</p>
                    </div>
                </div>
             </div>

             <div className="p-5 rounded-2xl border border-white/10 bg-white/[0.02] relative overflow-hidden">
                {isSubscribed ? (
                    <div className="text-green-500 text-[9px] font-bold uppercase tracking-widest flex items-center gap-2"><CheckCircle2 size={12} /> Joined the Archive</div>
                ) : (
                    <form onSubmit={handleSubscribe} className="relative">
                        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="JOIN THE LIST" className="w-full bg-black/40 border border-white/10 py-3 px-4 rounded-xl text-[9px] text-white focus:outline-none focus:border-brand-crimson transition-all font-bold uppercase placeholder-stone-600" />
                        <button type="submit" className="absolute right-1 top-1/2 -translate-y-1/2 w-8 h-8 bg-brand-crimson text-white rounded-lg flex items-center justify-center hover:bg-white hover:text-brand-crimson transition-all"><ArrowRight size={12} /></button>
                    </form>
                )}
             </div>
          </div>
        </div>
      </div>

      <div className="border-t border-white/5 bg-black/40 py-6 relative z-10">
         <div className="max-w-7xl mx-auto px-6 lg:px-12 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex flex-col md:flex-row gap-4 items-center">
                <p className="text-[8px] text-stone-600 uppercase font-black tracking-[0.3em]">© {new Date().getFullYear()} {storeSettings.storeName.toUpperCase()}.</p>
                <div className="hidden md:block w-px h-3 bg-white/10"></div>
                <div className="flex gap-4 text-[8px] font-bold uppercase tracking-widest text-stone-600">
                    <Link to="/privacy" className="hover:text-stone-400 transition-colors">Privacy</Link>
                    <Link to="/terms" className="hover:text-stone-400 transition-colors">Terms</Link>
                </div>
            </div>
            
            <div className="flex items-center gap-4 opacity-40 grayscale hover:grayscale-0 transition-all duration-500">
                <div className="h-5 px-2 bg-white rounded flex items-center justify-center text-[7px] font-black text-brand-black tracking-tighter">VISA</div>
                <div className="h-5 px-2 bg-white rounded flex items-center justify-center text-[7px] font-black text-brand-black tracking-tighter">AMEX</div>
                <div className="h-5 px-2 bg-white rounded flex items-center justify-center text-[7px] font-black text-brand-black tracking-tighter">PAYPAL</div>
            </div>

            <div className="flex items-center gap-6">
                <div className="flex items-center gap-4 text-[9px] text-stone-500 font-bold uppercase tracking-widest">
                    <span className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/5 cursor-default hover:bg-white/10 transition-colors"><span>{currentFlag}</span> {country}</span>
                    <span className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/5 cursor-default hover:bg-white/10 transition-colors"><Globe size={10} className="text-brand-crimson" /> {currency}</span>
                </div>
                <button onClick={scrollToTop} className="w-8 h-8 rounded-full bg-white/5 border border-white/5 text-stone-500 hover:text-white hover:bg-brand-crimson transition-all flex items-center justify-center"><ChevronUp size={14} /></button>
            </div>
         </div>
      </div>
    </footer>
  );
};
