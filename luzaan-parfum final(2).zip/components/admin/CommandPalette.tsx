
import React, { useState, useEffect, useRef } from 'react';
// @ts-ignore
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, Package, Users, ShoppingCart, Settings, 
  ArrowRight, FileText, Plus, LogOut, LayoutDashboard, 
  CreditCard, Truck, Palette, CornerDownLeft 
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { useAuth } from '../../context/AuthContext';

interface CommandResult {
  id: string;
  type: 'page' | 'product' | 'order' | 'customer' | 'action';
  title: string;
  subtitle?: string;
  icon: any;
  action: () => void;
}

export const CommandPalette: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  
  const navigate = useNavigate();
  const { adminProducts, adminOrders, adminCustomers, storeSettings } = useShop();
  const { logout } = useAuth();

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  // Generate Results based on Query
  const results: CommandResult[] = React.useMemo(() => {
    const q = query.toLowerCase().trim();
    let items: CommandResult[] = [];

    // 1. Navigation Pages (Always show some defaults if query is empty)
    const pages = [
      { title: 'Dashboard', path: '/admin', icon: LayoutDashboard },
      { title: 'Products', path: '/admin/products', icon: Package },
      { title: 'Orders', path: '/admin/orders', icon: ShoppingCart },
      { title: 'Customers', path: '/admin/customers', icon: Users },
      { title: 'Store Design', path: '/admin/design', icon: Palette },
      { title: 'Settings', path: '/admin/settings', icon: Settings },
      { title: 'Shipping', path: '/admin/shipping', icon: Truck },
    ];

    pages.forEach(page => {
      if (page.title.toLowerCase().includes(q)) {
        items.push({
          id: `page-${page.title}`,
          type: 'page',
          title: page.title,
          subtitle: 'Go to page',
          icon: page.icon,
          action: () => navigate(page.path)
        });
      }
    });

    // If query exists, search data
    if (q) {
      // 2. Products
      adminProducts.slice(0, 5).forEach(p => {
        if (p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q)) {
          items.push({
            id: p.id,
            type: 'product',
            title: p.name,
            subtitle: `Edit Product • ${p.stock} in stock`,
            icon: Package,
            action: () => navigate('/admin/products') //Ideally deep link to edit modal if architecture supported
          });
        }
      });

      // 3. Orders
      adminOrders.slice(0, 5).forEach(o => {
        if (o.id.toLowerCase().includes(q) || o.customer.name.toLowerCase().includes(q)) {
          items.push({
            id: o.id,
            type: 'order',
            title: `Order ${o.id}`,
            subtitle: `${o.customer.name} • ${o.status}`,
            icon: ShoppingCart,
            action: () => navigate('/admin/orders', { state: { focusOrderId: o.id } })
          });
        }
      });

      // 4. Customers
      adminCustomers.slice(0, 5).forEach(c => {
        if (c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)) {
          items.push({
            id: c.id,
            type: 'customer',
            title: c.name,
            subtitle: c.email,
            icon: Users,
            action: () => navigate('/admin/customers')
          });
        }
      });
    }

    // 5. Actions (Always available or filtered)
    const actions = [
      { title: 'Create New Product', icon: Plus, action: () => navigate('/admin/products') },
      { title: 'Log Out', icon: LogOut, action: () => { logout(); navigate('/login'); } },
    ];

    actions.forEach(act => {
      if (act.title.toLowerCase().includes(q)) {
        items.push({
          id: `action-${act.title}`,
          type: 'action',
          title: act.title,
          subtitle: 'Perform action',
          icon: act.icon,
          action: act.action
        });
      }
    });

    return items;
  }, [query, adminProducts, adminOrders, adminCustomers, navigate, logout]);

  // Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % results.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + results.length) % results.length);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (results[selectedIndex]) {
          results[selectedIndex].action();
          onClose();
        }
      } else if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, results, selectedIndex, onClose]);

  // Ensure selection resets when query changes
  useEffect(() => setSelectedIndex(0), [query]);

  // Auto-scroll to selected item
  useEffect(() => {
    if (listRef.current) {
        const selectedElement = listRef.current.children[selectedIndex] as HTMLElement;
        if (selectedElement) {
            selectedElement.scrollIntoView({ block: 'nearest' });
        }
    }
  }, [selectedIndex]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[9999] flex items-start justify-center pt-[15vh] px-4">
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            onClick={onClose} 
            className="absolute inset-0 bg-brand-black/40 backdrop-blur-sm" 
          />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: -20 }} 
            animate={{ opacity: 1, scale: 1, y: 0 }} 
            exit={{ opacity: 0, scale: 0.95, y: -20 }} 
            className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden relative flex flex-col max-h-[60vh]"
          >
            <div className="flex items-center px-4 py-4 border-b border-stone-100">
              <Search className="text-stone-400 ml-2" size={20} />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Type a command or search..."
                className="w-full px-4 py-1 text-lg text-brand-black placeholder-stone-300 outline-none bg-transparent"
              />
              <div className="hidden sm:flex items-center gap-2">
                  <span className="text-[10px] font-bold text-stone-400 bg-stone-100 px-2 py-1 rounded-md border border-stone-200">ESC</span>
              </div>
            </div>

            <div ref={listRef} className="overflow-y-auto p-2 space-y-1 custom-scrollbar">
              {results.length > 0 ? (
                results.map((item, index) => (
                  <div
                    key={`${item.type}-${item.id}`}
                    onClick={() => { item.action(); onClose(); }}
                    onMouseEnter={() => setSelectedIndex(index)}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl cursor-pointer transition-all ${
                      index === selectedIndex ? 'bg-brand-black text-white' : 'text-brand-black hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`p-2 rounded-lg ${index === selectedIndex ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'}`}>
                        <item.icon size={18} />
                      </div>
                      <div>
                        <p className={`text-sm font-bold ${index === selectedIndex ? 'text-white' : 'text-brand-black'}`}>{item.title}</p>
                        {item.subtitle && (
                          <p className={`text-[10px] uppercase tracking-wider font-medium ${index === selectedIndex ? 'text-white/60' : 'text-stone-400'}`}>
                            {item.subtitle}
                          </p>
                        )}
                      </div>
                    </div>
                    {index === selectedIndex && (
                        <CornerDownLeft size={16} className="text-white/50" />
                    )}
                  </div>
                ))
              ) : (
                <div className="py-12 text-center text-stone-400">
                  <p className="text-sm font-medium">No results found.</p>
                </div>
              )}
            </div>
            
            <div className="px-4 py-3 bg-stone-50 border-t border-stone-100 flex justify-between items-center text-[10px] text-stone-400 font-bold uppercase tracking-widest">
                <span>{storeSettings.storeName} Command Center</span>
                <span className="flex items-center gap-2">
                    <span className="bg-white border border-stone-200 px-1.5 py-0.5 rounded shadow-sm">↑</span>
                    <span className="bg-white border border-stone-200 px-1.5 py-0.5 rounded shadow-sm">↓</span>
                    to navigate
                </span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
