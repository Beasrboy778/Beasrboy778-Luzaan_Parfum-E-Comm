
import React from 'react';
import { motion } from 'framer-motion';

export const AnimatedCheckmark: React.FC<{ size?: number; className?: string }> = ({ size = 64, className = "text-green-600" }) => {
  return (
    <div className={`relative flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 50 50"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Circle Background Drawing */}
        <motion.circle
          cx="25"
          cy="25"
          r="23"
          stroke="currentColor"
          strokeWidth="2"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        />
        
        {/* Checkmark Drawing */}
        <motion.path
          d="M14 26L22 34L36 16"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5, ease: "easeOut" }}
        />
      </svg>
    </div>
  );
};

export const AnimatedPulse: React.FC<{ color?: string }> = ({ color = "bg-green-500" }) => {
  return (
    <div className="relative w-3 h-3 flex items-center justify-center">
      <motion.div
        className={`absolute w-full h-full rounded-full ${color} opacity-75`}
        animate={{ scale: [1, 2], opacity: [0.7, 0] }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut" }}
      />
      <div className={`relative w-2 h-2 rounded-full ${color}`} />
    </div>
  );
};

export const AnimatedBell: React.FC<{ hasNotifications: boolean }> = ({ hasNotifications }) => {
  return (
    <motion.div
      whileHover={{ rotate: [0, -15, 15, -10, 10, 0] }}
      transition={{ duration: 0.5 }}
      className="relative text-stone-500 hover:text-brand-black cursor-pointer"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
      </svg>
      
      {hasNotifications && (
        <motion.span
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute -top-1 -right-1 bg-brand-crimson text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center border-2 border-white shadow-sm"
        >
          !
        </motion.span>
      )}
    </motion.div>
  );
};

export const AnimatedStatsIcon: React.FC<{ children: React.ReactNode, delay?: number, colorClass?: string }> = ({ children, delay = 0, colorClass = "bg-brand-crimson/10 text-brand-crimson" }) => {
    return (
        <motion.div
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 200, damping: 15, delay }}
            className={`p-3 rounded-full ${colorClass}`}
        >
            {children}
        </motion.div>
    )
}
