
# Aura Backend Structure

This directory simulates the backend structure for the Aura E-commerce platform.

## Folder Structure

```
/src
  /config         # Database, Stripe, and Environment config
  /controllers    # Request handlers (Auth, Products, Orders)
  /services       # Business logic layer
  /models         # Database models (TypeORM or Prisma definitions)
  /routes         # Express/NestJS route definitions
  /middleware     # Auth guards, Logging, Error handling
  /utils          # Helper functions (Currency formatter, Date utils)
  /jobs           # BullMQ background jobs (Email sending, Inventory sync)
```

## Setup

1. Copy `.env.example` to `.env`
2. Run `docker-compose up -d` to start Postgres and Redis.
3. Run `npx prisma migrate dev` to apply the schema.
4. Run `npm run dev` to start the API server.
