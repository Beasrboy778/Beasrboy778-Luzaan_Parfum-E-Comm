
const { Pool } = require('pg');
require('dotenv').config();

// Create a new pool instance to manage connections
const pool = new Pool({
  user: process.env.DB_USER || 'admin',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'aura_ecommerce',
  password: process.env.DB_PASSWORD || 'password',
  port: process.env.DB_PORT || 5432,
});

// Event listener for errors on idle clients
pool.on('error', (err, client) => {
  console.error('Unexpected error on idle client', err);
  process.exit(-1);
});

module.exports = {
  // Expose a query method that logs and delegates to the pool
  query: (text, params) => {
    console.log('Executed query:', text);
    return pool.query(text, params);
  },
  // Method to get a client from the pool for transactions
  getClient: () => pool.connect(),
};
