
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'luzaan_fragrance_secret_2025';

// --- PRODUCTION MIDDLEWARE ---
const corsOptions = {
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  optionsSuccessStatus: 200
};

app.use(cors(corsOptions));
app.use(express.json());

// --- HIGH TRAFFIC DATABASE CONFIG ---
// Optimized for >1000 concurrent requests via connection pooling
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: 20, // Max clients in the pool
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err, client) => {
  console.error('Unexpected error on idle client', err);
  // Don't exit process, just log. Resiliency.
});

// --- INITIALIZE TABLES ---
const initDb = async () => {
    try {
        // Users & Orders
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                name VARCHAR(255),
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role VARCHAR(50) DEFAULT 'user',
                region VARCHAR(100),
                join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS orders (
                id SERIAL PRIMARY KEY,
                customer_email VARCHAR(255),
                total DECIMAL(10, 2),
                items JSONB,
                status VARCHAR(50),
                payment_intent_id VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        // Categories Table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS categories (
                id VARCHAR(100) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                slug VARCHAR(255) UNIQUE NOT NULL,
                image TEXT,
                product_count INTEGER DEFAULT 0
            );
        `);

        // Products Table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS products (
                id VARCHAR(100) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                tagline TEXT,
                price DECIMAL(10, 2) NOT NULL,
                compare_at_price DECIMAL(10, 2),
                description TEXT,
                notes JSONB,
                size VARCHAR(50),
                sizes JSONB,
                images JSONB,
                category VARCHAR(100),
                is_new BOOLEAN DEFAULT FALSE,
                is_best_seller BOOLEAN DEFAULT FALSE,
                badge VARCHAR(100),
                stock INTEGER DEFAULT 0,
                highlights JSONB,
                tags JSONB
            );
        `);

        // Reviews Table
        await pool.query(`
            CREATE TABLE IF NOT EXISTS reviews (
                id SERIAL PRIMARY KEY,
                product_id VARCHAR(100) NOT NULL,
                product_name VARCHAR(255),
                user_name VARCHAR(255),
                rating INTEGER CHECK (rating >= 1 AND rating <= 5),
                comment TEXT,
                status VARCHAR(50) DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        // Seeding Logic for Categories
        const catCheck = await pool.query('SELECT COUNT(*) FROM categories');
        if (parseInt(catCheck.rows[0].count) === 0) {
            console.log('Seeding initial categories...');
            const initialCats = [
                ['all', 'Shop All', 'all', null, 6],
                ['men', 'Men', 'men', null, 2],
                ['women', 'Women', 'women', null, 2],
                ['unisex', 'Unisex', 'unisex', null, 1],
                ['attar', 'Attar', 'attar', null, 1]
            ];
            for (const cat of initialCats) {
                await pool.query('INSERT INTO categories (id, name, slug, image, product_count) VALUES ($1, $2, $3, $4, $5)', cat);
            }
        }

        console.log('Luzaan Database Schema Verified and Seeded.');
    } catch (err) {
        console.error('Database Init Error:', err);
    }
};
initDb();

// --- AUTH ROUTES ---

app.post('/api/auth/register', async (req, res) => {
    const { name, email, password, region } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const result = await pool.query(
            'INSERT INTO users (name, email, password, region, role) VALUES ($1, $2, $3, $4, $5) RETURNING id, name, email, role, region',
            [name, email, hashedPassword, region || 'United States', 'user']
        );
        
        const user = result.rows[0];
        const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
        
        res.status(201).json({ user, token });
    } catch (err) {
        if (err.code === '23505') return res.status(400).json({ error: 'Email already exists.' });
        res.status(500).json({ error: 'Registration failed.' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        // Updated Master Admin Credentials
        if (email === 'admin@luzaan.com' && password === 'Luzaan_2003') {
            const mockAdmin = { id: 0, name: 'Admin', email: 'admin@luzaan.com', role: 'admin', region: 'Global' };
            const token = jwt.sign({ id: 0, role: 'admin' }, JWT_SECRET, { expiresIn: '7d' });
            return res.json({ user: mockAdmin, token });
        }

        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        const user = result.rows[0];

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ error: 'Invalid credentials.' });
        }

        const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
        delete user.password;
        res.json({ user, token });
    } catch (err) {
        res.status(500).json({ error: 'Login service error.' });
    }
});

// --- PAYMENT ROUTES ---

app.post('/api/create-payment-intent', async (req, res) => {
  const { amount, currency = 'usd' } = req.body;
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Convert to cents
      currency,
      automatic_payment_methods: { enabled: true },
    });
    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// --- PRODUCT CRUD ROUTES ---

app.get('/api/products', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM products ORDER BY name ASC');
        const prods = result.rows.map(p => ({
            ...p,
            compareAtPrice: p.compare_at_price,
            isNew: p.is_new,
            isBestSeller: p.is_best_seller
        }));
        res.json(prods);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch products.' });
    }
});

app.post('/api/products', async (req, res) => {
    const p = req.body;
    try {
        await pool.query(`
            INSERT INTO products (id, name, tagline, price, compare_at_price, description, notes, size, sizes, images, category, is_best_seller, is_new, stock)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
        `, [p.id, p.name, p.tagline, p.price, p.compareAtPrice, p.description, JSON.stringify(p.notes), p.size, JSON.stringify(p.sizes), JSON.stringify(p.images), p.category, p.isBestSeller, p.isNew, p.stock]);
        res.status(201).json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to create product.' });
    }
});

app.put('/api/products/:id', async (req, res) => {
    const { id } = req.params;
    const p = req.body;
    try {
        await pool.query(`
            UPDATE products SET 
                name=$1, tagline=$2, price=$3, compare_at_price=$4, description=$5, 
                notes=$6, size=$7, sizes=$8, images=$9, category=$10, 
                is_best_seller=$11, is_new=$12, stock=$13
            WHERE id=$14
        `, [p.name, p.tagline, p.price, p.compareAtPrice, p.description, JSON.stringify(p.notes), p.size, JSON.stringify(p.sizes), JSON.stringify(p.images), p.category, p.isBestSeller, p.isNew, p.stock, id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to update product.' });
    }
});

app.delete('/api/products/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('DELETE FROM products WHERE id=$1', [id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete product.' });
    }
});

// --- CATEGORY CRUD ROUTES ---

app.get('/api/categories', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM categories ORDER BY name ASC');
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch categories.' });
    }
});

app.post('/api/categories', async (req, res) => {
    const { id, name, slug, image } = req.body;
    try {
        await pool.query('INSERT INTO categories (id, name, slug, image) VALUES ($1, $2, $3, $4)', [id, name, slug, image]);
        res.status(201).json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to create category.' });
    }
});

app.delete('/api/categories/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('DELETE FROM categories WHERE id=$1', [id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete category.' });
    }
});

// --- ORDER ROUTES ---

app.post('/api/orders', async (req, res) => {
    const { items, total, customer, paymentIntentId } = req.body;
    try {
        const result = await pool.query(
            'INSERT INTO orders (customer_email, total, items, status, payment_intent_id) VALUES ($1, $2, $3, $4, $5) RETURNING id',
            [customer.email, total, JSON.stringify(items), 'Processing', paymentIntentId]
        );
        res.status(201).json({ success: true, orderId: result.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: 'Order placement failed.' });
    }
});

// --- REVIEW ROUTES (REAL WORLD IMPLEMENTATION) ---

// Public: Get Reviews for a Product (Approved Only)
app.get('/api/products/:id/reviews', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query(
            'SELECT * FROM reviews WHERE product_id = $1 AND status = $2 ORDER BY created_at DESC', 
            [id, 'approved']
        );
        // Map database columns to frontend Review type
        const formatted = result.rows.map(r => ({
            id: r.id.toString(),
            productId: r.product_id,
            productName: r.product_name,
            userName: r.user_name,
            rating: r.rating,
            comment: r.comment,
            status: r.status,
            date: new Date(r.created_at).toLocaleDateString()
        }));
        res.json(formatted);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch reviews.' });
    }
});

// Admin: Get All Reviews
app.get('/api/admin/reviews', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM reviews ORDER BY created_at DESC');
        const formatted = result.rows.map(r => ({
            id: r.id.toString(),
            productId: r.product_id,
            productName: r.product_name,
            userName: r.user_name,
            rating: r.rating,
            comment: r.comment,
            status: r.status,
            date: new Date(r.created_at).toLocaleDateString()
        }));
        res.json(formatted);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch reviews.' });
    }
});

// User: Create Review
app.post('/api/reviews', async (req, res) => {
    const { productId, productName, userName, rating, comment } = req.body;
    try {
        await pool.query(
            'INSERT INTO reviews (product_id, product_name, user_name, rating, comment) VALUES ($1, $2, $3, $4, $5)',
            [productId, productName, userName, rating, comment]
        );
        res.status(201).json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to submit review.' });
    }
});

// Admin: Update Review Status
app.put('/api/admin/reviews/:id/status', async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    try {
        await pool.query('UPDATE reviews SET status = $1 WHERE id = $2', [status, id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to update review status.' });
    }
});

app.get('/health', (req, res) => res.status(200).json({ status: 'Operational', mode: 'High-Performance' }));

app.listen(PORT, () => console.log(`Luzaan API Gateway Online: Port ${PORT}`));
