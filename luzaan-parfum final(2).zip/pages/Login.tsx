
import React, { useState, useEffect } from 'react';
// @ts-ignore
import { Link, useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useShop } from '../context/ShopContext';
import { useLanguage } from '../context/LanguageContext';
import { GlassCard } from '../components/GlassCard';
import { Loader2, Eye, EyeOff, ShieldAlert, Key, X, ArrowRight, Check, Sparkles, Lock } from 'lucide-react';
import { AuraLoader } from '../components/AuraLoader';
import { AnimatePresence, motion } from 'framer-motion';
import { Logo } from '../components/Logo';

export const Login: React.FC = () => {
  const { login, loginWithGoogle, requestPasswordReset, isLoading, isAuthenticated, user } = useAuth();
  const { addCustomer, claimPendingCart, storeSettings } = useShop();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  
  // Forgot Password State
  const [isForgotOpen, setIsForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotStatus, setForgotStatus] = useState<'idle' | 'success'>('idle');
  const [recoveryMessage, setRecoveryMessage] = useState('');

  // REDIRECT IF ALREADY LOGGED IN
  if (isAuthenticated) {
    return <Navigate to={user?.role === 'admin' ? '/admin' : '/account'} replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (email && password) {
      try {
          const loggedInUser = await login(email, password);
          
          if (loggedInUser) {
            addCustomer(loggedInUser); 
            claimPendingCart();
            setTimeout(() => {
              if (loggedInUser.role === 'admin') navigate('/admin');
              else navigate('/account');
            }, 500);
          }
      } catch (err: any) {
          setErrorMsg(err.message || "Authentication failed. Please verify your credentials.");
      }
    }
  };

  const handleGoogleLogin = async () => {
    const user = await loginWithGoogle();
    addCustomer(user);
    claimPendingCart();
    navigate('/account');
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!forgotEmail.includes('@')) return;
      
      const result = await requestPasswordReset(forgotEmail);
      setRecoveryMessage(result.message);
      setForgotStatus('success');
  };

  const inputClasses = "w-full bg-stone-50 border border-stone-200 p-4 rounded-xl text-sm text-brand-black font-medium outline-none focus:border-brand-black focus:bg-white transition-all placeholder-stone-400";

  return (
    <div className="min-h-screen flex items-center justify-center relative bg-brand-cream overflow-hidden px-6 py-20 font-sans">
      <AnimatePresence>
        {isLoading && <AuraLoader text="Accessing Archive..." fullScreen={true} />}
      </AnimatePresence>

      {/* Ambient Background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <motion.div 
            animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1] }}
            transition={{ duration: 10, repeat: Infinity }}
            className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-brand-gold/10 rounded-full blur-[120px] mix-blend-multiply" 
          />
          <motion.div 
            animate={{ scale: [1, 1.1, 1], opacity: [0.1, 0.15, 0.1] }}
            transition={{ duration: 15, repeat: Infinity }}
            className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-brand-crimson/5 rounded-full blur-[120px] mix-blend-multiply" 
          />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-md bg-white/80 backdrop-blur-2xl border border-white/50 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)] rounded-[3rem] p-10 md:p-12 overflow-hidden"
      >
         {/* Decorative top accent */}
         <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-brand-gold/30 via-brand-crimson/30 to-brand-gold/30 opacity-50" />

         <div className="text-center mb-10">
            <div className="flex justify-center mb-8">
                <Logo size="text-3xl" />
            </div>
            <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
            >
                <h1 className="font-serif text-4xl text-brand-black italic mb-2">Member Access</h1>
                <p className="text-[9px] font-black uppercase tracking-[0.3em] text-stone-400">Enter the Archive</p>
            </motion.div>
         </div>

         {errorMsg && (
            <motion.div 
                initial={{ opacity: 0, height: 0 }} 
                animate={{ opacity: 1, height: 'auto' }}
                className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 flex items-start gap-3"
            >
                <ShieldAlert size={16} className="mt-0.5 shrink-0" />
                <p className="text-[10px] font-bold uppercase tracking-tight leading-relaxed">{errorMsg}</p>
            </motion.div>
         )}

         <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-widest text-stone-400 ml-1">Email Coordinates</label>
                <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={inputClasses}
                    placeholder="name@example.com"
                    required
                />
            </div>
            
            <div className="space-y-1">
                <div className="flex justify-between items-center ml-1">
                    <label className="text-[9px] font-black uppercase tracking-widest text-stone-400">Access Key</label>
                    <button 
                        type="button"
                        onClick={() => setIsForgotOpen(true)}
                        className="text-[9px] font-black uppercase text-brand-crimson hover:text-brand-black transition-colors"
                    >
                        Forgot?
                    </button>
                </div>
                <div className="relative group">
                    <input 
                        type={showPassword ? 'text' : 'password'} 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className={`${inputClasses} pr-12`}
                        placeholder="••••••••"
                        required
                    />
                    <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-300 hover:text-brand-black transition-colors"
                    >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                </div>
            </div>

            <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit" 
                disabled={isLoading}
                className="w-full bg-brand-black text-white py-4 font-black uppercase tracking-[0.4em] text-[10px] rounded-2xl shadow-xl hover:bg-brand-crimson transition-all duration-500 mt-4 flex items-center justify-center gap-3"
            >
                {isLoading ? <Loader2 className="animate-spin" size={16} /> : <span>Sign In</span>}
            </motion.button>
         </form>

         <div className="my-8 flex items-center gap-4">
            <div className="h-px bg-stone-100 flex-1"></div>
            <span className="text-[8px] text-stone-300 font-black uppercase tracking-widest">Or Authenticate With</span>
            <div className="h-px bg-stone-100 flex-1"></div>
         </div>

         <button 
            type="button"
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-full bg-white border border-stone-200 text-brand-black py-4 font-black uppercase tracking-[0.2em] text-[9px] hover:bg-stone-50 hover:border-stone-300 transition-all rounded-2xl flex items-center justify-center gap-3 shadow-sm active:scale-95"
         >
            <svg className="w-4 h-4" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
            Google Identity
         </button>

         <div className="mt-8 text-center pt-6 border-t border-stone-100">
            <p className="text-stone-400 text-[9px] font-black uppercase tracking-widest">
                New to the Archive?
                <Link to="/register" className="text-brand-black hover:text-brand-crimson transition-colors ml-2 border-b border-brand-black pb-0.5 hover:border-brand-crimson">
                  Request Access
                </Link>
            </p>
         </div>
      </motion.div>

      {/* RECOVERY RITUAL MODAL */}
      <AnimatePresence>
        {isForgotOpen && (
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-brand-black/60 backdrop-blur-md"
                onClick={() => setIsForgotOpen(false)}
            >
                <motion.div
                    initial={{ scale: 0.9, y: 20 }}
                    animate={{ scale: 1, y: 0 }}
                    exit={{ scale: 0.9, y: 20, opacity: 0 }}
                    onClick={(e) => e.stopPropagation()}
                    className="bg-[#F9F6F2] w-full max-w-sm rounded-[2.5rem] shadow-2xl p-10 relative overflow-hidden border border-white/20"
                >
                    <button 
                        onClick={() => setIsForgotOpen(false)} 
                        className="absolute top-6 right-6 text-stone-300 hover:text-brand-black transition-colors"
                    >
                        <X size={20} />
                    </button>

                    <div className="mb-8 text-center">
                        <motion.div 
                            initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: 'spring' }}
                            className="w-14 h-14 bg-brand-black text-brand-gold rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-xl"
                        >
                            <Lock size={24} />
                        </motion.div>
                        <h2 className="font-serif text-3xl text-brand-black mb-2 italic">Recovery</h2>
                        <p className="text-stone-500 text-[9px] font-black uppercase tracking-[0.3em]">Protocol Reset</p>
                    </div>

                    {forgotStatus === 'success' ? (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-center bg-white p-8 rounded-2xl border border-stone-100 shadow-sm">
                            <div className="w-12 h-12 bg-green-50 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                                <Sparkles size={24} />
                            </div>
                            <p className="text-stone-500 text-sm leading-relaxed italic mb-6 font-serif">
                                "{recoveryMessage}"
                            </p>
                            <Link 
                                to={`/reset-password?email=${encodeURIComponent(forgotEmail)}&token=simulated_token_123`}
                                className="text-brand-crimson text-[9px] font-black uppercase tracking-widest hover:underline block"
                            >
                                Open Simulated Link
                            </Link>
                        </motion.div>
                    ) : (
                        <form onSubmit={handleForgotSubmit} className="space-y-6">
                            <div>
                                <label className="block text-[9px] font-black uppercase tracking-widest text-stone-400 mb-2">Email Address</label>
                                <input 
                                    type="email" 
                                    value={forgotEmail}
                                    onChange={(e) => setForgotEmail(e.target.value)}
                                    className={inputClasses}
                                    placeholder="email@example.com"
                                    required
                                />
                            </div>
                            <motion.button 
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                type="submit" 
                                disabled={isLoading}
                                className="w-full bg-brand-black text-white py-4 font-black uppercase tracking-[0.4em] text-[10px] hover:bg-brand-crimson transition-all duration-500 rounded-2xl shadow-xl flex items-center justify-center active:scale-95"
                            >
                                {isLoading ? <Loader2 className="animate-spin" size={16} /> : 'Send Recovery Scroll'}
                            </motion.button>
                        </form>
                    )}
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
