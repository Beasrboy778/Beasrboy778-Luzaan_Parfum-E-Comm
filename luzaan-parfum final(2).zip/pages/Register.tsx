
import React, { useState, useRef, useEffect } from 'react';
// @ts-ignore
import { Link, useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useShop } from '../context/ShopContext';
import { useLanguage } from '../context/LanguageContext';
import { useCurrency } from '../context/CurrencyContext';
import { GlassCard } from '../components/GlassCard';
import { Loader2, Eye, EyeOff, Globe, Check, ShieldCheck, Info, ChevronDown, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { AuraLoader } from '../components/AuraLoader';
import { Logo } from '../components/Logo';

export const Register: React.FC = () => {
  const { register, loginWithGoogle, isLoading, isAuthenticated, user } = useAuth();
  const { addCustomer, claimPendingCart, storeSettings } = useShop();
  const { t } = useLanguage();
  const { setCountry } = useCurrency();
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [region, setRegion] = useState('United States');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const countries = [
    "Argentina", "Australia", "Austria", "Bahrain", "Belgium", "Brazil", "Canada", 
    "China", "Denmark", "Finland", "France", "Germany", "Greece", "Hong Kong", 
    "India", "Ireland", "Italy", "Japan", "Kuwait", "Mexico", "Netherlands", 
    "New Zealand", "Norway", "Portugal", "Qatar", "Saudi Arabia", "Singapore", 
    "South Africa", "South Korea", "Spain", "Sweden", "Switzerland", 
    "United Arab Emirates", "United Kingdom", "United States"
  ];

  // Handle clicks outside the dropdown to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
            setIsDropdownOpen(false);
        }
    };

    if (isDropdownOpen) {
        document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isDropdownOpen]);

  // REDIRECT IF ALREADY LOGGED IN
  if (isAuthenticated) {
    return <Navigate to={user?.role === 'admin' ? '/admin' : '/account'} replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Pre-flight check
    if (password.length < 6) {
        setError('Security: Password must contain at least 6 characters.');
        return;
    }

    if (name.trim().split(' ').length < 2) {
        setError('Registration: Please provide your full name (First and Last).');
        return;
    }

    try {
        if (email && password && name) {
          const newUser = await register(name, email, region, password);
          addCustomer(newUser); 
          
          const supportedCountries = ['United States', 'United Kingdom', 'India', 'Canada', 'Australia'];
          const isEurope = ['France', 'Germany', 'Italy', 'Spain', 'Netherlands', 'Belgium', 'Austria', 'Portugal', 'Greece', 'Ireland', 'Finland'].includes(region);
          
          if (supportedCountries.includes(region)) {
              setCountry(region as any);
          } else if (isEurope) {
              setCountry('Europe' as any);
          } else {
              setCountry('United States' as any);
          }

          claimPendingCart();
          setShowWelcome(true);
          setTimeout(() => navigate('/account'), 3500);
        }
    } catch (err: any) {
        setError(err.message || 'Registration failed.');
    }
  };

  const handleGoogleLogin = async () => {
    const newUser = await loginWithGoogle();
    addCustomer(newUser); 
    setCountry(newUser.region as any || 'United States');
    claimPendingCart();
    navigate('/account');
  };

  const glassInputClass = "w-full bg-white border border-stone-200 p-3.5 rounded-xl text-sm text-brand-black outline-none focus:border-brand-black transition-all shadow-sm placeholder-stone-400 font-sans";

  return (
    <div className="min-h-screen pt-32 pb-24 px-6 flex items-center justify-center relative bg-brand-cream text-brand-black">
      <AnimatePresence>
        {isLoading && <AuraLoader text="Creating account..." fullScreen={true} />}
      </AnimatePresence>

      <div className="absolute top-1/3 left-1/3 w-[500px] h-[500px] bg-brand-gold/5 rounded-full blur-[120px] pointer-events-none" />

      <GlassCard className="p-8 max-w-lg w-full relative z-10 border border-white/40 shadow-2xl rounded-[2.5rem]">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
             <Logo size="text-2xl" />
          </div>
          <h1 className="font-serif font-bold text-3xl text-brand-black mb-1">Join {storeSettings.storeName}</h1>
          <p className="text-stone-500 text-[9px] font-black uppercase tracking-[0.4em] opacity-60">Begin your sensory journey</p>
        </div>

        {error && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-[10px] font-bold uppercase tracking-tight flex items-start gap-3 shadow-sm">
                <Info size={14} strokeWidth={3} className="shrink-0 mt-0.5" />
                {error}
            </motion.div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[9px] font-black uppercase tracking-widest text-stone-400 mb-1.5">Full Name</label>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} className={glassInputClass} placeholder="Full Name" required />
              </div>
              <div>
                <label className="block text-[9px] font-black uppercase tracking-widest text-stone-400 mb-1.5">Email</label>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={glassInputClass} placeholder="email@example.com" required />
              </div>
          </div>
          
          <div className="relative z-50" ref={dropdownRef}>
            <label className="block text-[9px] font-black uppercase tracking-widest text-stone-400 mb-2 flex items-center gap-2">
                <Globe size={11} /> Region
            </label>
            <div className="relative">
                <button type="button" onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className={`${glassInputClass} flex items-center justify-between cursor-pointer text-left`}>
                    <span className={region ? "text-brand-black" : "text-stone-400"}>{region}</span>
                    <ChevronDown size={14} className={`text-stone-400 transition-transform duration-300 ${isDropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                <AnimatePresence>
                    {isDropdownOpen && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                            className="absolute top-full left-0 right-0 mt-2 bg-white border border-stone-200 rounded-xl shadow-xl max-h-48 overflow-y-auto custom-scrollbar z-[60]">
                            <div className="p-1.5 space-y-1">
                                {countries.map((c) => (
                                    <button key={c} type="button" onClick={() => { setRegion(c); setIsDropdownOpen(false); }}
                                        className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-all ${region === c ? 'bg-brand-black text-white' : 'hover:bg-stone-50'}`}>
                                        {c}
                                    </button>
                                ))}
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
          </div>

          <div>
            <label className="block text-[9px] font-black uppercase tracking-widest text-stone-400 mb-1.5">Password</label>
            <div className="relative">
              <input type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} className={`${glassInputClass} pr-12`} placeholder="••••••••" required />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-300 hover:text-brand-black transition-colors p-2">
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <button type="submit" disabled={isLoading} className="w-full bg-brand-black text-white py-4 font-black uppercase tracking-[0.4em] text-[10px] hover:bg-brand-crimson transition-all duration-700 rounded-xl shadow-2xl active:scale-95 group overflow-hidden relative">
            Create Profile
          </button>
        </form>

        <div className="my-6 flex items-center gap-4">
            <div className="h-px bg-stone-200 flex-1 opacity-50"></div>
            <span className="text-[9px] text-stone-300 font-black uppercase tracking-widest">Or</span>
            <div className="h-px bg-stone-200 flex-1 opacity-50"></div>
        </div>

        <button type="button" onClick={handleGoogleLogin} disabled={isLoading} className="w-full bg-white border border-stone-200 text-brand-black py-3.5 font-black uppercase tracking-[0.2em] text-[9px] hover:bg-stone-50 transition-all rounded-xl flex items-center justify-center gap-3 shadow-sm active:scale-95">
            Google Account
        </button>

        <div className="mt-8 text-center border-t border-stone-100 pt-6">
          <p className="text-stone-400 text-[9px] font-black uppercase tracking-widest">
            {t('auth.haveAccount')}
            <Link to="/login" className="text-brand-crimson font-black hover:underline transition-colors ml-2 tracking-widest uppercase">
              Login
            </Link>
          </p>
        </div>
      </GlassCard>

      <AnimatePresence>
        {showWelcome && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-brand-black/60 backdrop-blur-xl">
                <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }}
                    className="bg-[#F9F6F2] w-full max-w-sm rounded-[2.5rem] p-8 text-center border border-white/20 shadow-2xl">
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="w-16 h-16 bg-brand-black text-brand-gold rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                        <Sparkles size={28} />
                    </motion.div>
                    <h2 className="font-display font-bold text-2xl lg:text-3xl text-brand-black mb-3 leading-tight">Welcome, {name.split(' ')[0]}</h2>
                    <p className="text-stone-500 text-[10px] font-black uppercase tracking-[0.2em] mb-6 leading-relaxed">
                        Congratulations. You are now logged in to our site.
                    </p>
                    <div className="h-1 bg-stone-100 rounded-full overflow-hidden mx-auto max-w-[150px]">
                        <motion.div initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 2.5 }} className="h-full bg-brand-black" />
                    </div>
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
