
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wind, Droplet, Sun, Moon, RefreshCcw, Heart, Sparkles, Flame, Mountain, Waves, Zap, Star } from 'lucide-react';
// @ts-ignore
import { Link } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { AuraLoader } from '../components/AuraLoader';

export const ScentDiscovery: React.FC = () => {
  const [step, setStep] = useState(0);
  const { products } = useShop();
  const [selections, setSelections] = useState<string[]>([]);
  const [recommendation, setRecommendation] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const steps = [
    {
      title: "When do you want to wear it?",
      options: [
        { id: 'day', label: 'Daytime', icon: Sun, desc: 'Fresh and light for work or sun.' },
        { id: 'night', label: 'Nighttime', icon: Moon, desc: 'Strong and sweet for dinner or parties.' },
        { id: 'any', label: 'Anytime', icon: Sparkles, desc: 'Good for every part of your day.' }
      ]
    },
    {
      title: "How do you want to feel?",
      options: [
        { id: 'bold', label: 'Strong & Bold', icon: Wind, desc: 'Smells of wood, leather, and spices.' },
        { id: 'romantic', label: 'Sweet & Floral', icon: Heart, desc: 'Smells of fresh roses and jasmine.' },
        { id: 'minimal', label: 'Clean & Simple', icon: Droplet, desc: 'Soft smells that are not too strong.' }
      ]
    },
    {
      title: "How do you want to be remembered?",
      options: [
        { id: 'whisper', label: 'A Whisper', icon: Zap, desc: 'A scent that only those very close can notice.' },
        { id: 'presence', label: 'A Presence', icon: Star, desc: 'A clean trail that follows you through the room.' },
        { id: 'legacy', label: 'A Legacy', icon: Sparkles, desc: 'A powerful scent that lingers long after you leave.' }
      ]
    },
    {
      title: "Which environment inspires you?",
      options: [
        { id: 'fire', label: 'Warm & Spicy', icon: Flame, desc: 'Like a warm fireplace or a bustling spice market.' },
        { id: 'earth', label: 'Fresh Earth', icon: Mountain, desc: 'Like wet grass, moss, and deep ancient wood.' },
        { id: 'water', label: 'Pure Water', icon: Waves, desc: 'Like the sea breeze, rain, and fresh mountain air.' }
      ]
    }
  ];

  const handleSelect = (id: string) => {
      const newSelections = [...selections, id];
      setSelections(newSelections);
      if (step < steps.length - 1) {
          setStep(step + 1);
      } else {
          setIsAnalyzing(true);
          setTimeout(() => {
            const recommended = products.find(p => {
                const notesStr = [...p.notes.top, ...p.notes.heart, ...p.notes.base].join(' ').toLowerCase();
                if (newSelections.includes('fire') && (notesStr.includes('amber') || notesStr.includes('smoke'))) return true;
                if (newSelections.includes('earth') && (notesStr.includes('vetiver') || notesStr.includes('sandalwood'))) return true;
                if (newSelections.includes('bold') && p.category === 'Men') return true;
                if (newSelections.includes('romantic') && p.category === 'Women') return true;
                return false;
            }) || products[0];
            setRecommendation(recommended);
            setStep(step + 1);
            setIsAnalyzing(false);
          }, 2500);
      }
  };

  const reset = () => { setStep(0); setSelections([]); setRecommendation(null); };

  return (
    <div className="pt-40 pb-32 px-8 min-h-screen bg-brand-cream animate-fade-in">
        <div className="max-w-ultra mx-auto">
            <div className="text-center mb-24 space-y-6">
                <span className="text-[10px] font-black uppercase tracking-[0.8em] text-brand-gold block">Olfactory Ritual</span>
                <h1 className="font-serif text-5xl md:text-7xl text-brand-black italic tracking-tighter">Scent Discovery</h1>
            </div>

            <div className="max-w-5xl mx-auto glass-premium p-12 md:p-16 rounded-[4rem] border-white shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-stone-100">
                    <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(step/steps.length) * 100}%` }}
                        className="h-full bg-brand-crimson transition-all duration-1000"
                    />
                </div>

                <AnimatePresence mode="wait">
                    {step < steps.length ? (
                        <motion.div key={step} initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-16">
                            <h2 className="text-4xl font-serif mb-12 text-brand-black text-center italic">{steps[step].title}</h2>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                                {steps[step].options.map(opt => (
                                    <button 
                                        key={opt.id} 
                                        onClick={() => handleSelect(opt.id)} 
                                        className="p-10 bg-white/40 border-2 border-white hover:border-brand-black hover:bg-white rounded-[3rem] text-center group transition-all duration-500 hover:shadow-2xl active:scale-95"
                                    >
                                        <opt.icon size={48} strokeWidth={1} className="mx-auto mb-8 text-stone-300 group-hover:text-brand-crimson transition-all duration-500" />
                                        <h4 className="font-bold text-lg uppercase tracking-widest text-brand-black mb-4">{opt.label}</h4>
                                        <p className="text-[10px] text-stone-400 font-medium leading-relaxed italic">{opt.desc}</p>
                                    </button>
                                ))}
                            </div>
                        </motion.div>
                    ) : (
                        recommendation && (
                          <motion.div key="result" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center max-w-2xl mx-auto">
                              <h2 className="font-serif text-5xl mb-4 text-brand-black italic">Your Olfactory Soulmate</h2>
                              <p className="text-stone-400 text-[10px] font-black uppercase tracking-[0.6em] mb-16">Matched to your signature</p>
                              
                              <div className="space-y-12">
                                   <motion.div 
                                        whileHover={{ scale: 1.05 }}
                                        className="aspect-square bg-white rounded-[4rem] p-16 shadow-2xl border border-stone-100 mb-10 flex items-center justify-center relative overflow-hidden max-w-sm mx-auto"
                                    >
                                       <div className="absolute inset-0 bg-gradient-to-tr from-brand-gold/15 to-transparent pointer-events-none" />
                                       <img src={recommendation.images[0]} alt="" className="w-full h-full object-contain drop-shadow-[0_40px_80px_rgba(0,0,0,0.15)]" />
                                   </motion.div>
                                   <div>
                                       <h3 className="font-serif text-4xl text-brand-black mb-4 italic">{recommendation.name}</h3>
                                       <p className="text-stone-500 text-xl italic mb-12 font-light leading-relaxed">"{recommendation.tagline}"</p>
                                   </div>
                                   <div className="flex flex-col gap-6">
                                       <Link to={`/product/${recommendation.id}`} className="w-full py-6 bg-brand-black text-white rounded-full font-black uppercase tracking-[0.5em] text-[10px] shadow-2xl hover:bg-brand-crimson transition-all active:scale-95">Enter Private View</Link>
                                       <button onClick={reset} className="flex items-center justify-center gap-3 text-[9px] font-black uppercase tracking-[0.4em] text-stone-400 hover:text-brand-black transition-colors"><RefreshCcw size={16} /> Re-start Ritual</button>
                                   </div>
                              </div>
                          </motion.div>
                        )
                    )}
                </AnimatePresence>
            </div>
        </div>
    </div>
  );
};
