
import React from 'react';
// @ts-ignore
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useCurrency } from '../context/CurrencyContext';
import { Order } from '../types';
import { AnimatedCheckmark } from '../components/AnimatedIcons';
import { Package, CreditCard, Banknote } from 'lucide-react';

export const OrderConfirmation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { formatPrice } = useCurrency();
  
  // Retrieve order object passed from Checkout state
  const order = location.state?.order as Order | undefined;

  if (!order) {
      return (
          <div className="min-h-screen pt-32 text-center bg-brand-cream">
              <h1 className="text-2xl font-serif">No order details found.</h1>
              <Link to="/shop" className="text-brand-crimson underline mt-4 block">Return to Shop</Link>
          </div>
      );
  }

  const breakdown = (order as any).breakdown || {};
  const subtotal = breakdown.subtotal || order.total;
  const codFee = breakdown.codFee || 0;
  const paymentMethodDisplay = (order as any).paymentMethod || 'Online Payment';

  const handleTrackOrder = () => {
      navigate('/account', { state: { focusOrderId: order.id } });
  };

  return (
    <div className="min-h-screen pt-32 pb-24 px-6 bg-brand-cream flex items-center justify-center text-center font-sans">
      <div className="max-w-lg mx-auto animate-slide-up w-full">
        <div className="flex justify-center mb-6">
          <AnimatedCheckmark size={80} className="text-green-600" />
        </div>
        <h1 className="font-serif text-4xl md:text-5xl mb-4 text-brand-black tracking-wide italic">Thank You</h1>
        <p className="text-xl text-stone-600 mb-8 font-light">Your order has been placed successfully.</p>
        
        <div className="bg-white p-8 shadow-xl mb-8 text-left border border-stone-100 relative overflow-hidden rounded-[2rem]">
           {/* Decorative Header */}
           <div className="flex justify-between items-start mb-8 pb-6 border-b border-stone-100">
               <div>
                   <p className="text-[10px] text-stone-400 mb-1 font-black uppercase tracking-[0.3em]">Luzaan Parfum</p>
                   <p className="font-serif text-2xl text-brand-black">{order.id}</p>
                   <p className="text-xs text-stone-400 mt-1">{order.date}</p>
               </div>
               <div className="text-right">
                   <p className="text-[10px] text-stone-400 mb-1 font-black uppercase tracking-[0.3em]">Total Paid</p>
                   <p className="text-2xl text-brand-crimson font-serif font-bold">{formatPrice(order.total)}</p>
               </div>
           </div>
           
           {/* Items List */}
           <div className="space-y-4 mb-8">
             {order.items.map((item, idx) => (
                 <div key={idx} className="flex items-center gap-4 text-stone-700">
                    <div className="w-14 h-14 rounded-xl bg-stone-50 overflow-hidden flex-shrink-0 border border-stone-100 p-1 flex items-center justify-center">
                        {item.images && item.images.length > 0 ? (
                            <img src={item.images[0]} className="w-full h-full object-contain" alt={item.name} />
                        ) : (
                            <Package size={20} className="text-stone-300" />
                        )}
                    </div>
                    <div className="flex-1">
                        <span className="font-serif block text-lg font-bold text-brand-black leading-none mb-1">{item.name}</span>
                        <span className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">{item.size} • Qty {item.quantity}</span>
                    </div>
                    <span className="text-sm font-bold text-brand-black">{formatPrice(item.price * item.quantity)}</span>
                 </div>
             ))}
           </div>

           {/* Cost Breakdown */}
           <div className="bg-stone-50 rounded-xl p-6 border border-stone-100 space-y-3 mb-8">
                <div className="flex justify-between text-xs text-stone-500 font-medium">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal)}</span>
                </div>
                {breakdown.shipping > 0 ? (
                    <div className="flex justify-between text-xs text-stone-500 font-medium">
                        <span>Shipping</span>
                        <span>{formatPrice(breakdown.shipping)}</span>
                    </div>
                ) : (
                    <div className="flex justify-between text-xs text-stone-500 font-medium">
                        <span>Shipping</span>
                        <span>Free</span>
                    </div>
                )}
                {codFee > 0 && (
                    <div className="flex justify-between text-xs text-brand-black font-bold">
                        <span>COD Fee</span>
                        <span>{formatPrice(codFee)}</span>
                    </div>
                )}
                <div className="flex justify-between text-sm font-bold text-brand-black pt-3 border-t border-stone-200 mt-2">
                    <span>Total</span>
                    <span>{formatPrice(order.total)}</span>
                </div>
           </div>

           {/* Payment & Shipping Info */}
           <div className="grid grid-cols-2 gap-6 text-sm text-stone-600">
               <div>
                   <p className="font-black uppercase tracking-widest text-[9px] text-stone-400 mb-2">Shipping To</p>
                   <p className="font-bold text-brand-black">{order.customer.name}</p>
                   {order.shippingAddress && (
                       <p className="text-xs leading-relaxed mt-1">
                        {order.shippingAddress.street}<br/>
                        {order.shippingAddress.city}, {order.shippingAddress.zip}<br/>
                        {order.shippingAddress.country}
                       </p>
                   )}
               </div>
               <div className="text-right">
                   <p className="font-black uppercase tracking-widest text-[9px] text-stone-400 mb-2">Payment Method</p>
                   <div className="inline-flex items-center gap-2 bg-stone-100 px-3 py-1.5 rounded-lg">
                        {paymentMethodDisplay.includes('Cash') ? <Banknote size={14} className="text-brand-black"/> : <CreditCard size={14} className="text-brand-black"/>}
                        <span className="text-xs font-bold text-brand-black">{paymentMethodDisplay}</span>
                   </div>
               </div>
           </div>

           <p className="text-stone-400 text-[10px] mt-8 text-center font-bold uppercase tracking-widest pt-6 border-t border-stone-100">
             Confirmation sent to {order.customer.email}
           </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button 
            onClick={handleTrackOrder}
            className="px-8 py-4 border border-brand-black text-brand-black uppercase text-[10px] font-black tracking-[0.3em] hover:bg-brand-black hover:text-white transition-colors rounded-xl"
          >
            Track Order
          </button>
          <Link 
            to="/shop" 
            className="px-8 py-4 bg-brand-black text-white uppercase text-[10px] font-black tracking-[0.3em] hover:bg-brand-crimson transition-colors rounded-xl shadow-xl"
          >
            Continue Shopping
          </Link>
        </div>
      </div>
    </div>
  );
};
