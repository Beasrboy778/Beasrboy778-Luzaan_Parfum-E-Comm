
import React from 'react';
import { Plus, Minus } from 'lucide-react';

const FAQItem = ({ question, answer }: { question: string, answer: string }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <div className="border-b border-brand-black/10">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center py-6 text-left group"
      >
        <span className="font-serif text-lg text-brand-black group-hover:text-stone-600 transition-colors">{question}</span>
        <span className="text-stone-400">
          {isOpen ? <Minus size={20} /> : <Plus size={20} />}
        </span>
      </button>
      <div 
        className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96 opacity-100 pb-6' : 'max-h-0 opacity-0'}`}
      >
        <p className="text-stone-600 leading-relaxed text-sm md:text-base pr-8">
          {answer}
        </p>
      </div>
    </div>
  );
};

export const FAQ: React.FC = () => {
  return (
    <div className="pt-32 pb-24 px-6 max-w-3xl mx-auto animate-fade-in">
      <div className="text-center mb-16">
        <h1 className="font-serif text-4xl md:text-5xl mb-4 text-brand-black">Common Questions</h1>
        <p className="text-stone-500">Answers to your most frequent inquiries.</p>
      </div>

      <div className="space-y-2">
        <FAQItem 
          question="Are your fragrances natural?" 
          answer="We prioritize natural ingredients wherever possible. Our Attar collection is 100% natural pure oil. For our Eau de Parfum range, we use a blend of high-quality naturals and safe synthetics to ensure longevity and stability, always free from phthalates and parabens." 
        />
        <FAQItem 
          question="How long does shipping take?" 
          answer="Standard shipping within the US takes 5-7 business days. International shipping typically ranges from 7-14 business days depending on customs processing in your country." 
        />
        <FAQItem 
          question="Do you offer samples?" 
          answer="Yes! We offer a 'Discovery Set' which includes 2ml vials of our entire core collection. This allows you to experience the scents on your skin before committing to a full-sized bottle." 
        />
        <FAQItem 
          question="Is the packaging recyclable?" 
          answer="Absolutely. Sustainability is a core pillar of Aura. Our glass bottles are recyclable (and refillable!), and our outer boxes are made from FSC-certified paper with vegetable-based inks." 
        />
        <FAQItem 
          question="How should I store my perfume?" 
          answer="To preserve the integrity of the fragrance, store your bottle in a cool, dry place away from direct sunlight and extreme temperature fluctuations. A drawer or closet is ideal." 
        />
        <FAQItem 
          question="What is the difference between Attar and Eau de Parfum?" 
          answer="Attar is a highly concentrated perfume oil, traditionally alcohol-free, offering a more intimate, long-lasting scent that stays close to the skin. Eau de Parfum contains alcohol, which helps the scent project further (sillage) and evolve more noticeably over time." 
        />
      </div>
    </div>
  );
};
