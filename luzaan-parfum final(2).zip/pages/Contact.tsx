
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useShop } from '../context/ShopContext';
import { Loader2, Mail, MapPin, Phone, Clock, ArrowRight, Lock, LogIn } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { GlassCard } from '../components/GlassCard';

export const Contact: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { sendContactMessage, designSettings, storeSettings } = useShop();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
      name: user ? user.name : '',
      email: user ? user.email : '',
      subject: 'General Inquiry',
      message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsSubmitting(true);
      const result = await sendContactMessage(formData);
      if (result) {
          setSuccess(true);
          setFormData({ ...formData, message: '', subject: 'General Inquiry' });
      }
      setIsSubmitting(false);
  };

  const inputClass = "w-full bg-white border border-stone-200 p-4 rounded-xl text-sm text-brand-black outline-none focus:border-brand-black transition-all placeholder-stone-400 font-sans";

  return (
    <div className="pt-40 pb-24 px-6 max-w-7xl mx-auto animate-fade-in bg-brand-cream text-brand-black min-h-screen relative">
        {/* Dynamic Background if set */}
        {designSettings.contactBgImage && (
            <div className="absolute inset-0 z-0 opacity-10 pointer-events-none">
                <img src={designSettings.contactBgImage} className="w-full h-full object-cover" alt="" />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-cream via-transparent to-transparent" />
            </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 relative z-10">
            
            {/* Left Info */}
            <div className="space-y-12">
                <div>
                    <span className="text-brand-crimson font-black text-[10px] tracking-[0.3em] uppercase mb-4 block">Concierge Service</span>
                    <h1 className="font-serif font-bold text-5xl md:text-7xl mb-6 text-brand-black">{designSettings.contactTitle || "Get in Touch"}</h1>
                    <p className="text-stone-500 text-lg font-serif italic max-w-md">
                        {designSettings.contactSubtitle || '"Scent is the most intense form of memory." Allow us to help you find yours.'}
                    </p>
                </div>

                <div className="space-y-8">
                    <div className="flex items-start gap-6 p-6 bg-white/50 border border-white rounded-[2rem] shadow-sm backdrop-blur-sm">
                        <div className="w-12 h-12 bg-brand-black text-brand-cream rounded-full flex items-center justify-center shrink-0">
                            <MapPin size={20} />
                        </div>
                        <div>
                            <h3 className="font-serif font-bold text-lg mb-2">{designSettings.contactSection1Title || "Flagship Atelier"}</h3>
                            <p className="text-stone-500 text-sm font-sans leading-relaxed">
                                {storeSettings.contactDetails.addressLine1 || "123 Perfume Lane, Le Marais"}<br/>
                                {storeSettings.contactDetails.addressLine2 || "Paris, France 75001"}
                            </p>
                        </div>
                    </div>

                    <div className="flex items-start gap-6 p-6 bg-white/50 border border-white rounded-[2rem] shadow-sm backdrop-blur-sm">
                        <div className="w-12 h-12 bg-brand-black text-brand-cream rounded-full flex items-center justify-center shrink-0">
                            <Mail size={20} />
                        </div>
                        <div>
                            <h3 className="font-serif font-bold text-lg mb-2">{designSettings.contactSection2Title || "Digital Concierge"}</h3>
                            <p className="text-stone-500 text-sm font-sans mb-1">{storeSettings.supportEmail || "concierge@luzaan.com"}</p>
                            <p className="text-stone-500 text-sm font-sans">{storeSettings.contactDetails.phone || "+33 1 23 45 67 89"}</p>
                        </div>
                    </div>

                    <div className="flex items-start gap-6 p-6 bg-white/50 border border-white rounded-[2rem] shadow-sm backdrop-blur-sm">
                        <div className="w-12 h-12 bg-brand-black text-brand-cream rounded-full flex items-center justify-center shrink-0">
                            <Clock size={20} />
                        </div>
                        <div>
                            <h3 className="font-serif font-bold text-lg mb-2">{designSettings.contactSection3Title || "Operating Hours"}</h3>
                            <p className="text-stone-500 text-sm font-sans">{storeSettings.contactDetails.hours || "Mon-Fri: 9am - 6pm CET"}</p>
                            <p className="text-stone-500 text-sm font-sans">{storeSettings.contactDetails.hoursSat || "Sat: By Appointment Only"}</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right Form with Auth Gate */}
            <div className="bg-white/80 p-10 md:p-12 rounded-[3rem] shadow-xl border border-stone-100 relative overflow-hidden backdrop-blur-xl">
              <div className="absolute top-0 right-0 w-64 h-64 bg-brand-crimson/5 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2 pointer-events-none" />
              
              {!isAuthenticated ? (
                  <div className="text-center h-full flex flex-col items-center justify-center py-12 relative z-10">
                      <div className="w-20 h-20 bg-brand-black text-brand-gold rounded-[2rem] flex items-center justify-center mb-8 shadow-2xl">
                          <Lock size={32} />
                      </div>
                      <h2 className="font-serif text-3xl italic mb-4 text-brand-black">Concierge Authentication</h2>
                      <p className="text-stone-500 mb-10 max-w-xs font-serif italic">
                        To communicate with the archive concierge, we request that you authenticate your session.
                      </p>
                      <div className="w-full space-y-4">
                          <button 
                            onClick={() => navigate('/login', { state: { from: '/contact' } })}
                            className="w-full bg-brand-black text-white py-5 rounded-2xl font-black uppercase text-[10px] tracking-[0.4em] shadow-xl hover:bg-brand-crimson transition-all flex items-center justify-center gap-3"
                          >
                              <LogIn size={18} /> Member Login
                          </button>
                          <Link to="/register" className="block text-stone-400 font-black uppercase text-[9px] tracking-[0.3em] hover:text-brand-black transition-colors underline underline-offset-8">
                              Register for Access
                          </Link>
                      </div>
                  </div>
              ) : success ? (
                  <div className="text-center h-full flex flex-col items-center justify-center py-12">
                      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-8">
                          <Mail size={32} />
                      </div>
                      <h2 className="font-serif font-bold text-3xl mb-4">Message Received</h2>
                      <p className="text-stone-500 mb-10 max-w-xs font-serif italic">
                          Thank you for contacting us. Our concierge team will respond within 24 hours.
                      </p>
                      <button 
                          onClick={() => setSuccess(false)}
                          className="bg-brand-black text-white px-10 py-4 rounded-full text-xs font-black uppercase tracking-widest hover:bg-stone-800 transition-colors shadow-lg"
                      >
                          Send Another
                      </button>
                  </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
                  <h3 className="font-serif font-bold text-2xl text-brand-black mb-8">Send a Message</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Name</label>
                      <input name="name" value={formData.name} onChange={handleChange} required className={inputClass} placeholder="Your Name" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Email</label>
                      <input name="email" type="email" value={formData.email} onChange={handleChange} required className={inputClass} placeholder="email@example.com" />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Subject</label>
                    <select name="subject" value={formData.subject} onChange={handleChange} className={inputClass}>
                      <option>General Inquiry</option>
                      <option>Order Status</option>
                      <option>Wholesale</option>
                      <option>Private Consultation</option>
                    </select>
                  </div>
  
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Message</label>
                    <textarea name="message" value={formData.message} onChange={handleChange} required rows={6} className={`${inputClass} resize-none`} placeholder="How can we assist you today?" />
                  </div>
  
                  <button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="w-full bg-brand-black text-white py-5 font-black uppercase tracking-[0.3em] text-[10px] hover:bg-brand-crimson transition-all rounded-xl shadow-xl active:scale-95 flex items-center justify-center gap-3"
                  >
                    {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : <>Send Message <ArrowRight size={16} /></>}
                  </button>
                </form>
              )}
            </div>
        </div>
    </div>
  );
};
