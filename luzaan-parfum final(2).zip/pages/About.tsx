
import React from 'react';
import { motion } from 'framer-motion';
import { Droplet, Wind, Fingerprint, Anchor, Compass, Clock, Map } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const About: React.FC = () => {
  const { designSettings } = useShop();

  return (
    <div className="animate-fade-in bg-brand-cream text-brand-black font-sans">
      
      {/* HERO SECTION - PHILOSOPHY */}
      <div className="relative min-h-[70vh] flex items-center justify-center text-center px-6 overflow-hidden">
        <div className="absolute inset-0 bg-brand-black/30 z-10" />
        <img src={designSettings.aboutHeroImage} alt="Our Shop" className="absolute inset-0 w-full h-full object-cover" />
        
        <div className="relative z-20 max-w-4xl mx-auto space-y-8">
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 1 }}>
              <span className="text-[10px] font-black uppercase tracking-[0.6em] text-brand-gold mb-4 block">The Philosophy</span>
              <h1 className="font-serif font-bold text-6xl md:text-8xl text-brand-cream mb-6 italic leading-none">{designSettings.aboutTitle || "The Brand"}</h1>
              <div className="w-24 h-1 bg-brand-gold mx-auto mb-8" />
              <p className="text-brand-cream/90 text-xl md:text-2xl font-serif italic max-w-2xl mx-auto leading-relaxed">
                "{designSettings.aboutText || "We do not manufacture scents; we curate memories. Every bottle is a vessel of time, patience, and artistry."}"
              </p>
          </motion.div>
        </div>
      </div>

      {/* SECTION 1: THE BRAND VALUES (About Us) */}
      <section className="py-32 px-6">
          <div className="max-w-6xl mx-auto">
              <div className="text-center mb-20">
                  <h2 className="text-4xl font-serif font-bold mb-4">The Pillars of Luzaan</h2>
                  <p className="text-stone-500 max-w-lg mx-auto text-sm font-light">Defined by what we refuse to compromise on.</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                  <div className="p-10 bg-white rounded-[3rem] shadow-xl border border-stone-100 text-center group hover:-translate-y-2 transition-all duration-500">
                      <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center text-brand-gold mx-auto mb-8 group-hover:bg-brand-black group-hover:text-white transition-colors">
                          <Droplet size={32} strokeWidth={1} />
                      </div>
                      <h3 className="font-bold text-xl mb-4 font-serif italic">Pure Extracts</h3>
                      <p className="text-sm text-stone-500 leading-loose">We use only the highest grade absolutes. No synthetics used to cut costs, only to enhance longevity.</p>
                  </div>
                  <div className="p-10 bg-white rounded-[3rem] shadow-xl border border-stone-100 text-center group hover:-translate-y-2 transition-all duration-500">
                      <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center text-brand-gold mx-auto mb-8 group-hover:bg-brand-black group-hover:text-white transition-colors">
                          <Clock size={32} strokeWidth={1} />
                      </div>
                      <h3 className="font-bold text-xl mb-4 font-serif italic">Time as an Ingredient</h3>
                      <p className="text-sm text-stone-500 leading-loose">Our maceration process lasts 6 months. Like fine wine, true depth cannot be rushed.</p>
                  </div>
                  <div className="p-10 bg-white rounded-[3rem] shadow-xl border border-stone-100 text-center group hover:-translate-y-2 transition-all duration-500">
                      <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center text-brand-gold mx-auto mb-8 group-hover:bg-brand-black group-hover:text-white transition-colors">
                          <Fingerprint size={32} strokeWidth={1} />
                      </div>
                      <h3 className="font-bold text-xl mb-4 font-serif italic">Limited Batches</h3>
                      <p className="text-sm text-stone-500 leading-loose">Produced in micro-lots to ensure consistency and exclusivity for our patrons.</p>
                  </div>
              </div>
          </div>
      </section>

      {/* SECTION 2: THE ORIGIN (Our Story) - Visually Distinct */}
      <section className="bg-brand-black text-brand-cream py-32 relative overflow-hidden">
          {/* Background Texture */}
          <div className="absolute top-0 right-0 w-full h-full opacity-5 pointer-events-none">
              <Map size={800} strokeWidth={0.5} className="absolute -right-40 -top-40" />
          </div>

          <div className="max-w-6xl mx-auto px-6 relative z-10">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                  <div className="space-y-8">
                      <span className="text-brand-crimson font-black uppercase tracking-[0.6em] text-[10px] block">The Origin</span>
                      <h2 className="font-serif text-5xl md:text-7xl font-bold italic leading-none">A Journey Across Continents</h2>
                      
                      <div className="space-y-12 pt-8 border-l border-white/10 pl-8 ml-4">
                          <div className="relative">
                              <span className="absolute -left-[41px] top-1 w-5 h-5 rounded-full bg-brand-gold border-4 border-brand-black" />
                              <h4 className="text-xl font-bold mb-2 flex items-center gap-3"><Compass size={18} className="text-stone-400"/> Grasse, France</h4>
                              <p className="text-stone-400 font-light leading-relaxed">Where the techniques were mastered. Years spent learning the ancient art of enfleurage and distillation.</p>
                          </div>
                          <div className="relative">
                              <span className="absolute -left-[41px] top-1 w-5 h-5 rounded-full bg-stone-600 border-4 border-brand-black" />
                              <h4 className="text-xl font-bold mb-2 flex items-center gap-3"><Anchor size={18} className="text-stone-400"/> The Silk Road</h4>
                              <p className="text-stone-400 font-light leading-relaxed">Sourcing rare Oud from Assam and Saffron from Kashmir to bring an oriental depth to western structure.</p>
                          </div>
                          <div className="relative">
                              <span className="absolute -left-[41px] top-1 w-5 h-5 rounded-full bg-stone-600 border-4 border-brand-black" />
                              <h4 className="text-xl font-bold mb-2 flex items-center gap-3"><Wind size={18} className="text-stone-400"/> The Atelier</h4>
                              <p className="text-stone-400 font-light leading-relaxed">Today, Luzaan stands as a bridge between these worlds, crafting scents that tell the story of travel and time.</p>
                          </div>
                      </div>
                  </div>

                  <div className="relative aspect-[3/4] rounded-[4rem] overflow-hidden border border-white/10 shadow-2xl">
                      <div className="absolute inset-0 bg-brand-gold/10 mix-blend-overlay z-10" />
                      <img 
                        src="https://images.unsplash.com/photo-1555529733-0e670560f7e1?auto=format&fit=crop&w=800&q=80" 
                        alt="Vintage Perfumery" 
                        className="w-full h-full object-cover opacity-60 grayscale hover:grayscale-0 transition-all duration-1000"
                      />
                      <div className="absolute bottom-10 left-10 z-20">
                          <p className="text-[12px] font-black uppercase tracking-[0.4em] text-white">Est. 2003</p>
                      </div>
                  </div>
              </div>
          </div>
      </section>

    </div>
  );
};
