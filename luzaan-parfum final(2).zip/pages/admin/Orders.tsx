
import React, { useState, useEffect } from 'react';
import { Eye, Download, CheckCircle, XCircle, Clock, Truck, User, MapPin, Package, Calendar, CreditCard, ChevronRight, X, Printer, Send, Activity, ShieldCheck, Ruler, Tag, Search, Box, ArrowRight, Wand2, CheckCircle2, AlertCircle, Copy, Banknote } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Order } from '../../types';
import { useCurrency } from '../../context/CurrencyContext';
import { motion, AnimatePresence } from 'framer-motion';

export const Orders: React.FC = () => {
  const { adminOrders, updateOrderStatus } = useShop();
  const { formatPrice } = useCurrency();
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [trackingNumber, setTrackingNumber] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Lock scroll when modal is open
  useEffect(() => {
    if (selectedOrder) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => { document.body.style.overflow = 'unset'; };
  }, [selectedOrder]);

  const getFulfillmentStatus = (status: string) => {
      if (status === 'Processing') return 'Unfulfilled';
      if (status === 'Shipped') return 'In Transit';
      if (status === 'Delivered') return 'Completed';
      if (status === 'Cancelled') return 'Restocked';
      return 'Unfulfilled';
  };

  const getFulfillmentColor = (status: string) => {
      const fStatus = getFulfillmentStatus(status);
      if (fStatus === 'Unfulfilled') return 'bg-yellow-100 text-yellow-800';
      if (fStatus === 'In Transit') return 'bg-blue-100 text-blue-800';
      if (fStatus === 'Completed') return 'bg-green-100 text-green-800';
      if (fStatus === 'Restocked') return 'bg-red-100 text-red-800 line-through';
      return 'bg-stone-100 text-stone-600';
  };
  
  const filteredOrders = adminOrders.filter(o => 
      o.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
      o.customer.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const generateTracking = () => {
      const prefix = "TRK-IN";
      const timestamp = Date.now().toString().slice(-4);
      const random = Math.floor(100000 + Math.random() * 900000);
      setTrackingNumber(`${prefix}-${random}-${timestamp}`);
  };

  const handleDispatch = () => {
      if (selectedOrder) {
          const finalTracking = trackingNumber.trim() || `TRK-AUTO-${Date.now()}`;
          updateOrderStatus(selectedOrder.id, 'Shipped', finalTracking);
          setSelectedOrder(prev => prev ? { ...prev, status: 'Shipped', trackingNumber: finalTracking } : null);
      }
  };

  const handleConfirmDelivery = () => {
      if (selectedOrder) {
          updateOrderStatus(selectedOrder.id, 'Delivered');
          setSelectedOrder(prev => prev ? { ...prev, status: 'Delivered' } : null);
      }
  };

  const handleGenerateInvoice = () => {
      if (!selectedOrder) return;
      const invoiceWindow = window.open('', '_blank');
      if (!invoiceWindow) return;
      
      const breakdown = selectedOrder.breakdown || {};
      const subtotal = breakdown.subtotal || selectedOrder.total;
      const codFee = breakdown.codFee || 0;
      const tax = breakdown.tax || 0;
      const shipping = breakdown.shipping || 0;
      const discount = breakdown.discount || 0;

      const htmlContent = `
        <html>
          <head>
            <title>Invoice ${selectedOrder.id}</title>
            <style>
              body { font-family: 'Georgia', serif; padding: 40px; color: #1a1a1a; max-width: 800px; margin: 0 auto; }
              .header { display: flex; justify-content: space-between; border-bottom: 2px solid #000; padding-bottom: 20px; margin-bottom: 30px; align-items: flex-end; }
              .brand { font-size: 32px; font-weight: bold; letter-spacing: 2px; text-transform: uppercase; }
              .invoice-title { font-size: 14px; text-transform: uppercase; letter-spacing: 1px; color: #666; text-align: right; }
              .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; font-size: 14px; }
              .label { font-weight: bold; text-transform: uppercase; font-size: 10px; letter-spacing: 1px; color: #888; margin-bottom: 5px; }
              table { width: 100%; border-collapse: collapse; margin-bottom: 30px; font-size: 14px; }
              th { text-align: left; border-bottom: 1px solid #ccc; padding: 15px 0; text-transform: uppercase; font-size: 10px; letter-spacing: 1px; }
              td { padding: 15px 0; border-bottom: 1px solid #eee; }
              .totals { margin-left: auto; width: 300px; }
              .row { display: flex; justify-content: space-between; padding: 8px 0; }
              .row.final { border-top: 2px solid #000; padding-top: 15px; font-weight: bold; font-size: 18px; margin-top: 10px; }
              .footer { margin-top: 60px; text-align: center; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #888; }
            </style>
          </head>
          <body>
            <div class="header">
              <div class="brand">LUZAAN PARFUM</div>
              <div class="invoice-title">Official Receipt<br/>#${selectedOrder.id}</div>
            </div>
            
            <div class="meta-grid">
                <div>
                    <div class="label">Billed To</div>
                    <div><strong>${selectedOrder.customer.name}</strong></div>
                    <div>${selectedOrder.customer.email}</div>
                    ${selectedOrder.shippingAddress ? `<div>${selectedOrder.shippingAddress.street}<br/>${selectedOrder.shippingAddress.city}, ${selectedOrder.shippingAddress.country}</div>` : ''}
                </div>
                <div style="text-align: right;">
                    <div class="label">Order Date</div>
                    <div>${selectedOrder.date}</div>
                    <div class="label" style="margin-top: 15px;">Payment Method</div>
                    <div>${selectedOrder.paymentMethod || 'Credit Card'}</div>
                </div>
            </div>

            <table>
              <thead><tr><th>Item Description</th><th>Quantity</th><th>Unit Price</th><th>Total</th></tr></thead>
              <tbody>
                ${selectedOrder.items.map((i: any) => `<tr><td>${i.name}<br/><span style="font-size:10px;color:#666;">${i.size}</span></td><td>${i.quantity}</td><td>${formatPrice(i.price)}</td><td>${formatPrice(i.price * i.quantity)}</td></tr>`).join('')}
              </tbody>
            </table>

            <div class="totals">
                <div class="row"><span>Subtotal</span><span>${formatPrice(subtotal)}</span></div>
                ${discount > 0 ? `<div class="row" style="color:green;"><span>Discount</span><span>-${formatPrice(discount)}</span></div>` : ''}
                <div class="row"><span>Shipping</span><span>${shipping === 0 ? 'Free' : formatPrice(shipping)}</span></div>
                <div class="row"><span>Tax</span><span>${formatPrice(tax)}</span></div>
                ${codFee > 0 ? `<div class="row"><span>COD Handling Fee</span><span>${formatPrice(codFee)}</span></div>` : ''}
                <div class="row final"><span>Total</span><span>${formatPrice(selectedOrder.total)}</span></div>
            </div>

            <div class="footer">Thank you for choosing Luzaan. Authenticity Guaranteed.</div>
          </body>
        </html>`;
      invoiceWindow.document.write(htmlContent);
      invoiceWindow.document.close();
      window.print();
  };

  const whiteInputClass = "w-full bg-white border border-stone-300 p-3 rounded-xl text-sm text-brand-black outline-none focus:border-brand-black focus:ring-1 focus:ring-brand-black transition-all shadow-sm placeholder-stone-400 font-sans font-medium";

  return (
    <div className="animate-fade-in relative h-full pb-20 text-brand-black">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-10 gap-6">
        <div>
          <h1 className="text-2xl font-bold text-brand-black">Orders Ledger</h1>
          <p className="text-stone-500 text-xs mt-1">Manage and fulfill customer orders.</p>
        </div>
        <div className="w-full lg:w-auto flex gap-3">
             <div className="relative group flex-1 lg:w-80">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400 group-focus-within:text-brand-black transition-colors" size={16} />
                <input 
                    type="text" placeholder="Filter by Order ID or Customer..." 
                    value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-stone-200 rounded-xl text-sm outline-none focus:border-brand-black bg-white shadow-sm transition-all"
                />
            </div>
            <button className="px-6 py-3 bg-white border border-stone-200 rounded-xl text-xs font-bold text-stone-600 hover:bg-stone-50 shadow-sm uppercase tracking-widest">Export CSV</button>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-xl border border-stone-200 overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left text-xs min-w-[800px]">
            <thead className="bg-stone-50 text-stone-500 font-bold uppercase tracking-wider border-b border-stone-200">
              <tr>
                <th className="px-8 py-6">Order ID</th>
                <th className="px-8 py-6">Date</th>
                <th className="px-8 py-6">Customer</th>
                <th className="px-8 py-6">Total</th>
                <th className="px-8 py-6">Status</th>
                <th className="px-8 py-6">Fulfillment</th>
                <th className="px-8 py-6 text-right">Items</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-50">
              {filteredOrders.length > 0 ? filteredOrders.map(order => {
                const fulfillmentStatus = getFulfillmentStatus(order.status);
                return (
                <tr 
                    key={order.id} 
                    onClick={() => setSelectedOrder(order)}
                    className="hover:bg-stone-50 transition-colors cursor-pointer group"
                >
                  <td className="px-8 py-6 font-bold text-brand-black group-hover:underline decoration-stone-300 underline-offset-2">
                      {order.id}
                  </td>
                  <td className="px-8 py-6 text-stone-500 whitespace-nowrap">
                      {new Date(order.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                  <td className="px-8 py-6 text-stone-600 font-medium">
                      {order.customer.name}
                  </td>
                  <td className="px-8 py-6 font-serif font-bold text-brand-black text-sm">
                      {formatPrice(order.total)}
                  </td>
                  <td className="px-8 py-6">
                      <span className={`px-3 py-1.5 rounded-full text-[9px] font-bold uppercase tracking-widest border border-stone-200 bg-white text-stone-600`}>
                          Paid
                      </span>
                  </td>
                  <td className="px-8 py-6">
                      <span className={`px-3 py-1.5 rounded-full text-[9px] font-bold uppercase tracking-widest border border-transparent ${getFulfillmentColor(order.status)}`}>
                          {fulfillmentStatus}
                      </span>
                  </td>
                  <td className="px-8 py-6 text-right text-stone-500 font-bold">
                    {order.items.reduce((acc, i) => acc + i.quantity, 0)} Units
                  </td>
                </tr>
              )}) : (
                  <tr>
                    <td colSpan={7} className="p-20 text-center text-stone-300 italic font-serif text-lg">No orders found.</td>
                  </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {selectedOrder && (
            <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }} 
                className="fixed inset-0 z-[2000] flex items-start justify-center bg-white/60 backdrop-blur-md pt-20 pb-10 px-4 overflow-hidden"
                onClick={() => setSelectedOrder(null)}
            >
                <motion.div 
                    initial={{ scale: 0.95, opacity: 0, y: 20 }} 
                    animate={{ scale: 1, opacity: 1, y: 0 }} 
                    exit={{ scale: 0.95, opacity: 0, y: 20 }} 
                    className="bg-white w-full max-w-5xl rounded-[2.5rem] shadow-2xl border border-stone-200 flex flex-col max-h-[calc(100dvh-6rem)] relative overflow-hidden"
                    onClick={(e) => e.stopPropagation()}
                >
                    <div className="flex justify-between items-center p-6 lg:p-8 border-b border-stone-100 bg-[#FCFBFA]/90 backdrop-blur sticky top-0 z-20 shrink-0">
                        <div>
                            <h2 className="text-2xl font-serif font-bold italic text-brand-black">{selectedOrder.id}</h2>
                            <p className="text-[10px] font-black uppercase text-stone-400 tracking-[0.2em] mt-1">Order Detail View</p>
                        </div>
                        <div className="flex gap-3">
                            <button onClick={handleGenerateInvoice} className="p-3 bg-stone-50 text-stone-500 rounded-full hover:bg-brand-black hover:text-white transition-colors" title="Print Invoice">
                                <Printer size={18} />
                            </button>
                            <button onClick={() => setSelectedOrder(null)} className="p-3 bg-stone-50 text-stone-500 rounded-full hover:bg-stone-200 transition-colors">
                                <X size={18} />
                            </button>
                        </div>
                    </div>

                    <div className="p-8 lg:p-10 space-y-8 flex-1 overflow-y-auto custom-scrollbar bg-stone-50/20">
                        
                        <div className="bg-white p-8 rounded-[2rem] border border-stone-200 shadow-sm relative overflow-hidden">
                            <div className="flex justify-between items-center mb-6">
                                <h3 className="font-bold text-lg uppercase tracking-wide text-brand-black flex items-center gap-3">
                                    {getFulfillmentStatus(selectedOrder.status) === 'Completed' ? <CheckCircle2 size={24} className="text-green-600"/> : <Truck size={24} className="text-brand-black"/>}
                                    {getFulfillmentStatus(selectedOrder.status)}
                                </h3>
                                <div className="text-right">
                                    <span className="text-[9px] font-black uppercase tracking-widest text-stone-400 block mb-1">Status</span>
                                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${getFulfillmentColor(selectedOrder.status)}`}>
                                        {selectedOrder.status}
                                    </span>
                                </div>
                            </div>

                            {selectedOrder.status === 'Processing' && (
                                <div className="p-6 bg-stone-50 rounded-2xl border border-stone-100">
                                    <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-3 flex items-center gap-2"><Tag size={12} /> Assign Tracking ID</label>
                                    <div className="flex gap-4">
                                        <input 
                                            type="text" 
                                            value={trackingNumber} 
                                            onChange={(e) => setTrackingNumber(e.target.value)}
                                            className={`${whiteInputClass} flex-1`}
                                            placeholder="Enter Carrier Tracking Number..." 
                                        />
                                        <button onClick={generateTracking} className="px-4 py-3 bg-white border border-stone-300 rounded-xl text-stone-500 hover:text-brand-black hover:border-brand-black transition-all shadow-sm"><Wand2 size={18} /></button>
                                    </div>
                                    <button 
                                        onClick={handleDispatch}
                                        className="w-full mt-4 bg-brand-black text-white py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.3em] hover:bg-brand-crimson transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2"
                                    >
                                        Dispatch Order <Send size={14} />
                                    </button>
                                </div>
                            )}

                            {selectedOrder.status === 'Shipped' && (
                                <div className="p-6 bg-blue-50/50 rounded-2xl border border-blue-100">
                                    <div className="flex justify-between items-center mb-6">
                                        <div>
                                            <p className="text-[10px] font-black uppercase tracking-widest text-blue-800/60 mb-2">Active Tracking ID</p>
                                            <div className="flex items-center gap-3">
                                                <p className="text-2xl font-mono font-bold text-blue-900 bg-white px-4 py-2 rounded-lg border border-blue-100 shadow-sm">
                                                    {selectedOrder.trackingNumber || 'TRK-PENDING'}
                                                </p>
                                                <button onClick={() => navigator.clipboard.writeText(selectedOrder.trackingNumber || '')} className="p-2 text-blue-400 hover:text-blue-700 transition-colors">
                                                    <Copy size={16} />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={handleConfirmDelivery}
                                        className="w-full bg-green-600 text-white py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.3em] hover:bg-green-700 transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2"
                                    >
                                        Confirm Delivery <CheckCircle size={14} />
                                    </button>
                                </div>
                            )}

                            {selectedOrder.status === 'Delivered' && (
                                <div className="p-6 bg-green-50/50 rounded-2xl border border-green-100 flex items-center gap-4">
                                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                                        <CheckCircle2 size={24} />
                                    </div>
                                    <div>
                                        <p className="text-green-800 font-bold text-sm">Order Completed</p>
                                        <p className="text-green-700 text-xs">Delivered successfully. Tracking: <span className="font-mono font-bold">{selectedOrder.trackingNumber}</span></p>
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="bg-white p-8 rounded-[2rem] border border-stone-200 shadow-sm">
                                <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-6 flex items-center gap-2"><User size={12} /> Customer Profile</h4>
                                <div className="flex items-center gap-4 mb-6">
                                    <div className="w-12 h-12 rounded-full bg-brand-black text-white flex items-center justify-center font-bold text-lg font-serif">
                                        {selectedOrder.customer.name.charAt(0)}
                                    </div>
                                    <div>
                                        <p className="font-bold text-lg text-brand-black">{selectedOrder.customer.name}</p>
                                        <p className="text-xs text-stone-500">{selectedOrder.customer.email}</p>
                                    </div>
                                </div>
                                <div className="p-4 bg-stone-50 rounded-xl border border-stone-100">
                                    <p className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2 flex items-center gap-2"><MapPin size={10} /> Shipping Address</p>
                                    {selectedOrder.shippingAddress ? (
                                        <p className="text-sm text-stone-600 leading-relaxed font-medium">
                                            {selectedOrder.shippingAddress.street}<br/>
                                            {selectedOrder.shippingAddress.city}, {selectedOrder.shippingAddress.state} {selectedOrder.shippingAddress.zip}<br/>
                                            {selectedOrder.shippingAddress.country}
                                        </p>
                                    ) : (
                                        <p className="text-sm text-stone-400 italic">No shipping address provided.</p>
                                    )}
                                </div>
                            </div>

                            <div className="bg-white p-8 rounded-[2rem] border border-stone-200 shadow-sm">
                                <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-6 flex items-center gap-2"><CreditCard size={12} /> Financial Record</h4>
                                <div className="space-y-4">
                                    {/* Payment Method Details */}
                                    <div className="flex justify-between items-center p-4 bg-stone-50 rounded-xl border border-stone-100">
                                        <span className="text-xs font-bold text-stone-500 flex items-center gap-2">
                                            {selectedOrder.paymentMethod === 'Cash on Delivery' ? <Banknote size={14}/> : <CreditCard size={14}/>}
                                            Method
                                        </span>
                                        <span className="font-bold text-brand-black text-xs uppercase tracking-wide">{selectedOrder.paymentMethod || 'Credit Card'}</span>
                                    </div>

                                    {/* Detailed Breakdown */}
                                    <div className="p-4 bg-stone-50 rounded-xl border border-stone-100 space-y-2">
                                        <div className="flex justify-between text-xs">
                                            <span className="text-stone-500">Subtotal</span>
                                            <span className="font-bold text-brand-black">{formatPrice(selectedOrder.breakdown?.subtotal || selectedOrder.total)}</span>
                                        </div>
                                        <div className="flex justify-between text-xs">
                                            <span className="text-stone-500">Shipping</span>
                                            <span className="font-bold text-brand-black">{selectedOrder.breakdown?.shipping ? formatPrice(selectedOrder.breakdown.shipping) : 'Free'}</span>
                                        </div>
                                        {selectedOrder.breakdown?.codFee > 0 && (
                                            <div className="flex justify-between text-xs">
                                                <span className="text-stone-500">COD Fee</span>
                                                <span className="font-bold text-brand-black">{formatPrice(selectedOrder.breakdown.codFee)}</span>
                                            </div>
                                        )}
                                        <div className="flex justify-between text-xs pt-2 border-t border-stone-200 mt-2">
                                            <span className="font-black uppercase tracking-widest text-brand-black">Total Paid</span>
                                            <span className="font-serif font-bold text-brand-black text-lg">{formatPrice(selectedOrder.total)}</span>
                                        </div>
                                    </div>
                                    
                                    <div className="flex justify-between items-center p-4 bg-green-50 rounded-xl border border-green-100">
                                        <span className="text-xs font-bold text-green-700">Payment Status</span>
                                        <span className="font-bold text-xs uppercase tracking-widest text-green-800 flex items-center gap-1"><CheckCircle2 size={12}/> Verified</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white p-8 rounded-[2rem] border border-stone-200 shadow-sm">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-6 flex items-center gap-2"><Package size={12} /> Manifest</h4>
                            <div className="space-y-4">
                                {selectedOrder.items.map((item: any, idx: number) => (
                                    <div key={idx} className="flex gap-6 items-center p-4 hover:bg-stone-50 rounded-2xl transition-colors border border-transparent hover:border-stone-100">
                                        <div className="w-16 h-16 bg-white rounded-xl border border-stone-200 overflow-hidden flex-shrink-0 flex items-center justify-center p-2 shadow-sm">
                                            <img src={item.images[0]} alt="" className="w-full h-full object-contain" />
                                        </div>
                                        <div className="flex-1">
                                            <p className="font-serif font-bold text-lg text-brand-black">{item.name}</p>
                                            <p className="text-xs text-stone-500 font-medium uppercase tracking-wider">{item.size} • Qty {item.quantity}</p>
                                        </div>
                                        <p className="font-serif font-bold text-xl text-brand-black">{formatPrice(item.price * item.quantity)}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                    
                    <div className="p-6 lg:p-8 border-t border-stone-200 bg-white sticky bottom-0 z-20 flex justify-between items-center">
                        <div>
                            <span className="text-[10px] font-black uppercase tracking-widest text-stone-400 block">Total Value</span>
                            <span className="text-3xl font-serif font-bold text-brand-black">{formatPrice(selectedOrder.total)}</span>
                        </div>
                        <div className="flex gap-4">
                            {selectedOrder.status !== 'Cancelled' && selectedOrder.status !== 'Delivered' && (
                                <button onClick={() => { updateOrderStatus(selectedOrder.id, 'Cancelled'); setSelectedOrder(null); }} className="px-8 py-4 border border-stone-200 text-red-500 font-bold uppercase tracking-widest text-[10px] rounded-xl hover:bg-red-50 transition-colors">
                                    Cancel Order
                                </button>
                            )}
                            <button onClick={() => setSelectedOrder(null)} className="px-10 py-4 bg-brand-black text-white font-black uppercase tracking-widest text-[10px] rounded-xl hover:bg-stone-800 shadow-lg transition-all active:scale-95">
                                Close Details
                            </button>
                        </div>
                    </div>
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
