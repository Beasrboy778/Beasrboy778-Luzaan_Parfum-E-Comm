
import React, { useState } from 'react';
import { CreditCard, Save, Globe, Mail, Store, Key, ShieldCheck, Check, Sparkles, Smartphone, Eye, EyeOff, Lock, Contact, ExternalLink, Truck, Server } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { StoreSettings } from '../../types';

const PasswordInput = ({ label, name, value, onChange, placeholder }: any) => {
    const [show, setShow] = useState(false);
    return (
        <div>
            <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">{label}</label>
            <div className="relative">
                <input 
                    type={show ? 'text' : 'password'} 
                    name={name} 
                    value={value || ''} 
                    onChange={onChange} 
                    placeholder={placeholder} 
                    className="w-full bg-white border border-stone-300 rounded-lg p-3 pr-10 text-sm text-brand-black outline-none focus:border-brand-black focus:ring-2 focus:ring-brand-black/5 transition-all shadow-sm font-mono tracking-wide"
                />
                <button 
                    type="button"
                    onClick={() => setShow(!show)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-brand-black"
                >
                    {show ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
            </div>
        </div>
    );
};

export const Settings: React.FC = () => {
  const { storeSettings, updateStoreSettings, securitySettings, updateSecuritySettings } = useShop();
  const [activeTab, setActiveTab] = useState('general');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success'>('idle');
  
  const [formData, setFormData] = useState<StoreSettings>(storeSettings);
  const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = (name: string, value: any) => {
      let error = '';
      if (name === 'storeName' && !value.trim()) error = 'Store name is required.';
      if (name === 'supportEmail') {
          if (!value.trim()) error = 'Email is required.';
          else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) error = 'Invalid email format.';
      }
      setErrors(prev => ({...prev, [name]: error}));
      return error === '';
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      const { name, value, type } = e.target;
      const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
      setFormData(prev => ({ ...prev, [name]: val }));
      validate(name, val);
  };

  const handleContactChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const { name, value } = e.target;
      setFormData(prev => ({ 
          ...prev, 
          contactDetails: { ...prev.contactDetails, [name]: value }
      }));
  };

  const handleSocialChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const { name, value } = e.target;
      setFormData(prev => ({ 
          ...prev, 
          socialLinks: { ...prev.socialLinks, [name]: value }
      }));
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setPasswords(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSave = () => {
      setSaveStatus('saving');
      setTimeout(() => {
        if (activeTab === 'advanced') {
            if (passwords.new && passwords.new !== passwords.confirm) {
                alert('New passwords do not match.');
                setSaveStatus('idle');
                return;
            }
            updateSecuritySettings({ ...securitySettings });
        } else {
            updateStoreSettings(formData);
        }
        setSaveStatus('success');
        setTimeout(() => setSaveStatus('idle'), 2000);
      }, 800);
  };

  const whiteInputClass = "w-full bg-white border border-stone-300 rounded-lg p-3 text-sm text-brand-black outline-none focus:border-brand-black focus:ring-2 focus:ring-brand-black/5 transition-all shadow-sm placeholder-stone-400";

  return (
    <div className="animate-fade-in max-w-6xl mx-auto pb-12 text-brand-black">
      <div className="flex justify-between items-center mb-8">
        <div>
            <h1 className="text-3xl font-serif font-bold">Store Settings</h1>
            <p className="text-stone-500 mt-1">Manage the core details and connections for your shop.</p>
        </div>
        <button 
            onClick={handleSave} 
            disabled={saveStatus !== 'idle'}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-bold uppercase tracking-wide transition-all shadow-lg active:scale-95 ${saveStatus === 'success' ? 'bg-green-600 text-white' : 'bg-brand-black text-white hover:bg-stone-800'}`}
        >
            {saveStatus === 'success' ? <Check size={16} /> : <Save size={16} />}
            {saveStatus === 'success' ? 'Changes Saved' : (saveStatus === 'saving' ? 'Saving...' : 'Save Changes')}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="bg-white rounded-xl border border-stone-200 shadow-sm h-fit overflow-hidden">
              <nav className="flex flex-col p-2">
                  {[
                      { id: 'general', label: 'Store Name & Info', icon: Store },
                      { id: 'contact', label: 'Contact & Social', icon: Contact },
                      { id: 'keys', label: 'App Connections', icon: Key },
                      { id: 'advanced', label: 'Security', icon: ShieldCheck },
                  ].map(tab => (
                      <button
                          key={tab.id}
                          onClick={() => setActiveTab(tab.id)}
                          className={`flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-colors mb-1 ${
                              activeTab === tab.id 
                              ? 'bg-brand-black text-white shadow-md' 
                              : 'text-stone-500 hover:bg-stone-50 hover:text-brand-black'
                          }`}
                      >
                          <tab.icon size={18} /> {tab.label}
                      </button>
                  ))}
              </nav>
          </div>

          <div className="lg:col-span-3 space-y-6">
              {activeTab === 'general' && (
                <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden animate-fade-in">
                    <div className="p-6 border-b border-stone-100 bg-stone-50/50 flex justify-between items-center">
                        <h3 className="font-bold text-brand-black">Basic Info</h3>
                        <Globe size={16} className="text-stone-400" />
                    </div>
                    <div className="p-8 space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Shop Name</label>
                                <input name="storeName" value={formData.storeName} onChange={handleChange} className={whiteInputClass} />
                                {errors.storeName && <p className="text-red-500 text-[10px] mt-1">{errors.storeName}</p>}
                            </div>
                            <div>
                                <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Support Email</label>
                                <input name="supportEmail" value={formData.supportEmail} onChange={handleChange} className={whiteInputClass} />
                                {errors.supportEmail && <p className="text-red-500 text-[10px] mt-1">{errors.supportEmail}</p>}
                            </div>
                            <div>
                                <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Currency</label>
                                <select name="currency" value={formData.currency} onChange={handleChange} className={whiteInputClass}>
                                    <option value="USD">Dollar ($)</option>
                                    <option value="EUR">Euro (€)</option>
                                    <option value="GBP">Pound (£)</option>
                                    <option value="INR">Rupee (₹)</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Tax Rate (%)</label>
                                <input type="number" name="taxRate" value={formData.taxRate} onChange={handleChange} className={whiteInputClass} />
                            </div>
                        </div>
                    </div>
                </div>
              )}

              {activeTab === 'contact' && (
                <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden animate-fade-in">
                    <div className="p-6 border-b border-stone-100 bg-stone-50/50 flex justify-between items-center">
                        <h3 className="font-bold text-brand-black">Contact & Social Media</h3>
                        <Smartphone size={16} className="text-stone-400" />
                    </div>
                    <div className="p-8 space-y-8">
                        <div className="space-y-4">
                            <h4 className="font-bold text-sm text-brand-black">Physical Address & Hours</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="md:col-span-2">
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Street Address</label>
                                    <input name="addressLine1" value={formData.contactDetails.addressLine1} onChange={handleContactChange} className={whiteInputClass} placeholder="123 Luxury Lane" />
                                </div>
                                <div className="md:col-span-2">
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">City, Country, Zip</label>
                                    <input name="addressLine2" value={formData.contactDetails.addressLine2} onChange={handleContactChange} className={whiteInputClass} placeholder="Paris, France 75001" />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Phone</label>
                                    <input name="phone" value={formData.contactDetails.phone} onChange={handleContactChange} className={whiteInputClass} placeholder="+1 234 567 890" />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Weekday Hours</label>
                                    <input name="hours" value={formData.contactDetails.hours} onChange={handleContactChange} className={whiteInputClass} placeholder="Mon-Fri: 9am - 6pm" />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Weekend Hours</label>
                                    <input name="hoursSat" value={formData.contactDetails.hoursSat} onChange={handleContactChange} className={whiteInputClass} placeholder="Sat: 10am - 4pm" />
                                </div>
                            </div>
                        </div>

                        <div className="h-px bg-stone-100" />

                        <div className="space-y-4">
                            <h4 className="font-bold text-sm text-brand-black">Social Connections</h4>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Instagram URL</label>
                                    <input name="instagram" value={formData.socialLinks.instagram} onChange={handleSocialChange} className={whiteInputClass} placeholder="https://instagram.com/..." />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Facebook URL</label>
                                    <input name="facebook" value={formData.socialLinks.facebook} onChange={handleSocialChange} className={whiteInputClass} placeholder="https://facebook.com/..." />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Twitter / X URL</label>
                                    <input name="twitter" value={formData.socialLinks.twitter} onChange={handleSocialChange} className={whiteInputClass} placeholder="https://twitter.com/..." />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              )}

              {activeTab === 'keys' && (
                <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden animate-fade-in">
                    <div className="p-6 border-b border-stone-100 bg-stone-50/50 flex justify-between items-center">
                        <h3 className="font-bold text-brand-black">Central API Hub</h3>
                        <Key size={16} className="text-stone-400" />
                    </div>
                    <div className="p-8 space-y-8">
                        {/* Gemini Section */}
                        <div className="p-6 bg-gradient-to-r from-blue-50/50 to-purple-50/50 border border-blue-100 rounded-xl relative overflow-hidden">
                            <div className="flex justify-between items-start mb-4">
                                <h4 className="font-bold text-sm flex items-center gap-2 text-brand-black">
                                    <Sparkles size={16} className="text-purple-500" /> Google Gemini AI
                                </h4>
                                <a 
                                    href="https://aistudio.google.com/app/apikey" 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="text-[9px] font-black uppercase tracking-widest text-purple-600 bg-white px-3 py-1.5 rounded-lg shadow-sm hover:bg-purple-600 hover:text-white transition-all flex items-center gap-1"
                                >
                                    Get Key <ExternalLink size={10} />
                                </a>
                            </div>
                            <div className="space-y-4 max-w-lg relative z-10">
                                <PasswordInput label="AI Key (Gemini)" name="geminiApiKey" value={formData.geminiApiKey} onChange={handleChange} placeholder="AIzaSy..." />
                                <p className="text-[10px] text-stone-500 italic">Required for AI Muse, Scent Analysis, and Automated Text generation.</p>
                            </div>
                        </div>

                        {/* Payment & Shipping & Email Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {/* Stripe Section */}
                            <div className="p-6 bg-stone-50 border border-stone-200 rounded-xl space-y-4">
                                <div className="flex justify-between items-center">
                                    <h4 className="font-bold text-sm flex items-center gap-2">
                                        <CreditCard size={16} className="text-brand-crimson" /> Payments (Stripe)
                                    </h4>
                                    <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noopener noreferrer" className="text-[9px] font-bold uppercase text-stone-400 hover:text-brand-crimson flex items-center gap-1">Keys <ExternalLink size={8} /></a>
                                </div>
                                <PasswordInput label="Publishable Key" name="stripePublicKey" value={formData.stripePublicKey} onChange={handleChange} placeholder="pk_live_..." />
                                <PasswordInput label="Secret Key" name="stripeSecretKey" value={formData.stripeSecretKey} onChange={handleChange} placeholder="sk_live_..." />
                                <p className="text-[8px] text-red-400 italic">Warning: Storing secret keys in frontend is not recommended for production.</p>
                            </div>

                            {/* Shipping Section */}
                            <div className="p-6 bg-stone-50 border border-stone-200 rounded-xl space-y-4">
                                <div className="flex justify-between items-center">
                                    <h4 className="font-bold text-sm flex items-center gap-2">
                                        <Truck size={16} className="text-blue-600" /> Logistics (Shippo/EasyPost)
                                    </h4>
                                    <a href="https://goshippo.com/" target="_blank" rel="noopener noreferrer" className="text-[9px] font-bold uppercase text-stone-400 hover:text-blue-600 flex items-center gap-1">Sign Up <ExternalLink size={8} /></a>
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Provider</label>
                                    <select name="shippingProvider" value={formData.shippingProvider || 'manual'} onChange={handleChange} className={whiteInputClass}>
                                        <option value="manual">Manual</option>
                                        <option value="shippo">Shippo</option>
                                        <option value="easypost">EasyPost</option>
                                    </select>
                                </div>
                                <PasswordInput label="API Key" name="shippingApiKey" value={formData.shippingApiKey} onChange={handleChange} placeholder="Live Key..." />
                            </div>

                            {/* Email Section */}
                            <div className="p-6 bg-stone-50 border border-stone-200 rounded-xl md:col-span-2">
                                <div className="flex justify-between items-center mb-4">
                                    <h4 className="font-bold text-sm flex items-center gap-2">
                                        <Mail size={16} className="text-stone-600" /> Email Service (Resend)
                                    </h4>
                                    <a href="https://resend.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-[9px] font-bold uppercase text-stone-400 hover:text-brand-black flex items-center gap-1">Get Key <ExternalLink size={8} /></a>
                                </div>
                                <PasswordInput label="API Key" name="emailProviderApiKey" value={formData.emailProviderApiKey} onChange={handleChange} placeholder="re_..." />
                            </div>
                        </div>
                    </div>
                </div>
              )}

              {activeTab === 'advanced' && (
                <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden animate-fade-in">
                    <div className="p-6 border-b border-stone-100 bg-stone-50/50 flex justify-between items-center">
                        <h3 className="font-bold text-brand-black">Security Settings</h3>
                        <ShieldCheck size={16} className="text-stone-400" />
                    </div>
                    <div className="p-8 space-y-8">
                        <div className="p-6 bg-red-50/30 border border-red-100 rounded-xl">
                            <h4 className="font-bold text-sm text-red-900 mb-4 flex items-center gap-2">
                                <Lock size={16} /> Admin Password
                            </h4>
                            <div className="space-y-4 max-w-lg">
                                <PasswordInput label="Current Password" name="current" value={passwords.current} onChange={handlePasswordChange} />
                                <div className="grid grid-cols-2 gap-4">
                                    <PasswordInput label="New Password" name="new" value={passwords.new} onChange={handlePasswordChange} />
                                    <PasswordInput label="Confirm New" name="confirm" value={passwords.confirm} onChange={handlePasswordChange} />
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center justify-between p-6 bg-stone-50 rounded-xl border border-stone-100">
                            <div>
                                <h4 className="font-bold text-sm text-brand-black mb-1">Double Login Check (2FA)</h4>
                                <p className="text-xs text-stone-500">Sends a code to your email for every login.</p>
                            </div>
                            <button 
                                onClick={() => updateSecuritySettings({ twoFactor: !securitySettings.twoFactor })} 
                                className={`w-14 h-8 rounded-full p-1.5 transition-colors duration-300 ${securitySettings.twoFactor ? 'bg-brand-black' : 'bg-stone-300'}`}
                            >
                                <div className={`w-5 h-5 bg-white rounded-full shadow-sm transition-transform duration-300 ${securitySettings.twoFactor ? 'translate-x-6' : 'translate-x-0'}`} />
                            </button>
                        </div>
                    </div>
                </div>
              )}
          </div>
      </div>
    </div>
  );
};
