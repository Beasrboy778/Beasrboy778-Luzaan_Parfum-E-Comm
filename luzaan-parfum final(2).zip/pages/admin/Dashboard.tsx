
import React, { useMemo } from 'react';
// @ts-ignore
import { useNavigate, Link } from 'react-router-dom';
import { DollarSign, ShoppingBag, Users, Package, TrendingUp, Activity, ArrowRight, ExternalLink, Clock, CheckCircle2, AlertCircle, ChevronRight, Eye, Truck, Sparkles, Diamond, MoreVertical } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { useCurrency } from '../../context/CurrencyContext';
import { motion } from 'framer-motion';

export const Dashboard: React.FC = () => {
  const { adminOrders, adminProducts, adminCustomers } = useShop();
  const { formatPrice } = useCurrency();
  const navigate = useNavigate();

  // Dynamic Calculations
  const stats = useMemo(() => {
      const totalRevenue = adminOrders.reduce((acc, order) => acc + order.total, 0);
      const totalOrders = adminOrders.length;
      const totalCustomers = adminCustomers.length;
      const unfulfilledOrders = adminOrders.filter(o => o.status === 'Processing').length;
      const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

      // Mock previous period data for "trends"
      const prevRevenue = totalRevenue * 0.9; 
      const revenueGrowth = ((totalRevenue - prevRevenue) / prevRevenue) * 100;

      return { totalRevenue, totalOrders, totalCustomers, unfulfilledOrders, averageOrderValue, revenueGrowth };
  }, [adminOrders, adminProducts, adminCustomers]);

  const topProducts = useMemo(() => {
      const productCounts: Record<string, { count: number, img: string, name: string, category: string }> = {};
      adminOrders.forEach(o => {
          o.items.forEach(i => {
              if (!productCounts[i.id]) {
                  productCounts[i.id] = { count: 0, img: i.images[0], name: i.name, category: i.category };
              }
              productCounts[i.id].count += i.quantity;
          });
      });
      return Object.values(productCounts).sort((a, b) => b.count - a.count).slice(0, 4);
  }, [adminOrders]);

  const getStatusColor = (status: string) => {
      switch (status) {
          case 'Processing': return 'bg-brand-gold/20 text-brand-black border-brand-gold/40';
          case 'Shipped': return 'bg-blue-50 text-blue-800 border-blue-100';
          case 'Delivered': return 'bg-green-50 text-green-800 border-green-100';
          case 'Cancelled': return 'bg-red-50 text-red-800 border-red-100';
          default: return 'bg-stone-100 text-stone-600';
      }
  };

  // Mock Data for the chart visual
  const chartData = [45, 60, 75, 50, 80, 95, 110, 90, 100, 120, 140, 135];
  const maxChartVal = Math.max(...chartData);

  return (
    <div className="animate-fade-in max-w-[1600px] mx-auto pb-20 font-sans text-brand-black">
      
      {/* Aesthetic Header */}
      <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
        <div>
            <span className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-400 mb-2 block">Command Center</span>
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-brand-black italic">Atelier Overview</h1>
        </div>
        <div className="flex items-center gap-4 bg-white px-6 py-3 rounded-full shadow-sm border border-stone-100">
            <Clock size={16} className="text-brand-gold" />
            <span className="text-xs font-bold uppercase tracking-widest text-stone-500">
                {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Stats & Chart (8 cols) */}
        <div className="lg:col-span-8 space-y-8">
            
            {/* 3 Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Revenue Card */}
                <div className="bg-brand-black text-white p-8 rounded-[2.5rem] relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:scale-110 transition-transform duration-700">
                        <DollarSign size={80} />
                    </div>
                    <div className="relative z-10">
                        <p className="text-[9px] font-black uppercase tracking-[0.3em] text-brand-gold mb-4">Total Revenue</p>
                        <h3 className="text-3xl font-serif italic mb-2">{formatPrice(stats.totalRevenue)}</h3>
                        <div className="flex items-center gap-2 text-[10px] font-bold text-green-400">
                            <TrendingUp size={12} />
                            <span>+{stats.revenueGrowth.toFixed(0)}% vs last month</span>
                        </div>
                    </div>
                </div>

                {/* Orders Card */}
                <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-6 text-stone-100 group-hover:text-stone-200 transition-colors">
                        <ShoppingBag size={80} />
                    </div>
                    <div className="relative z-10">
                        <p className="text-[9px] font-black uppercase tracking-[0.3em] text-stone-400 mb-4">Total Orders</p>
                        <h3 className="text-3xl font-serif italic text-brand-black mb-2">{stats.totalOrders}</h3>
                        <div className="flex items-center gap-2 text-[10px] font-bold text-stone-500">
                            <Activity size={12} />
                            <span>{stats.unfulfilledOrders} Pending Fulfillment</span>
                        </div>
                    </div>
                </div>

                {/* Customers Card */}
                <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-6 text-stone-100 group-hover:text-stone-200 transition-colors">
                        <Users size={80} />
                    </div>
                    <div className="relative z-10">
                        <p className="text-[9px] font-black uppercase tracking-[0.3em] text-stone-400 mb-4">Active Patrons</p>
                        <h3 className="text-3xl font-serif italic text-brand-black mb-2">{stats.totalCustomers}</h3>
                        <div className="flex items-center gap-2 text-[10px] font-bold text-brand-crimson">
                            <Diamond size={12} />
                            <span>Global Clientele</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Sales Chart Visualization */}
            <div className="bg-white p-10 rounded-[3rem] border border-stone-200 shadow-sm flex flex-col h-96">
                <div className="flex justify-between items-center mb-8">
                    <h3 className="font-serif text-xl italic text-brand-black">Revenue Velocity</h3>
                    <button className="text-[9px] font-black uppercase tracking-widest text-stone-400 hover:text-brand-black transition-colors">View Report</button>
                </div>
                <div className="flex-1 flex items-end justify-between gap-2 md:gap-4">
                    {chartData.map((val, i) => (
                        <div key={i} className="flex-1 flex flex-col justify-end group h-full relative">
                            <motion.div 
                                initial={{ height: 0 }}
                                animate={{ height: `${(val / maxChartVal) * 100}%` }}
                                transition={{ duration: 1, delay: i * 0.05 }}
                                className="w-full bg-stone-100 rounded-t-xl group-hover:bg-brand-black transition-colors duration-500 relative min-h-[10px]"
                            >
                                <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-brand-black text-white text-[8px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                    {formatPrice(val * 10)}
                                </div>
                            </motion.div>
                        </div>
                    ))}
                </div>
                <div className="border-t border-stone-100 mt-4 pt-4 flex justify-between text-[9px] font-black uppercase tracking-widest text-stone-400">
                    <span>Jan</span><span>Dec</span>
                </div>
            </div>

            {/* Recent Orders Ledger */}
            <div className="bg-white rounded-[3rem] border border-stone-200 shadow-sm overflow-hidden">
                <div className="p-8 border-b border-stone-100 flex justify-between items-center bg-stone-50/30">
                    <h3 className="font-serif text-xl italic text-brand-black">Recent Acquisitions</h3>
                    <Link to="/admin/orders" className="text-[9px] font-black uppercase tracking-widest text-brand-crimson hover:underline">View All Ledger</Link>
                </div>
                <div className="divide-y divide-stone-100">
                    {adminOrders.slice(0, 5).map(order => (
                        <div 
                            key={order.id} 
                            onClick={() => navigate('/admin/orders', { state: { focusOrderId: order.id } })}
                            className="p-6 flex items-center justify-between hover:bg-stone-50 transition-colors cursor-pointer group"
                        >
                            <div className="flex items-center gap-6">
                                <div className="w-12 h-12 bg-stone-100 rounded-full flex items-center justify-center text-brand-black font-bold font-serif text-sm border border-stone-200 group-hover:border-brand-black transition-colors">
                                    {order.customer.name.charAt(0)}
                                </div>
                                <div>
                                    <p className="font-bold text-sm text-brand-black group-hover:text-brand-crimson transition-colors">{order.id}</p>
                                    <p className="text-[10px] text-stone-500 uppercase tracking-widest">{order.customer.name} • {order.items.length} Items</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-8">
                                <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${getStatusColor(order.status)}`}>
                                    {order.status}
                                </span>
                                <span className="font-serif font-bold text-lg text-brand-black w-24 text-right">
                                    {formatPrice(order.total)}
                                </span>
                                <ChevronRight size={16} className="text-stone-300 group-hover:text-brand-black transition-colors" />
                            </div>
                        </div>
                    ))}
                    {adminOrders.length === 0 && (
                        <div className="p-12 text-center text-stone-400 font-serif italic">The ledger is currently empty.</div>
                    )}
                </div>
            </div>
        </div>

        {/* Right Column: Sidebar (4 cols) */}
        <div className="lg:col-span-4 space-y-8">
            
            {/* Quick Rituals */}
            <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm">
                <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-400 mb-6">Quick Rituals</h3>
                <div className="space-y-3">
                    <button onClick={() => navigate('/admin/products')} className="w-full flex items-center justify-between p-4 bg-stone-50 rounded-2xl hover:bg-brand-black hover:text-white transition-all group border border-stone-100">
                        <div className="flex items-center gap-3">
                            <Package size={16} />
                            <span className="text-xs font-bold uppercase tracking-widest">Register Product</span>
                        </div>
                        <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                    <button onClick={() => navigate('/admin/orders')} className="w-full flex items-center justify-between p-4 bg-stone-50 rounded-2xl hover:bg-brand-black hover:text-white transition-all group border border-stone-100">
                        <div className="flex items-center gap-3">
                            <Truck size={16} />
                            <span className="text-xs font-bold uppercase tracking-widest">Fulfillment</span>
                        </div>
                        <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                    <button onClick={() => navigate('/admin/design')} className="w-full flex items-center justify-between p-4 bg-stone-50 rounded-2xl hover:bg-brand-black hover:text-white transition-all group border border-stone-100">
                        <div className="flex items-center gap-3">
                            <Eye size={16} />
                            <span className="text-xs font-bold uppercase tracking-widest">Store Aesthetics</span>
                        </div>
                        <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                </div>
            </div>

            {/* Top Creations */}
            <div className="bg-white rounded-[2.5rem] border border-stone-200 shadow-sm overflow-hidden">
                <div className="p-8 border-b border-stone-100 bg-stone-50/30">
                    <h3 className="font-serif text-xl italic text-brand-black">Top Creations</h3>
                </div>
                <div>
                    {topProducts.length > 0 ? topProducts.map((p, idx) => (
                        <div key={idx} className="flex items-center gap-4 p-6 hover:bg-stone-50 transition-colors border-b border-stone-50 last:border-0">
                            <div className="w-14 h-14 bg-stone-100 rounded-2xl flex items-center justify-center p-1 border border-stone-200">
                                <img src={p.img} alt="" className="w-full h-full object-contain" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <h4 className="font-bold text-sm text-brand-black truncate">{p.name}</h4>
                                <p className="text-[9px] text-stone-400 uppercase tracking-widest">{p.category}</p>
                            </div>
                            <span className="text-xs font-bold text-brand-black bg-stone-100 px-3 py-1 rounded-full">{p.count} Sold</span>
                        </div>
                    )) : (
                        <div className="p-8 text-center text-stone-400 text-xs italic">No sales data yet.</div>
                    )}
                </div>
                <div className="p-4 bg-stone-50/50 text-center">
                    <Link to="/admin/products" className="text-[9px] font-black uppercase tracking-[0.3em] text-brand-crimson hover:underline">Full Inventory</Link>
                </div>
            </div>

            {/* System Status */}
            <div className="bg-brand-black text-white p-8 rounded-[2.5rem] relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                    <AlertCircle size={100} />
                </div>
                <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-gold mb-6">System Status</h3>
                <div className="space-y-4 relative z-10">
                    <div className="flex items-center gap-3 text-xs opacity-80">
                        <CheckCircle2 size={14} className="text-green-400" />
                        <span className="line-through decoration-white/30">Gateway Online</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs opacity-80">
                        <CheckCircle2 size={14} className="text-green-400" />
                        <span className="line-through decoration-white/30">Database Synced</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs font-bold text-brand-gold">
                        <div className="w-2 h-2 bg-brand-gold rounded-full animate-pulse" />
                        <span>Backup Scheduled</span>
                    </div>
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};
