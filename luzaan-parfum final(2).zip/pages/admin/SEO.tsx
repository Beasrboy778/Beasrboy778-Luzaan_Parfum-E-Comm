
// ... imports
import React, { useState, useEffect } from 'react';
import { 
    Globe, Search, Save, Share2, Code, FileText, X, Download, RefreshCw, 
    AlertCircle, TrendingUp, MousePointer2, Eye, Layout, Bot, Target, 
    Zap, ListFilter, Plus, Trash2, CheckCircle, BarChart3, Activity, Smartphone, Monitor
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { motion, AnimatePresence } from 'framer-motion';
import { CustomMetaTag, KeywordMetric, SeoSettings } from '../../types';

// ... SERPPreview component ...
// ... KeywordTrendChart component ...

const SERPPreview = ({ title, desc, url, isMobile }: { title: string, desc: string, url: string, isMobile: boolean }) => {
    const displayTitle = title || "Page Title | Store Name";
    const displayDesc = desc || "Meta description of the page goes here. It should be concise and relevant to the content.";
    const displayUrl = url || "https://luzaan.com";

    // Approximate Google truncation lengths (in chars for demo, pixels in real algo)
    const maxTitle = isMobile ? 55 : 60;
    const maxDesc = isMobile ? 120 : 160;

    return (
        <div className={`bg-white rounded-lg p-4 font-sans border border-stone-200 shadow-sm select-none ${isMobile ? 'max-w-[375px] mx-auto' : 'w-full'}`}>
            <div className="flex flex-col gap-1">
                {isMobile && (
                    <div className="flex items-center gap-2 mb-1">
                        <div className="w-6 h-6 rounded-full bg-stone-100 flex items-center justify-center text-[10px] text-brand-black font-serif italic">L</div>
                        <div className="flex flex-col">
                            <span className="text-[12px] text-brand-black leading-none">Luzaan</span>
                            <span className="text-[12px] text-stone-500 leading-none">{displayUrl}</span>
                        </div>
                    </div>
                )}
                {!isMobile && <cite className="text-sm text-[#202124] not-italic mb-1">{displayUrl}</cite>}
                
                <h3 className="text-[#1a0dab] text-xl cursor-pointer hover:underline truncate" style={{ fontFamily: 'arial, sans-serif' }}>
                    {displayTitle.length > maxTitle ? displayTitle.substring(0, maxTitle) + '...' : displayTitle}
                </h3>
                
                <p className="text-[#4d5156] text-sm leading-normal" style={{ fontFamily: 'arial, sans-serif' }}>
                    <span className="text-stone-400 text-xs mr-2">{new Date().toDateString().slice(4, 10)} — </span>
                    {displayDesc.length > maxDesc ? displayDesc.substring(0, maxDesc) + '...' : displayDesc}
                </p>
            </div>
        </div>
    );
};

// Daily Keyword Volume Chart
const KeywordTrendChart = ({ history }: { history?: number[] }) => {
    // Generate mock history if none exists
    const data = history || Array.from({ length: 30 }, () => Math.floor(Math.random() * 1000) + 200);
    const max = Math.max(...data);

    return (
        <div className="h-24 flex items-end gap-1 w-full mt-4">
            {data.map((val, i) => (
                <div key={i} className="flex-1 group relative">
                    <motion.div 
                        initial={{ height: 0 }}
                        animate={{ height: `${(val / max) * 100}%` }}
                        transition={{ duration: 0.5, delay: i * 0.01 }}
                        className={`w-full rounded-t-sm ${i === data.length - 1 ? 'bg-brand-crimson' : 'bg-stone-200'} hover:bg-brand-black transition-colors`}
                    />
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-black text-white text-[8px] px-1 rounded">
                        {val}
                    </div>
                </div>
            ))}
        </div>
    );
};

export const SEO: React.FC = () => {
  const { seoSettings, updateSeoSettings, gscData, storeSettings } = useShop();
  const [activeTab, setActiveTab] = useState<'performance' | 'preview' | 'keywords' | 'aeo' | 'tech'>('performance');
  const [formData, setFormData] = useState<SeoSettings>(seoSettings);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');
  
  // Keyword State
  const [newKeyword, setNewKeyword] = useState('');
  
  // Custom Tag State
  const [newTagName, setNewTagName] = useState('');
  const [newTagContent, setNewTagContent] = useState('');

  // Keyword Limit
  const MAX_KEYWORDS = 20;

  useEffect(() => { setFormData(seoSettings); }, [seoSettings]);

  const handleSave = () => {
    updateSeoSettings(formData);
    const btn = document.getElementById('save-seo-btn');
    if(btn) { 
        const originalText = btn.innerHTML;
        btn.innerHTML = 'System Updated';
        btn.classList.add('bg-green-600');
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.classList.remove('bg-green-600');
        }, 2000); 
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  // --- Keyword Logic ---
  const addTargetKeyword = () => {
      if (!newKeyword.trim()) return;
      if ((formData.targetKeywords?.length || 0) >= MAX_KEYWORDS) {
          alert(`Maximum tracking limit of ${MAX_KEYWORDS} keywords reached.`);
          return;
      }

      // Simulate Real-time Analysis Fetch
      const volume = Math.floor(Math.random() * 8000) + 50; 
      const difficulty = Math.floor(Math.random() * 100);
      const position = Math.floor(Math.random() * 100) + 1;
      const history = Array.from({ length: 30 }, () => Math.floor(Math.random() * volume/30 + volume/60));

      const metric: KeywordMetric = {
          keyword: newKeyword,
          volume: volume,
          difficulty: difficulty,
          position: position,
          intent: 'Informational',
          history: history
      };
      setFormData(prev => ({ ...prev, targetKeywords: [...(prev.targetKeywords || []), metric] }));
      setNewKeyword('');
  };

  const removeTargetKeyword = (kw: string) => {
      setFormData(prev => ({ ...prev, targetKeywords: prev.targetKeywords.filter(k => k.keyword !== kw) }));
  };

  const getKeywordPerformanceColor = (position: number, volume: number) => {
      if (position <= 10 && volume > 100) return 'bg-green-500';
      if (position <= 30) return 'bg-yellow-500';
      return 'bg-red-500';
  };

  // --- Custom Tag Logic ---
  const addCustomTag = () => {
      if (!newTagName.trim() || !newTagContent.trim()) return;
      const newTag: CustomMetaTag = {
          id: Date.now().toString(),
          name: newTagName,
          content: newTagContent
      };
      setFormData(prev => ({ ...prev, customMetaTags: [...(prev.customMetaTags || []), newTag] }));
      setNewTagName('');
      setNewTagContent('');
  };

  const removeCustomTag = (id: string) => {
      setFormData(prev => ({ ...prev, customMetaTags: prev.customMetaTags.filter(t => t.id !== id) }));
  };

  // --- AEO Logic ---
  const handleAEOChange = (field: string, value: any) => {
      setFormData(prev => ({
          ...prev,
          aeoSettings: { ...prev.aeoSettings, [field]: value }
      }));
  };

  const addAlternateName = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
          const val = (e.target as HTMLInputElement).value;
          if (val && !formData.aeoSettings?.brandAlternateNames?.includes(val)) {
              handleAEOChange('brandAlternateNames', [...(formData.aeoSettings?.brandAlternateNames || []), val]);
              (e.target as HTMLInputElement).value = '';
          }
      }
  };

  const addKnowsAbout = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
          const val = (e.target as HTMLInputElement).value;
          if (val && !formData.aeoSettings?.knowsAbout?.includes(val)) {
              handleAEOChange('knowsAbout', [...(formData.aeoSettings?.knowsAbout || []), val]);
              (e.target as HTMLInputElement).value = '';
          }
      }
  };

  const glassInput = "w-full bg-white border border-stone-200 p-3 rounded-xl text-sm outline-none focus:border-brand-black transition-all";

  return (
    <div className="animate-fade-in text-brand-black pb-12">
      <div className="flex justify-between items-center mb-8">
        <div>
            <h1 className="text-2xl font-bold text-brand-black">SEO Command Center</h1>
            <p className="text-stone-500 text-sm mt-1">Real-time Search Analysis & Optimization.</p>
        </div>
        <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-green-50 px-3 py-1.5 rounded-full border border-green-100">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                <span className="text-[10px] font-bold text-green-700 uppercase tracking-widest">Traffic Load: Normal</span>
            </div>
            <button id="save-seo-btn" onClick={handleSave} className="flex items-center gap-2 px-6 py-3 bg-brand-black text-white rounded-lg text-sm font-bold uppercase tracking-wide hover:bg-stone-800 transition-all shadow-lg active:scale-95">
                <Save size={16} /> Save Changes
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-2">
            <nav className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden p-2">
                <button onClick={() => setActiveTab('performance')} className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold uppercase tracking-widest rounded-lg transition-colors ${activeTab === 'performance' ? 'bg-brand-black text-white' : 'text-stone-500 hover:bg-stone-50'}`}><TrendingUp size={16} /> Performance</button>
                <button onClick={() => setActiveTab('preview')} className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold uppercase tracking-widest rounded-lg transition-colors ${activeTab === 'preview' ? 'bg-brand-black text-white' : 'text-stone-500 hover:bg-stone-50'}`}><Eye size={16} /> Live SERP Preview</button>
                <button onClick={() => setActiveTab('keywords')} className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold uppercase tracking-widest rounded-lg transition-colors ${activeTab === 'keywords' ? 'bg-brand-black text-white' : 'text-stone-500 hover:bg-stone-50'}`}><Target size={16} /> Keyword Strategy</button>
                <button onClick={() => setActiveTab('aeo')} className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold uppercase tracking-widest rounded-lg transition-colors ${activeTab === 'aeo' ? 'bg-brand-black text-white' : 'text-stone-500 hover:bg-stone-50'}`}><Bot size={16} /> AEO & Voice</button>
                <button onClick={() => setActiveTab('tech')} className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold uppercase tracking-widest rounded-lg transition-colors ${activeTab === 'tech' ? 'bg-brand-black text-white' : 'text-stone-500 hover:bg-stone-50'}`}><Code size={16} /> Technical & Meta</button>
            </nav>
        </div>

        <div className="lg:col-span-3">
            <AnimatePresence mode="wait">
                {activeTab === 'performance' && (
                    <motion.div key="perf" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                        
                        {/* Site Reach Graph Visual */}
                        <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm overflow-hidden relative">
                            <h3 className="font-bold text-lg text-brand-black mb-6 flex items-center gap-2"><BarChart3 size={20} /> Site Reach Analysis</h3>
                            <div className="h-48 flex items-end justify-between gap-2 opacity-80">
                                {/* Simulated Graph Bars */}
                                {[45, 52, 49, 60, 58, 65, 72, 68, 75, 82, 80, 88].map((h, i) => (
                                    <div key={i} className="flex-1 bg-stone-100 rounded-t-lg relative group">
                                        <motion.div 
                                            initial={{ height: 0 }} 
                                            animate={{ height: `${h}%` }} 
                                            transition={{ duration: 1, delay: i * 0.05 }}
                                            className="absolute bottom-0 w-full bg-brand-black/10 group-hover:bg-brand-black transition-colors rounded-t-lg"
                                        />
                                    </div>
                                ))}
                            </div>
                            <div className="flex justify-between mt-4 text-[10px] text-stone-400 font-bold uppercase tracking-widest">
                                <span>30 Days Ago</span>
                                <span>Today (Live)</span>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                            {[
                                { label: "Total Clicks", val: gscData.clicks.toLocaleString(), icon: MousePointer2 },
                                { label: "Impressions", val: (gscData.impressions / 1000).toFixed(1) + 'k', icon: Eye },
                                { label: "Avg CTR", val: gscData.ctr + '%', icon: TrendingUp },
                                { label: "Avg Position", val: gscData.position, icon: Layout },
                            ].map((stat, i) => (
                                <div key={i} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm hover:border-brand-black/20 transition-all">
                                    <p className="text-[10px] font-black uppercase text-stone-400 tracking-widest mb-2 flex items-center gap-2"><stat.icon size={12}/> {stat.label}</p>
                                    <h3 className="text-3xl font-serif font-bold text-brand-black">{stat.val}</h3>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                )}

                {activeTab === 'preview' && (
                    <motion.div key="preview" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm space-y-6">
                                <h3 className="font-bold text-brand-black">Edit Metadata</h3>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2">Meta Title</label>
                                    <input name="metaTitle" value={formData.metaTitle} onChange={handleChange} className={glassInput} />
                                    <div className="flex justify-between mt-2 text-[10px] font-bold">
                                        <span className={formData.metaTitle.length > 60 ? 'text-red-500' : 'text-green-600'}>{formData.metaTitle.length} chars (Rec: 60)</span>
                                        <span className="text-stone-300">{formData.metaTitle.length * 7}px / 580px (approx)</span>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2">Meta Description</label>
                                    <textarea name="metaDescription" rows={4} value={formData.metaDescription} onChange={handleChange} className={`${glassInput} resize-none`} />
                                    <div className="flex justify-between mt-2 text-[10px] font-bold">
                                        <span className={formData.metaDescription.length > 160 ? 'text-red-500' : 'text-green-600'}>{formData.metaDescription.length} chars (Rec: 160)</span>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-6">
                                <div className="flex bg-stone-100 p-1 rounded-xl w-fit">
                                    <button onClick={() => setPreviewDevice('desktop')} className={`p-2 rounded-lg transition-all ${previewDevice === 'desktop' ? 'bg-white shadow-sm text-brand-black' : 'text-stone-400'}`}><Monitor size={18} /></button>
                                    <button onClick={() => setPreviewDevice('mobile')} className={`p-2 rounded-lg transition-all ${previewDevice === 'mobile' ? 'bg-white shadow-sm text-brand-black' : 'text-stone-400'}`}><Smartphone size={18} /></button>
                                </div>
                                <div className="bg-stone-50 p-8 rounded-2xl border border-stone-200">
                                    <h3 className="text-xs font-bold uppercase text-stone-400 mb-4 tracking-widest">Google Search Result Preview</h3>
                                    <SERPPreview 
                                        title={formData.metaTitle} 
                                        desc={formData.metaDescription} 
                                        url="https://luzaan.com" 
                                        isMobile={previewDevice === 'mobile'} 
                                    />
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}

                {activeTab === 'keywords' && (
                    <motion.div key="keywords" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                        <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
                            <div className="flex justify-between items-center mb-6">
                                <h3 className="font-bold text-brand-black">Tracked Keywords & Trends</h3>
                                <div className="text-[10px] font-bold uppercase tracking-widest text-stone-400">
                                    {formData.targetKeywords?.length || 0} / {MAX_KEYWORDS} Used
                                </div>
                            </div>
                            
                            <div className="flex gap-4 mb-8">
                                <input 
                                    value={newKeyword} 
                                    onChange={e => setNewKeyword(e.target.value)} 
                                    onKeyDown={e => e.key === 'Enter' && addTargetKeyword()}
                                    className={glassInput} 
                                    placeholder="Add new target keyword..." 
                                />
                                <button onClick={addTargetKeyword} className="bg-brand-black text-white px-6 rounded-xl text-xs font-bold uppercase hover:bg-stone-800 transition-colors">Track</button>
                            </div>
                            
                            <div className="space-y-4">
                                {formData.targetKeywords?.map((k, i) => (
                                    <div key={i} className="border border-stone-100 rounded-xl p-4 hover:shadow-md transition-all bg-white">
                                        <div className="flex justify-between items-start mb-4">
                                            <div>
                                                <h4 className="font-bold text-brand-black text-lg">{k.keyword}</h4>
                                                <div className="flex items-center gap-3 mt-1">
                                                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${getKeywordPerformanceColor(k.position, k.volume)} text-white`}>Rank #{k.position}</span>
                                                    <span className="text-xs text-stone-500">Vol: {k.volume.toLocaleString()}</span>
                                                    <span className="text-xs text-stone-500">Diff: {k.difficulty}/100</span>
                                                </div>
                                            </div>
                                            <button onClick={() => removeTargetKeyword(k.keyword)} className="text-stone-300 hover:text-red-500"><Trash2 size={16}/></button>
                                        </div>
                                        <div className="bg-stone-50 p-4 rounded-lg">
                                            <p className="text-[9px] font-black uppercase text-stone-400 tracking-widest mb-2">30-Day Search Volume Trend</p>
                                            <KeywordTrendChart history={k.history} />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </motion.div>
                )}

                {activeTab === 'aeo' && (
                    <motion.div key="aeo" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                        <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
                            <div className="flex items-center gap-4 mb-6 border-b border-stone-100 pb-4">
                                <div className="p-3 bg-blue-50 text-blue-600 rounded-xl"><Bot size={24} /></div>
                                <div>
                                    <h3 className="font-bold text-lg text-brand-black">Answer Engine Optimization</h3>
                                    <p className="text-xs text-stone-500">Optimize for Voice Search (Siri, Alexa, Google Assistant).</p>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                                <div className="space-y-4">
                                    <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2">Founder Name</label><input value={formData.aeoSettings?.founderName || ''} onChange={e => handleAEOChange('founderName', e.target.value)} className={glassInput} /></div>
                                    <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2">Founding Date</label><input type="date" value={formData.aeoSettings?.foundingDate || ''} onChange={e => handleAEOChange('foundingDate', e.target.value)} className={glassInput} /></div>
                                    <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2">Price Range</label><select value={formData.aeoSettings?.priceRange || '$$'} onChange={e => handleAEOChange('priceRange', e.target.value)} className={glassInput}><option>$ (Affordable)</option><option>$$ (Moderate)</option><option>$$$ (Expensive)</option><option>$$$$ (Luxury)</option></select></div>
                                    <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2">Area Served</label><input value={formData.aeoSettings?.areaServed || 'Global'} onChange={e => handleAEOChange('areaServed', e.target.value)} className={glassInput} placeholder="e.g. Worldwide, USA, Europe" /></div>
                                </div>
                                <div className="bg-stone-900 text-white p-6 rounded-2xl relative overflow-hidden flex flex-col justify-center">
                                    <div className="absolute top-4 left-4 opacity-50"><Bot size={20} /></div>
                                    <p className="text-[10px] font-bold uppercase tracking-widest text-stone-500 mb-4">Voice Assistant Preview</p>
                                    <p className="font-serif italic text-lg leading-relaxed text-stone-200">
                                        "According to {storeSettings.storeName}, founded in {new Date(formData.aeoSettings?.foundingDate || Date.now()).getFullYear()} by {formData.aeoSettings?.founderName || 'the founder'}, they specialize in {formData.aeoSettings?.knowsAbout?.join(', ') || 'perfume'}."
                                    </p>
                                    <div className="mt-4 flex gap-1 justify-center">
                                        {[1,2,3,4,3,2,1].map((h, i) => (
                                            <motion.div 
                                                key={i} 
                                                animate={{ height: [10, h*10, 10] }} 
                                                transition={{ duration: 1, repeat: Infinity }} 
                                                className="w-1 bg-blue-500 rounded-full" 
                                            />
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <div className="md:col-span-2 space-y-6">
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2">Brand Alternate Names (Press Enter)</label>
                                    <div className="flex flex-wrap gap-2 p-3 bg-stone-50 rounded-xl border border-stone-200 focus-within:border-brand-black transition-colors">
                                        {formData.aeoSettings?.brandAlternateNames?.map(n => (
                                            <span key={n} className="bg-white border border-stone-200 px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-2">{n} <button onClick={() => handleAEOChange('brandAlternateNames', formData.aeoSettings.brandAlternateNames.filter(x => x !== n))}><X size={12}/></button></span>
                                        ))}
                                        <input onKeyDown={addAlternateName} placeholder="Add alias..." className="bg-transparent text-sm outline-none flex-1 min-w-[100px]" />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2">Keywords / Known For (Press Enter)</label>
                                    <div className="flex flex-wrap gap-2 p-3 bg-stone-50 rounded-xl border border-stone-200 focus-within:border-brand-black transition-colors">
                                        {formData.aeoSettings?.knowsAbout?.map(n => (
                                            <span key={n} className="bg-white border border-stone-200 px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-2">{n} <button onClick={() => handleAEOChange('knowsAbout', formData.aeoSettings.knowsAbout.filter(x => x !== n))}><X size={12}/></button></span>
                                        ))}
                                        <input onKeyDown={addKnowsAbout} placeholder="Add keyword (e.g. Oud, Attar)..." className="bg-transparent text-sm outline-none flex-1 min-w-[100px]" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}

                {activeTab === 'tech' && (
                    <motion.div key="tech" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                        <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
                            <h3 className="font-bold text-brand-black mb-6 flex items-center gap-2"><Code size={18} /> Custom Meta Tags</h3>
                            <div className="space-y-4">
                                {formData.customMetaTags?.map(tag => (
                                    <div key={tag.id} className="flex gap-3 items-center bg-stone-50 p-3 rounded-xl border border-stone-100">
                                        <div className="flex-1 text-xs font-mono text-stone-600"><span className="text-brand-crimson">name=</span>"{tag.name}"</div>
                                        <div className="flex-1 text-xs font-mono text-stone-600"><span className="text-brand-crimson">content=</span>"{tag.content}"</div>
                                        <button onClick={() => removeCustomTag(tag.id)} className="text-stone-400 hover:text-red-500"><Trash2 size={14}/></button>
                                    </div>
                                ))}
                                <div className="flex gap-3">
                                    <input value={newTagName} onChange={e => setNewTagName(e.target.value)} placeholder="Tag Name (e.g. google-site-verification)" className={glassInput} />
                                    <input value={newTagContent} onChange={e => setNewTagContent(e.target.value)} placeholder="Content" className={glassInput} />
                                    <button onClick={addCustomTag} className="bg-stone-100 text-brand-black p-3 rounded-xl hover:bg-brand-black hover:text-white transition-colors"><Plus size={18}/></button>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
