
import React, { useState, useEffect, useRef, useLayoutEffect } from 'react';
// @ts-ignore
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, Package, Users, ShoppingCart, Settings, LogOut, 
  Menu, Tag, Truck, Star, FileText, Shield, 
  Database, Globe, Layers, Receipt, BookOpen, Mail, Palette, X, ShieldCheck, Cpu, Key, Lock, Sparkles, MessageSquare,
  Banknote, Search, Command
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { useShop } from '../../context/ShopContext';
import { AnimatedBell, AnimatedPulse } from '../../components/AnimatedIcons';
import { CommandPalette } from '../../components/admin/CommandPalette';
import { Logo } from '../../components/Logo';

const FramerIcon = ({ icon: Icon, isActive }: { icon: any, isActive: boolean }) => (
  // @ts-ignore
  <motion.div
    animate={isActive ? { scale: 1.1, color: '#ffffff' } : { scale: 1, color: '#8A8A8A' }}
    whileHover={{ scale: 1.05 }}
    transition={{ type: "spring", stiffness: 300 }}
  >
    <Icon size={18} strokeWidth={isActive ? 2 : 1.5} />
  </motion.div>
);

const MENU_ITEMS = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/admin' },
  { icon: Banknote, label: 'Sales', path: '/admin/sales' },
  { icon: Mail, label: 'Inbox', path: '/admin/inbox', id: 'inbox' },
  { icon: Package, label: 'Products', path: '/admin/products' },
  { icon: Layers, label: 'Categories', path: '/admin/categories' },
  { icon: ShoppingCart, label: 'Orders', path: '/admin/orders' },
  { icon: Users, label: 'Customers', path: '/admin/customers' },
  { icon: Sparkles, label: 'Marketing', path: '/admin/marketing' },
  { icon: Palette, label: 'Store Design', path: '/admin/design' },
  { icon: Database, label: 'Stock', path: '/admin/inventory' },
  { icon: Tag, label: 'Coupons', path: '/admin/coupons' },
  { icon: Receipt, label: 'Payments', path: '/admin/transactions' },
  { icon: Truck, label: 'Shipping', path: '/admin/shipping' },
  { icon: Star, label: 'Reviews', path: '/admin/reviews' },
  { icon: BookOpen, label: 'Stories', path: '/admin/stories' },
  { icon: MessageSquare, label: 'Comments', path: '/admin/comments', id: 'comments' },
  { icon: Globe, label: 'Site Pages', path: '/admin/content' },
  { icon: FileText, label: 'Google SEO', path: '/admin/seo' },
  { icon: Shield, label: 'Security', path: '/admin/security' },
  { icon: Database, label: 'Backups', path: '/admin/backups' },
  { icon: Settings, label: 'Settings', path: '/admin/settings' },
];

const SidebarContent = ({ 
  isMobile = false, 
  currentPath, 
  unreadMessages, 
  pendingComments, 
  onCloseMobile, 
  onLogout 
}: any) => {
  const navRef = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const savedScroll = sessionStorage.getItem('admin_sidebar_scroll');
    if (navRef.current && savedScroll) {
      navRef.current.scrollTop = parseInt(savedScroll, 10);
    }
  }, []);

  const handleScroll = () => {
    if (navRef.current) {
      sessionStorage.setItem('admin_sidebar_scroll', navRef.current.scrollTop.toString());
    }
  };

  return (
    <div className="flex flex-col h-full bg-white border-r border-stone-200 font-sans">
      <div className="h-20 lg:h-28 flex items-center justify-between px-6 border-b border-stone-100 bg-stone-50/30 backdrop-blur-sm shrink-0">
        <Logo size="text-xl" />
        {isMobile && (
            <button onClick={onCloseMobile} className="lg:hidden w-10 h-10 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 hover:text-brand-black transition-all">
                <X size={20} />
            </button>
        )}
      </div>

      <nav 
        ref={navRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto py-6 custom-scrollbar"
      >
        <ul className="space-y-1 px-4">
          {MENU_ITEMS.map((item, i) => {
            const isActive = currentPath === item.path;
            let badge = undefined;
            if (item.id === 'inbox' && unreadMessages > 0) badge = unreadMessages;
            if (item.id === 'comments' && pendingComments > 0) badge = pendingComments;

            return (
              <motion.li key={item.path} initial={isMobile ? { opacity: 0, x: -10 } : false} animate={isMobile ? { opacity: 1, x: 0 } : false} transition={{ delay: i * 0.02 }}>
                <Link to={item.path} onClick={isMobile ? onCloseMobile : undefined} className={`flex items-center justify-between px-4 py-2.5 rounded-xl transition-all group text-sm font-medium relative overflow-hidden ${isActive ? 'text-white' : 'text-stone-500 hover:bg-stone-50 hover:text-brand-black'}`}>
                  <div className="flex items-center relative z-10">
                    <FramerIcon icon={item.icon} isActive={isActive} />
                    <span className={`ml-3.5 whitespace-nowrap transition-transform ${isActive ? 'font-bold' : ''}`}>{item.label}</span>
                  </div>
                  {badge && (
                      <span className={`relative z-10 text-[9px] font-black px-1.5 py-0.5 rounded-full ${isActive ? 'bg-white text-brand-black' : 'bg-brand-crimson text-white shadow-sm'}`}>{badge}</span>
                  )}
                  {isActive && (
                      <motion.div layoutId="active-pill" className="absolute inset-0 bg-brand-black z-0 rounded-xl shadow-lg" initial={false} transition={{ type: "spring", stiffness: 400, damping: 30 }} />
                  )}
                </Link>
              </motion.li>
            );
          })}
        </ul>
      </nav>

      <div className="p-4 border-t border-stone-100 bg-stone-50/50 shrink-0">
        <button onClick={onLogout} className="flex items-center w-full px-4 py-3 text-stone-400 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all group text-sm font-medium">
          <LogOut size={18} className="group-hover:rotate-180 transition-transform duration-500" />
          <span className="ml-3 font-black uppercase tracking-widest text-[10px] font-sans">Exit Manager</span>
        </button>
      </div>
    </div>
  );
};

export const AdminLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const { adminMessages, blogComments } = useShop(); 
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Command Palette State
  const [isCommandOpen, setIsCommandOpen] = useState(false);

  const unreadMessages = adminMessages.filter(m => m.status === 'unread').length;
  const pendingComments = blogComments.filter(c => c.status === 'pending').length;

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/login');
    }
  }, [user, navigate]);
  
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  // Keyboard shortcut listener for Command+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user || user.role !== 'admin') return null;

  return (
    <div className="flex h-screen bg-stone-50 font-sans text-brand-black overflow-hidden relative">
      <CommandPalette isOpen={isCommandOpen} onClose={() => setIsCommandOpen(false)} />

      <aside className="hidden lg:block w-64 h-full fixed z-20 shadow-sm">
        <SidebarContent 
            currentPath={location.pathname}
            unreadMessages={unreadMessages}
            pendingComments={pendingComments}
            onLogout={handleLogout}
        />
      </aside>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-[2100] lg:hidden">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }} className="absolute inset-0 bg-brand-black/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />
            <motion.div initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }} transition={{ type: 'spring', damping: 25, stiffness: 200 }} className="absolute top-0 left-0 h-full w-[280px] bg-white shadow-2xl overflow-hidden">
              <SidebarContent 
                isMobile={true} 
                currentPath={location.pathname}
                unreadMessages={unreadMessages}
                pendingComments={pendingComments}
                onCloseMobile={() => setIsMobileMenuOpen(false)}
                onLogout={handleLogout}
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col transition-all duration-300 lg:ml-64 w-full overflow-hidden">
        <header className="h-16 lg:h-20 bg-white/80 backdrop-blur-xl border-b border-stone-200 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-[1000] shadow-sm">
          <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden p-2 -ml-2 text-stone-500 hover:text-brand-black bg-stone-50 rounded-xl transition-all active:scale-90"><Menu size={22} /></button>
          
          {/* Global Search Trigger */}
          <button 
            onClick={() => setIsCommandOpen(true)}
            className="flex items-center gap-3 bg-stone-50 border border-stone-200 px-4 py-2.5 rounded-xl hover:border-brand-black hover:bg-white transition-all group lg:w-96"
          >
            <Search size={16} className="text-stone-400 group-hover:text-brand-black transition-colors" />
            <span className="text-xs text-stone-400 font-medium group-hover:text-brand-black">Search or type command...</span>
            <div className="ml-auto hidden lg:flex items-center gap-1">
                <span className="bg-white border border-stone-200 rounded px-1.5 py-0.5 text-[9px] font-bold text-stone-400 shadow-sm">⌘K</span>
            </div>
          </button>
          
          <div className="flex items-center gap-3 lg:gap-6">
            <div className="hidden sm:block">
              <AnimatedBell hasNotifications={unreadMessages > 0} />
            </div>
            <div className="flex items-center gap-3 pl-4 lg:pl-6 border-l border-stone-100">
              <div className="hidden lg:block text-right">
                 <p className="text-xs font-bold text-brand-black leading-none mb-1">{user?.name || 'Admin'}</p>
                 <div className="flex items-center gap-1.5"><AnimatedPulse color="bg-green-500" /><p className="text-[8px] font-black uppercase tracking-wider text-stone-400">Archivist</p></div>
              </div>
              <div className="w-9 h-9 lg:w-10 lg:h-10 rounded-xl bg-brand-black text-white flex items-center justify-center font-display font-bold border-2 border-white shadow-md overflow-hidden shrink-0">
                 {user?.photoURL ? <img src={user.photoURL} alt="" className="w-full h-full object-cover" /> : user?.name?.charAt(0) || 'A'}
              </div>
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-hidden relative w-full">
            <div className="h-full w-full overflow-y-auto custom-scrollbar p-4 lg:p-8">
              <Outlet />
            </div>
        </main>
      </div>
    </div>
  );
};
