
import React, { useState } from 'react';
import { Star, Check, X, MessageSquare, AlertCircle } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const Reviews: React.FC = () => {
  const { reviews, updateReviewStatus } = useShop();
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const filteredReviews = reviews.filter(r => filter === 'all' ? true : r.status === filter);
  const pendingCount = reviews.filter(r => r.status === 'pending').length;
  const avgRating = reviews.length > 0 ? (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1) : '0.0';

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <div>
           <h1 className="text-2xl font-bold text-brand-black">Reviews & Ratings</h1>
           <p className="text-stone-500 text-sm mt-1">Moderate customer feedback.</p>
        </div>
        <div className="flex gap-4">
             <div className="bg-white px-4 py-2 rounded-lg border border-stone-200 shadow-sm flex items-center gap-2">
                 <div className="p-1 bg-yellow-100 rounded text-yellow-600"><Star size={14} fill="currentColor" /></div>
                 <div>
                     <p className="text-[10px] font-bold uppercase text-stone-400">Avg Rating</p>
                     <p className="font-bold text-brand-black">{avgRating}</p>
                 </div>
             </div>
             <div className="bg-white px-4 py-2 rounded-lg border border-stone-200 shadow-sm flex items-center gap-2">
                 <div className="p-1 bg-blue-100 rounded text-blue-600"><MessageSquare size={14} /></div>
                 <div>
                     <p className="text-[10px] font-bold uppercase text-stone-400">Total Reviews</p>
                     <p className="font-bold text-brand-black">{reviews.length}</p>
                 </div>
             </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden">
        <div className="p-6 border-b border-stone-200 flex flex-col md:flex-row gap-4 justify-between items-center bg-stone-50/50">
          <div className="flex gap-2">
            <button onClick={() => setFilter('all')} className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${filter === 'all' ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}>All</button>
            <button onClick={() => setFilter('pending')} className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${filter === 'pending' ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}>
                Pending {pendingCount > 0 && <span className="ml-1 bg-red-500 text-white px-1.5 py-0.5 rounded-full text-[9px]">{pendingCount}</span>}
            </button>
            <button onClick={() => setFilter('approved')} className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${filter === 'approved' ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}>Approved</button>
            <button onClick={() => setFilter('rejected')} className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${filter === 'rejected' ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}>Rejected</button>
          </div>
        </div>
        
        <div className="divide-y divide-stone-100">
          {filteredReviews.length === 0 ? (
              <div className="p-12 text-center text-stone-400">
                  <AlertCircle size={48} className="mx-auto mb-4 opacity-50" />
                  <p>No reviews found matching this filter.</p>
              </div>
          ) : (
            filteredReviews.map(review => (
                <div key={review.id} className="p-6 flex flex-col md:flex-row gap-6 hover:bg-stone-50 transition-colors">
                <div className="md:w-48 flex-shrink-0">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center font-bold text-stone-600 text-xs">
                            {review.userName.charAt(0)}
                        </div>
                        <div>
                            <h4 className="font-bold text-brand-black text-sm">{review.userName}</h4>
                            <p className="text-[10px] text-stone-500">{review.date}</p>
                        </div>
                    </div>
                    <div className="flex gap-1 text-yellow-400 mb-1">
                        {[...Array(5)].map((_, i) => (<Star key={i} size={12} className={i < review.rating ? "fill-current" : "text-stone-200"} />))}
                    </div>
                </div>
                
                <div className="flex-1">
                    <h5 className="font-bold text-xs uppercase text-stone-400 mb-1">Product: <span className="text-brand-crimson">{review.productName}</span></h5>
                    <p className="text-stone-700 text-sm leading-relaxed mb-4 bg-white p-3 border border-stone-100 rounded-lg italic">"{review.comment}"</p>
                    
                    <div className="flex items-center gap-3">
                        <span className={`px-2 py-1 rounded text-[10px] uppercase font-bold border ${review.status === 'approved' ? 'bg-green-50 text-green-700 border-green-100' : review.status === 'rejected' ? 'bg-red-50 text-red-700 border-red-100' : 'bg-yellow-50 text-yellow-700 border-yellow-100'}`}>
                            {review.status}
                        </span>
                        
                        <div className="flex-1 border-b border-stone-100"></div>

                        {review.status === 'pending' && (
                            <div className="flex gap-2">
                                <button onClick={() => updateReviewStatus(review.id, 'approved')} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white text-xs font-bold rounded-lg hover:bg-green-700 shadow-sm transition-colors"><Check size={14} /> Approve</button>
                                <button onClick={() => updateReviewStatus(review.id, 'rejected')} className="flex items-center gap-2 px-4 py-2 bg-white border border-red-200 text-red-600 text-xs font-bold rounded-lg hover:bg-red-50 transition-colors"><X size={14} /> Reject</button>
                            </div>
                        )}
                        {review.status !== 'pending' && (
                            <button onClick={() => updateReviewStatus(review.id, 'pending')} className="text-xs text-stone-400 hover:text-brand-black underline font-medium">Change Status</button>
                        )}
                    </div>
                </div>
                </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
