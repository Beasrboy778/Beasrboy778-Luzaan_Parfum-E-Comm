
import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Save, Eye, EyeOff, Image as ImageIcon, X, Mail, Upload, Loader2 } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { NewsletterConfig } from '../../types';

// Compression Utility
const compressImage = (file: File, maxWidth = 800): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height *= maxWidth / width;
                    width = maxWidth;
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                // Use WebP for better compression/quality ratio and transparency support
                const dataUrl = canvas.toDataURL('image/webp', 0.8);
                resolve(dataUrl);
            };
            img.onerror = (error) => reject(error);
        };
        reader.onerror = (error) => reject(error);
    });
};

const getImageSize = (dataUrl: string) => {
    if (!dataUrl || dataUrl.length === 0) return '0 KB';
    const sizeInBytes = dataUrl.length * 0.75; 
    const sizeInKb = sizeInBytes / 1024;
    return sizeInKb.toFixed(1) + ' KB';
};

export const Marketing: React.FC = () => {
  const { siteContent, updateSiteContent } = useShop();
  const [config, setConfig] = useState<NewsletterConfig>(siteContent.newsletter);
  const [showPreview, setShowPreview] = useState(true);
  const [isCompressing, setIsCompressing] = useState(false);
  const [imgDims, setImgDims] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    updateSiteContent('newsletter', config);
    const btn = document.getElementById('save-marketing-btn');
    if (btn) {
        const originalText = btn.innerHTML;
        btn.innerHTML = ' Ritual Archived';
        btn.classList.replace('bg-brand-black', 'bg-green-600');
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.classList.replace('bg-green-600', 'bg-brand-black');
        }, 2000);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          setIsCompressing(true);
          try {
              const compressed = await compressImage(file, 1000); // 1000px max width for popup
              setConfig(prev => ({ ...prev, image: compressed }));
          } catch (error) {
              console.error("Image compression failed", error);
              alert("Failed to process image.");
          } finally {
              setIsCompressing(false);
              // Reset input so same file can be selected again if needed
              e.target.value = '';
          }
      }
  };

  const glassInputClass = "w-full bg-white/40 backdrop-blur-md border border-stone-200/50 p-3 rounded-xl text-sm text-brand-black outline-none focus:bg-white/70 focus:border-brand-black transition-all shadow-inner placeholder-stone-400";

  return (
    <div className="animate-fade-in text-brand-black pb-20">
      <div className="flex justify-between items-center mb-8">
        <div>
            <h1 className="text-3xl font-serif font-bold">Marketing Rituals</h1>
            <p className="text-stone-500 mt-1">Direct the entrance ritual and member acquisition flow.</p>
        </div>
        <button 
            id="save-marketing-btn"
            onClick={handleSave} 
            className="flex items-center gap-2 px-8 py-3 bg-brand-black text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-stone-800 transition-all shadow-lg active:scale-95"
        >
            <Save size={16} /> Finalize Ritual
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Controls */}
          <div className="space-y-8">
              <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm">
                  <div className="flex items-center justify-between mb-10 border-b border-stone-100 pb-6">
                      <div className="flex items-center gap-3">
                          <div className="p-3 bg-brand-crimson/5 rounded-2xl text-brand-crimson shadow-sm">
                              <Sparkles size={24} />
                          </div>
                          <div>
                              <h3 className="font-bold text-lg">Entrance Invitation</h3>
                              <p className="text-[9px] uppercase font-black text-stone-400 tracking-[0.4em]">Subscription Layer</p>
                          </div>
                      </div>
                      <button 
                        onClick={() => setConfig(prev => ({ ...prev, enabled: !prev.enabled }))}
                        className={`w-16 h-10 rounded-full p-1.5 transition-all duration-500 ${config.enabled ? 'bg-brand-crimson shadow-[0_0_15px_rgba(128,0,32,0.3)]' : 'bg-stone-300'}`}
                      >
                        <div className={`w-7 h-7 bg-white rounded-full shadow-md transition-transform duration-500 ${config.enabled ? 'translate-x-6' : 'translate-x-0'}`} />
                      </button>
                  </div>

                  <div className="space-y-8">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div>
                              <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3">Accent Header</label>
                              <input value={config.offerText} onChange={e => setConfig({...config, offerText: e.target.value})} className={glassInputClass} />
                          </div>
                          <div>
                              <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3">Post-Join Code</label>
                              <input value={config.code} onChange={e => setConfig({...config, code: e.target.value.toUpperCase()})} className={`${glassInputClass} font-mono font-bold tracking-[0.4em]`} />
                          </div>
                      </div>

                      <div>
                          <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3">Main Headline</label>
                          <input value={config.title} onChange={e => setConfig({...config, title: e.target.value})} className={`${glassInputClass} text-xl font-serif italic py-4`} />
                      </div>

                      <div>
                          <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3">Supporting Copy</label>
                          <textarea rows={3} value={config.subtitle} onChange={e => setConfig({...config, subtitle: e.target.value})} className={`${glassInputClass} resize-none leading-relaxed italic`} />
                      </div>

                      <div>
                          <div className="flex justify-between items-end mb-3">
                              <label className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 flex items-center gap-2"><ImageIcon size={12} /> Imagery URL</label>
                              {config.image && (
                                  <div className="text-right">
                                      <span className="block text-[9px] font-mono text-brand-black font-bold">{imgDims}</span>
                                      <span className="text-[8px] text-stone-400">{getImageSize(config.image)}</span>
                                  </div>
                              )}
                          </div>
                          
                          <div className="flex gap-2">
                              <input value={config.image} onChange={e => setConfig({...config, image: e.target.value})} className={glassInputClass} />
                              <input type="file" ref={fileRef} className="hidden" accept="image/*" onChange={handleFileUpload} />
                              <button 
                                onClick={() => fileRef.current?.click()} 
                                disabled={isCompressing}
                                className="p-3 bg-stone-100 rounded-lg hover:bg-brand-black hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex flex-col items-center justify-center min-w-[100px]" 
                                title="Upload Image"
                              >
                                  {isCompressing ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
                                  <span className="text-[7px] font-black uppercase mt-1">Rec: 600x800</span>
                              </button>
                          </div>
                          
                          {/* Hidden Image for calculating stats */}
                          <img 
                            src={config.image} 
                            className="hidden" 
                            onLoad={(e) => setImgDims(`${e.currentTarget.naturalWidth}x${e.currentTarget.naturalHeight}`)} 
                            alt="" 
                          />
                          
                          {isCompressing && <p className="text-[9px] text-stone-400 mt-2 italic animate-pulse">Optimizing visual asset...</p>}
                      </div>

                      <div className="pt-6 flex items-center justify-between border-t border-stone-100">
                          <span className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-400">Simulation Status</span>
                          <button onClick={() => setShowPreview(!showPreview)} className="flex items-center gap-2 text-xs font-bold text-brand-crimson hover:underline">
                              {showPreview ? <EyeOff size={14} /> : <Eye size={14} />} {showPreview ? 'Hide Ritual' : 'Preview Ritual'}
                          </button>
                      </div>
                  </div>
              </div>
          </div>

          {/* Preview Container */}
          <div className="relative">
              <div className="sticky top-24">
                  <div className="flex items-center gap-3 mb-8">
                      <span className="h-px flex-1 bg-stone-200" />
                      <span className="text-[9px] font-black uppercase tracking-[0.5em] text-stone-400">Live Aesthetic Simulation</span>
                      <span className="h-px flex-1 bg-stone-200" />
                  </div>

                  <AnimatePresence mode="wait">
                      {showPreview && (
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="w-full aspect-[4/3] bg-[#F9F6F2] rounded-[3rem] shadow-2xl border-4 border-white overflow-hidden flex flex-col md:flex-row"
                        >
                            <div className="w-full md:w-[45%] h-full relative bg-stone-100">
                                <img src={config.image} alt="" className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-brand-black/5" />
                            </div>
                            <div className="flex-1 p-12 flex flex-col justify-center relative">
                                <button className="absolute top-6 right-6 text-stone-300">
                                    <X size={20} />
                                </button>
                                <span className="text-brand-crimson font-black text-[10px] uppercase tracking-[0.5em] mb-4 block">{config.offerText}</span>
                                <h2 className="font-serif text-4xl text-brand-black mb-4 italic leading-tight">{config.title}</h2>
                                <p className="text-stone-500 text-xs mb-10 leading-relaxed italic opacity-80">
                                    {config.subtitle}
                                </p>
                                <div className="space-y-4">
                                    <div className="relative">
                                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-300" size={16} />
                                        <input disabled placeholder="Email Address" className="w-full bg-white border border-stone-100 pl-10 pr-4 py-4 text-xs rounded-xl shadow-sm" />
                                    </div>
                                    <button className="w-full bg-brand-black text-white py-4 font-black uppercase tracking-[0.4em] text-[10px] rounded-xl shadow-xl">
                                        Subscribe Now
                                    </button>
                                </div>
                                <p className="text-[8px] text-stone-400 text-center mt-8 uppercase font-bold tracking-[0.3em]">
                                    Privacy Guaranteed • Unsubscribe Anytime
                                </p>
                            </div>
                        </motion.div>
                      )}
                  </AnimatePresence>

                  {!config.enabled && (
                      <div className="mt-8 p-6 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-4 text-red-600 shadow-sm animate-pulse">
                          <EyeOff size={20} />
                          <p className="text-xs font-bold uppercase tracking-widest">Ritual is currently offline for visitors.</p>
                      </div>
                  )}
              </div>
          </div>
      </div>
    </div>
  );
};
