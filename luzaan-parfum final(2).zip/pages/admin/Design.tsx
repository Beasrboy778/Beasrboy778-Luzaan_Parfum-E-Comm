
import React, { useState, useRef } from 'react';
import { Save, Video, LayoutTemplate, Upload, Globe, ShieldCheck, Grid, Layers, Sparkles, Sliders, Play, Image as ImageIcon, Check, MousePointer2, Type, Zap, Plus, Trash2, Edit2, ArrowRight, Loader2, FileJson, Hash, Layout, Flag, MessageSquare } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { DesignSettings, HeroSlide } from '../../types';
import { motion, AnimatePresence } from 'framer-motion';

// --- Image Compression Utility ---
const compressImage = (file: File, maxWidth = 1920): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height *= maxWidth / width;
                    width = maxWidth;
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                
                // Compress to WebP with 0.8 quality
                const dataUrl = canvas.toDataURL('image/webp', 0.8);
                resolve(dataUrl);
            };
            img.onerror = (error) => reject(error);
        };
        reader.onerror = (error) => reject(error);
    });
};

const getImageSize = (dataUrl: string) => {
    if (!dataUrl || dataUrl.length === 0) return '0 KB';
    const sizeInBytes = dataUrl.length * 0.75; 
    const sizeInKb = sizeInBytes / 1024;
    if (sizeInKb > 1024) {
        return (sizeInKb / 1024).toFixed(2) + ' MB';
    }
    return sizeInKb.toFixed(1) + ' KB';
};

const ImageUploadBlock = ({ label, field, value, onChange, loading, info, recSize }: any) => {
    const [dims, setDims] = useState<string | null>(null);

    return (
        <div className="space-y-4">
            <div className="flex justify-between items-end">
                <div className="flex flex-col">
                    <label className="text-[10px] font-black uppercase text-stone-400 tracking-[0.3em]">{label}</label>
                    {recSize && <span className="text-[9px] font-mono text-stone-300 mt-1">Target: {recSize}</span>}
                </div>
                <div className="text-right">
                    {value && !value.includes('video') && (
                        <div className="flex flex-col items-end">
                            <span className="text-[9px] font-mono text-brand-black font-bold">{dims || 'Loading...'}</span>
                            <span className="text-[8px] text-stone-400">{getImageSize(value)}</span>
                        </div>
                    )}
                </div>
            </div>
            <div className="relative group cursor-pointer aspect-[16/9] bg-stone-50 border-2 border-dashed border-stone-200 rounded-2xl overflow-hidden hover:border-brand-black transition-all">
                <input type="file" onChange={(e) => onChange(e, field)} className="absolute inset-0 opacity-0 z-10 cursor-pointer" accept="image/*,video/*" />
                {loading ? (
                    <div className="flex flex-col items-center justify-center h-full gap-2">
                        <Loader2 className="animate-spin text-brand-black" size={24} />
                        <span className="text-[9px] font-black uppercase text-stone-400">Optimizing Asset...</span>
                    </div>
                ) : value ? (
                    value.includes('video') || value.endsWith('.mp4') ? (
                        <video src={value} className="w-full h-full object-cover" muted loop autoPlay />
                    ) : (
                        <img 
                            src={value} 
                            className="w-full h-full object-cover" 
                            alt="Preview" 
                            onLoad={(e) => setDims(`${e.currentTarget.naturalWidth}x${e.currentTarget.naturalHeight}`)}
                        />
                    )
                ) : (
                    <div className="flex flex-col items-center justify-center h-full text-stone-300 gap-2">
                        <ImageIcon size={24} />
                        <span className="text-[9px] font-black uppercase">Upload Asset</span>
                        {recSize && <span className="text-[8px] font-mono text-stone-400 bg-stone-100 px-2 py-1 rounded">{recSize}</span>}
                    </div>
                )}
                <div className="absolute inset-0 bg-brand-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Upload className="text-white" size={24} />
                </div>
            </div>
            {info && <p className="text-[9px] text-stone-400 italic">{info}</p>}
        </div>
    );
};

export const Design: React.FC = () => {
  const { designSettings, updateDesignSettings } = useShop();
  const [formData, setFormData] = useState<DesignSettings>(designSettings);
  const [activeTab, setActiveTab] = useState<'global' | 'home' | 'pages' | 'marketing' | 'text'>('home');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success'>('idle');
  const [isCompressing, setIsCompressing] = useState(false);
  
  // Slide Management State
  const [editingSlideId, setEditingSlideId] = useState<string | null>(null);
  const [slideForm, setSlideForm] = useState<HeroSlide>({ id: '', line1: '', line2: '', quote: '', image: '' });
  const slideImageRef = useRef<HTMLInputElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'number' ? parseFloat(value) : value;
    setFormData(prev => ({ ...prev, [name]: val }));
  };

  const handleSave = () => {
    updateDesignSettings(formData);
    document.documentElement.style.setProperty('--grain-opacity', (formData.siteGrainIntensity || 0.02).toString());
    setSaveStatus('success');
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: keyof DesignSettings) => {
      const file = e.target.files?.[0];
      if (file) {
          if (file.type.startsWith('video/')) {
              const reader = new FileReader();
              reader.onloadend = () => {
                  if (typeof reader.result === 'string') {
                      setFormData(prev => ({ ...prev, [field]: reader.result }));
                  }
              };
              reader.readAsDataURL(file);
              return;
          }

          setIsCompressing(true);
          try {
              const maxWidth = (field === 'siteLogo' || field === 'siteFavicon') ? 512 : 1920; 
              const compressed = await compressImage(file, maxWidth);
              setFormData(prev => ({ ...prev, [field]: compressed }));
          } catch (err) {
              console.error("Compression failed", err);
              alert("Image processing failed.");
          } finally {
              setIsCompressing(false);
          }
      }
  };

  // --- Slide Handlers ---
  const handleEditSlide = (slide: HeroSlide) => {
      setSlideForm({ ...slide });
      setEditingSlideId(slide.id);
  };

  const handleAddSlide = () => {
      setSlideForm({ id: Date.now().toString(), line1: '', line2: '', quote: '', image: '' });
      setEditingSlideId('new');
  };

  const handleSaveSlide = () => {
      if (!slideForm.line1) return;
      let updatedSlides = [...(formData.heroSlides || [])];
      if (editingSlideId === 'new') {
          updatedSlides.push({ ...slideForm, id: Date.now().toString() });
      } else {
          updatedSlides = updatedSlides.map(s => s.id === editingSlideId ? slideForm : s);
      }
      setFormData({ ...formData, heroSlides: updatedSlides });
      setEditingSlideId(null);
  };

  const handleDeleteSlide = (id: string) => {
      if (window.confirm("Delete this slide?")) {
          setFormData({ ...formData, heroSlides: formData.heroSlides?.filter(s => s.id !== id) });
      }
  };

  const handleSlideImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          setIsCompressing(true);
          try {
              const compressed = await compressImage(file, 800); 
              setSlideForm(prev => ({ ...prev, image: compressed }));
          } finally {
              setIsCompressing(false);
          }
      }
  };

  const inputClass = "w-full bg-white border border-stone-200 p-4 rounded-xl text-sm outline-none focus:border-brand-black transition-all shadow-sm font-sans";

  return (
    <div className="animate-fade-in max-w-6xl mx-auto pb-24 text-brand-black">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
        <div>
            <h1 className="text-3xl font-serif font-bold">Store Aesthetics</h1>
            <p className="text-stone-500 mt-1">Direct the cinematic experience and global brand narrative.</p>
        </div>
        <button onClick={handleSave} className={`flex items-center gap-3 px-12 py-5 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all shadow-2xl active:scale-95 ${saveStatus === 'success' ? 'bg-green-600 text-white' : 'bg-brand-black text-white hover:bg-stone-800'}`}>
            {saveStatus === 'success' ? <Check size={20} /> : <Save size={20} />}
            {saveStatus === 'success' ? 'Aesthetics Updated' : 'Archive New Design'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
          <div className="lg:col-span-1">
              <nav className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden p-3 sticky top-6">
                  {[
                      { id: 'global', label: 'Global Identity', icon: Globe },
                      { id: 'home', label: 'Home Layout', icon: Layout },
                      { id: 'pages', label: 'Inner Pages', icon: FileJson },
                      { id: 'text', label: 'Text & Titles', icon: Type },
                      { id: 'marketing', label: 'Marketing Layer', icon: Sparkles },
                  ].map(tab => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`w-full flex items-center gap-4 px-6 py-5 text-xs font-black uppercase tracking-widest rounded-2xl transition-all mb-2 ${activeTab === tab.id ? 'bg-brand-black text-white shadow-xl translate-x-2' : 'text-stone-400 hover:bg-stone-50 hover:text-brand-black'}`}
                      >
                        <tab.icon size={18} /> {tab.label}
                      </button>
                  ))}
              </nav>
          </div>

          <div className="lg:col-span-3">
            <AnimatePresence mode="wait">
              
              {activeTab === 'global' && (
                <motion.div key="global" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="bg-white p-12 rounded-[3.5rem] border border-stone-200 shadow-sm space-y-12">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-8"><h3 className="text-2xl font-serif font-bold italic flex items-center gap-4"><Globe size={28} className="text-brand-crimson" /> Brand Fundamentals</h3></div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
                        <ImageUploadBlock label="Vector Logo" field="siteLogo" value={formData.siteLogo} onChange={handleUpload} loading={isCompressing} recSize="500x200 PNG" />
                        <ImageUploadBlock label="Site Favicon" field="siteFavicon" value={formData.siteFavicon} onChange={handleUpload} loading={isCompressing} recSize="512x512 PNG" />
                    </div>

                    <div className="p-8 bg-stone-50/50 rounded-[2.5rem] border border-stone-100 shadow-inner">
                        <div className="flex items-center justify-between mb-4">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-black flex items-center gap-2"><Sparkles size={12} /> Atmospheric Texture</h4>
                            <span className="text-[9px] font-mono text-stone-400">{Math.round((formData.siteGrainIntensity || 0.02) * 100)}% Intensity</span>
                        </div>
                        <p className="text-[9px] text-stone-400 font-medium mb-6 max-w-lg leading-relaxed">Adjust the cinematic film grain overlay to enhance the tactile luxury feel.</p>
                        <input type="range" min="0" max="0.15" step="0.01" value={formData.siteGrainIntensity || 0.02} onChange={(e) => setFormData({...formData, siteGrainIntensity: parseFloat(e.target.value)})} className="w-full h-1 bg-stone-200 rounded-full appearance-none cursor-pointer accent-brand-black" />
                    </div>

                    <div className="pt-8 border-t border-stone-100 space-y-6">
                        <div className="flex items-center justify-between">
                            <label className="block text-[10px] font-black uppercase text-stone-400 flex items-center gap-2"><Flag size={14} /> Global Announcement Bar</label>
                            <button onClick={() => setFormData({...formData, announcementBarActive: !formData.announcementBarActive})} className={`w-10 h-5 rounded-full p-1 transition-colors ${formData.announcementBarActive ? 'bg-brand-black' : 'bg-stone-200'}`}><div className={`w-3 h-3 bg-white rounded-full shadow-sm transition-transform ${formData.announcementBarActive ? 'translate-x-5' : 'translate-x-0'}`} /></button>
                        </div>
                        <input type="text" name="announcementBarText" value={formData.announcementBarText} onChange={handleChange} className={inputClass} placeholder="e.g. Free Shipping Worldwide" />
                        <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 flex items-center gap-2"><Globe size={14} /> Marquee Text (Footer)</label>
                        <textarea name="marqueeText" value={formData.marqueeText} onChange={handleChange} rows={3} className={`${inputClass} resize-none font-bold uppercase tracking-[0.2em] text-[11px]`} />
                    </div>
                </motion.div>
              )}

              {activeTab === 'home' && (
                <motion.div key="home" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="bg-white p-12 rounded-[4rem] border border-stone-200 shadow-sm space-y-16">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-8"><h3 className="text-2xl font-serif font-bold italic flex items-center gap-4"><Layout size={28} className="text-brand-crimson" /> Home Experience</h3></div>

                    <div className="space-y-12">
                        <ImageUploadBlock label="Hero Background Visual" field="heroVideo" value={formData.heroVideo} onChange={handleUpload} loading={isCompressing} info="Supports MP4 Video or High-Res Image" recSize="1920x1080" />
                        
                        {/* Slide Manager */}
                        <div className="p-8 bg-stone-50 rounded-[3rem] border border-stone-200 shadow-inner">
                            <div className="flex justify-between items-center mb-8 border-b border-stone-200 pb-4">
                                <h4 className="text-[10px] font-black uppercase text-stone-500 tracking-[0.4em] flex items-center gap-2"><Layers size={14} /> Rotating Hero Text</h4>
                                <button onClick={handleAddSlide} className="flex items-center gap-2 text-[9px] font-black uppercase bg-white px-4 py-2 rounded-xl shadow-sm border border-stone-100 hover:text-brand-crimson transition-colors"><Plus size={12} /> Add Slide</button>
                            </div>

                            {editingSlideId && (
                                <div className="mb-8 p-6 bg-white rounded-2xl border border-stone-200 shadow-lg animate-fade-in">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                        <div><label className="block text-[8px] font-black uppercase text-stone-400 mb-2 tracking-widest">Line 1 (Big)</label><input value={slideForm.line1} onChange={e => setSlideForm({...slideForm, line1: e.target.value})} className={inputClass} placeholder="e.g. Olfactory" /></div>
                                        <div><label className="block text-[8px] font-black uppercase text-stone-400 mb-2 tracking-widest">Line 2 (Italic)</label><input value={slideForm.line2} onChange={e => setSlideForm({...slideForm, line2: e.target.value})} className={inputClass} placeholder="e.g. Art." /></div>
                                        <div className="md:col-span-2"><label className="block text-[8px] font-black uppercase text-stone-400 mb-2 tracking-widest">Quote / Subtext</label><input value={slideForm.quote} onChange={e => setSlideForm({...slideForm, quote: e.target.value})} className={inputClass} placeholder="e.g. We create scents that last..." /></div>
                                        <div className="md:col-span-2">
                                            <label className="block text-[8px] font-black uppercase text-stone-400 mb-2 tracking-widest flex items-center gap-2"><ImageIcon size={10} /> Custom Slide Image (Optional)</label>
                                            <div className="flex gap-4 items-center">
                                                {slideForm.image && (<div className="relative group"><img src={slideForm.image} className="w-16 h-16 rounded-xl object-contain bg-stone-50 border border-stone-200" alt="" /><div className="absolute -top-2 -right-2 bg-stone-800 text-white text-[6px] px-1 rounded">{getImageSize(slideForm.image)}</div></div>)}
                                                <input type="file" ref={slideImageRef} onChange={handleSlideImageUpload} className="hidden" accept="image/*" />
                                                <button type="button" onClick={() => slideImageRef.current?.click()} disabled={isCompressing} className="px-4 py-2 bg-stone-100 rounded-lg text-xs font-bold text-stone-500 hover:bg-stone-200 flex items-center gap-2">
                                                    {isCompressing ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />} 
                                                    Upload Image <span className="opacity-50 text-[8px]">(Rec: 800x800)</span>
                                                </button>
                                                {slideForm.image && <button type="button" onClick={() => setSlideForm({...slideForm, image: ''})} className="text-red-400 hover:text-red-600 text-xs font-bold">Remove</button>}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex justify-end gap-3"><button onClick={() => setEditingSlideId(null)} className="px-4 py-2 text-xs font-bold text-stone-400 hover:text-brand-black">Cancel</button><button onClick={handleSaveSlide} className="px-6 py-2 bg-brand-black text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-brand-crimson transition-all shadow-md">Save Slide</button></div>
                                </div>
                            )}

                            <div className="space-y-3">
                                {(formData.heroSlides || []).map((slide, idx) => (
                                    <div key={slide.id} className="flex items-center justify-between p-4 bg-white border border-stone-100 rounded-2xl group hover:border-brand-black/10 transition-all">
                                        <div className="flex items-center gap-4"><span className="text-xs font-bold text-stone-300 w-6">{(idx + 1).toString().padStart(2, '0')}</span>{slide.image ? (<img src={slide.image} className="w-10 h-10 rounded-lg object-contain bg-stone-50 border border-stone-100" alt="" />) : (<div className="w-10 h-10 rounded-lg bg-stone-50 border border-stone-100 flex items-center justify-center text-stone-300"><Zap size={14}/></div>)}<div><p className="text-sm font-bold text-brand-black">{slide.line1} <span className="font-serif italic text-brand-gold">{slide.line2}</span></p><p className="text-[10px] text-stone-400 truncate max-w-[200px]">{slide.quote}</p></div></div>
                                        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity"><button onClick={() => handleEditSlide(slide)} className="p-2 bg-stone-50 text-brand-black rounded-lg hover:bg-stone-200 transition-colors"><Edit2 size={14} /></button><button onClick={() => handleDeleteSlide(slide.id)} className="p-2 bg-red-50 text-red-500 rounded-lg hover:bg-red-100 transition-colors"><Trash2 size={14} /></button></div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* ... Controls ... */}
                        <div className="p-8 bg-stone-50 rounded-[3rem] border border-stone-200 shadow-inner space-y-6">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-500 flex items-center gap-2"><Sliders size={14} /> Hero Controls</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Main CTA Text</label>
                                    <input name="heroBtnText" value={formData.heroBtnText} onChange={handleChange} className={inputClass} />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Secondary Button</label>
                                        <input name="heroSecondaryBtnText" value={formData.heroSecondaryBtnText} onChange={handleChange} className={inputClass} placeholder="Button Label" />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Button Link</label>
                                        <input name="heroSecondaryBtnLink" value={formData.heroSecondaryBtnLink} onChange={handleChange} className={inputClass} placeholder="/discovery" />
                                    </div>
                                </div>
                                <div className="md:col-span-2">
                                    <div className="flex items-center justify-between mb-2">
                                        <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest flex items-center gap-2"><Sparkles size={12}/> Spotlight Cards (New/Signature)</label>
                                        <button onClick={() => setFormData({...formData, heroShowSpotlight: !formData.heroShowSpotlight})} className={`w-10 h-5 rounded-full p-1 transition-colors ${formData.heroShowSpotlight ? 'bg-brand-black' : 'bg-stone-300'}`}><div className={`w-3 h-3 bg-white rounded-full shadow-sm transition-transform ${formData.heroShowSpotlight ? 'translate-x-5' : 'translate-x-0'}`} /></button>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Overlay Opacity</label>
                                    <input type="range" min="0" max="1" step="0.1" name="heroOverlayOpacity" value={formData.heroOverlayOpacity} onChange={handleChange} className="w-full h-1 bg-stone-200 rounded-full appearance-none cursor-pointer accent-brand-black" />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Overlay Color</label>
                                    <input type="color" name="heroOverlayColor" value={formData.heroOverlayColor} onChange={handleChange} className="w-full h-10 rounded-lg cursor-pointer border border-stone-200" />
                                </div>
                            </div>
                        </div>

                        {/* CORE LANDING PAGE SECTIONS */}
                        <div className="space-y-12 border-t border-stone-100 pt-12">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-500">Landing Page Assets</h4>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div className="space-y-6">
                                    <div className="text-[10px] font-black uppercase text-brand-gold tracking-[0.4em] mb-4">The Core Essence</div>
                                    <ImageUploadBlock label="New Arrival Spotlight" field="featureNewImage" value={formData.featureNewImage} onChange={handleUpload} loading={isCompressing} info="Overrides dynamic product image in 'Just Arrived' card." recSize="1000x1250" />
                                    <ImageUploadBlock label="Signature Scent Spotlight" field="featureBestSellerImage" value={formData.featureBestSellerImage} onChange={handleUpload} loading={isCompressing} info="Overrides dynamic product image in 'Signature Scent' card." recSize="1000x1250" />
                                </div>
                                <div className="space-y-6">
                                    <div className="text-[10px] font-black uppercase text-brand-gold tracking-[0.4em] mb-4">Story & Muse</div>
                                    <ImageUploadBlock label="Philosophy / Heritage" field="philosophyImage" value={formData.philosophyImage} onChange={handleUpload} loading={isCompressing} info="Background for the 'Rooted in Ancient Rituals' section." recSize="1200x1500" />
                                    <ImageUploadBlock label="AI Muse Persona" field="museImage" value={formData.museImage} onChange={handleUpload} loading={isCompressing} info="Visual avatar for the AI Scent Finder section." recSize="1000x1000" />
                                    <ImageUploadBlock label="Home Journal Background" field="homeJournalImage" value={formData.homeJournalImage} onChange={handleUpload} loading={isCompressing} info="Background for the 'Latest Stories' section on Home." recSize="1600x900" />
                                </div>
                            </div>

                            <div className="grid grid-cols-1 gap-8">
                                 <ImageUploadBlock label="Footer Background" field="footerImage" value={formData.footerImage} onChange={handleUpload} loading={isCompressing} info="Full-width background for the site footer." recSize="1920x600" />
                            </div>
                        </div>
                    </div>
                </motion.div>
              )}

              {activeTab === 'pages' && (
                <motion.div key="pages" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="bg-white p-12 rounded-[4rem] border border-stone-200 shadow-sm space-y-16">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-8"><h3 className="text-2xl font-serif font-bold italic flex items-center gap-4"><FileJson size={28} className="text-brand-crimson" /> Inner Pages Visuals</h3></div>
                    
                    <div className="space-y-12">
                        <div className="bg-stone-50 p-8 rounded-[3rem] border border-stone-100">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-black mb-6">Shop / Collection</h4>
                            <ImageUploadBlock label="Collection Header Banner" field="shopBannerImage" value={formData.shopBannerImage} onChange={handleUpload} loading={isCompressing} info="Wide banner (2000px+ width recommended)" recSize="2000x600" />
                            <div className="mt-4"><label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Page Title</label><input name="shopTitle" value={formData.shopTitle} onChange={handleChange} className={inputClass} placeholder="All Scents" /></div>
                        </div>

                        <div className="bg-stone-50 p-8 rounded-[3rem] border border-stone-100">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-black mb-6">Our Story (About)</h4>
                            <ImageUploadBlock label="About Hero Image" field="aboutHeroImage" value={formData.aboutHeroImage} onChange={handleUpload} loading={isCompressing} recSize="1600x900" />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="bg-stone-50 p-8 rounded-[3rem] border border-stone-100">
                                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-black mb-6">Contact / Concierge</h4>
                                <ImageUploadBlock label="Contact Background" field="contactBgImage" value={formData.contactBgImage} onChange={handleUpload} loading={isCompressing} recSize="1600x900" />
                            </div>
                            <div className="bg-stone-50 p-8 rounded-[3rem] border border-stone-100">
                                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-black mb-6">Journal / Blog</h4>
                                <ImageUploadBlock label="Journal Header" field="blogHeaderImage" value={formData.blogHeaderImage} onChange={handleUpload} loading={isCompressing} recSize="1600x600" />
                            </div>
                        </div>
                    </div>
                </motion.div>
              )}

              {/* ... */}
              {activeTab === 'text' && (
                <motion.div key="text" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="bg-white p-12 rounded-[4rem] border border-stone-200 shadow-sm space-y-16">
                    <div className="flex items-center justify-between border-b border-stone-100 pb-8"><h3 className="text-2xl font-serif font-bold italic flex items-center gap-4"><Type size={28} className="text-brand-crimson" /> Text & Titles</h3></div>
                    
                    <div className="space-y-12">
                        {/* Home Page Texts */}
                        <div className="bg-stone-50 p-8 rounded-[3rem] border border-stone-100 space-y-6">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-black mb-2 flex items-center gap-2">Home Page Sections</h4>
                            
                            <div className="mb-6 pb-6 border-b border-stone-200">
                                <label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest mb-2">Hero Static Subtitle</label>
                                <textarea name="heroSubtitle" value={formData.heroSubtitle} onChange={handleChange} rows={2} className={`${inputClass} resize-none`} placeholder="Optional text below the main headline..." />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {/* Section 1 */}
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">Section 1: Spotlight (Title)</label><input name="homeSection1Title" value={formData.homeSection1Title} onChange={handleChange} className={inputClass} /></div>
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">Section 1: Spotlight (Subtitle)</label><textarea name="homeSection1Subtitle" value={formData.homeSection1Subtitle} onChange={handleChange} rows={2} className={inputClass} /></div>
                                {/* Section 2 */}
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">Section 2: New (Title)</label><input name="homeSection2Title" value={formData.homeSection2Title} onChange={handleChange} className={inputClass} /></div>
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">Section 2: New (Subtitle)</label><input name="homeSection2Subtitle" value={formData.homeSection2Subtitle} onChange={handleChange} className={inputClass} /></div>
                                {/* Section 3 */}
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">Section 3: Signature (Title)</label><input name="homeSection3Title" value={formData.homeSection3Title} onChange={handleChange} className={inputClass} /></div>
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">Section 3: Signature (Subtitle)</label><input name="homeSection3Subtitle" value={formData.homeSection3Subtitle} onChange={handleChange} className={inputClass} /></div>
                                {/* Section 4 */}
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">Section 4: Limited (Title)</label><input name="homeSection4Title" value={formData.homeSection4Title} onChange={handleChange} className={inputClass} /></div>
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">Section 4: Limited (Subtitle)</label><input name="homeSection4Subtitle" value={formData.homeSection4Subtitle} onChange={handleChange} className={inputClass} /></div>
                                {/* AI Muse */}
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">AI Muse (Title)</label><input name="homeMuseTitle" value={formData.homeMuseTitle} onChange={handleChange} className={inputClass} /></div>
                                <div className="space-y-2"><label className="block text-[10px] font-black uppercase text-stone-400 tracking-widest">AI Muse (Subtitle)</label><textarea name="homeMuseSubtitle" value={formData.homeMuseSubtitle} onChange={handleChange} rows={2} className={inputClass} /></div>
                            </div>
                        </div>
                        {/* Contact Page */}
                        <div className="bg-stone-50 p-8 rounded-[3rem] border border-stone-100 space-y-6">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-black mb-2 flex items-center gap-2">Contact Page</h4>
                            <div className="grid grid-cols-1 gap-6">
                                <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Main Header</label><input name="contactTitle" value={formData.contactTitle} onChange={handleChange} className={inputClass} /></div>
                                <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Welcome Subtext</label><textarea name="contactSubtitle" value={formData.contactSubtitle} onChange={handleChange} rows={2} className={inputClass} /></div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
                                <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Section 1 (Address)</label><input name="contactSection1Title" value={formData.contactSection1Title} onChange={handleChange} className={inputClass} /></div>
                                <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Section 2 (Email/Phone)</label><input name="contactSection2Title" value={formData.contactSection2Title} onChange={handleChange} className={inputClass} /></div>
                                <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Section 3 (Hours)</label><input name="contactSection3Title" value={formData.contactSection3Title} onChange={handleChange} className={inputClass} /></div>
                            </div>
                        </div>
                        {/* About Page */}
                        <div className="bg-stone-50 p-8 rounded-[3rem] border border-stone-100 space-y-6">
                            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-black mb-2 flex items-center gap-2">About Page</h4>
                            <div className="grid grid-cols-1 gap-6">
                                <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Main Title</label><input name="aboutTitle" value={formData.aboutTitle} onChange={handleChange} className={inputClass} /></div>
                                <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-widest">Story Body Text</label><textarea name="aboutText" value={formData.aboutText} onChange={handleChange} rows={6} className={inputClass} /></div>
                            </div>
                        </div>
                    </div>
                </motion.div>
              )}

              {activeTab === 'marketing' && (
                <div className="bg-white p-12 rounded-[4rem] border border-stone-200 shadow-sm flex flex-col items-center justify-center text-center space-y-6">
                    <Sparkles size={48} className="text-brand-crimson" />
                    <h3 className="text-xl font-bold">Marketing Protocols</h3>
                    <p className="text-stone-500 max-w-md">Marketing rituals like the entrance popup are managed in the dedicated <strong>Marketing</strong> tab in the sidebar for deeper control.</p>
                </div>
              )}

            </AnimatePresence>
          </div>
      </div>
    </div>
  );
};
