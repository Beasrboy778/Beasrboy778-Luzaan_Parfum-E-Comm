
import React, { useState, useEffect } from 'react';
import { Save, MessageSquare, Sparkles, Tag, Image as ImageIcon, Eye, FileText, Truck, Shield, AlignLeft, Info } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { NewsletterConfig, SiteContent } from '../../types';

export const Content: React.FC = () => {
  const { siteContent, updateSiteContent } = useShop();
  const [activeSection, setActiveSection] = useState<keyof SiteContent>('newsletter');
  const [editorContent, setEditorContent] = useState('');
  
  // Dedicated state for newsletter management
  const [newsletterData, setNewsletterData] = useState<NewsletterConfig>(siteContent.newsletter);

  useEffect(() => {
    if (activeSection === 'newsletter') {
        setNewsletterData(siteContent.newsletter);
    } else {
        setEditorContent(siteContent[activeSection] as string);
    }
  }, [activeSection, siteContent]);

  const handleSave = () => {
    if (activeSection === 'newsletter') {
        updateSiteContent('newsletter', newsletterData);
        alert('Marketing configurations saved successfully.');
    } else {
        updateSiteContent(activeSection, editorContent);
        alert(`${pages.find(p => p.id === activeSection)?.label} updated successfully.`);
    }
  };

  const pages = [
    { id: 'newsletter', label: 'Marketing Popup', icon: MessageSquare },
    { id: 'shipping', label: 'Shipping & Returns', icon: Truck }, 
    { id: 'privacy', label: 'Privacy Policy', icon: Shield }, 
    { id: 'terms', label: 'Terms of Service', icon: FileText },
  ];

  const glassInputClass = "w-full bg-white/40 backdrop-blur-md border border-stone-200/50 p-3 rounded-lg text-sm text-brand-black outline-none focus:bg-white/70 focus:border-brand-black transition-all shadow-inner placeholder-stone-400";

  return (
    <div className="animate-fade-in h-full flex flex-col text-brand-black">
      <div className="mb-8 flex justify-between items-center shrink-0">
        <div>
           <h1 className="text-2xl font-bold text-brand-black">Site Content & Legal</h1>
           <p className="text-stone-500 text-sm mt-1">Manage the narrative and policies of your store.</p>
        </div>
        <button 
          onClick={handleSave} 
          className="flex items-center gap-2 px-8 py-3 bg-brand-black text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-stone-800 transition-all shadow-xl active:scale-95"
        >
          <Save size={16} /> Save Record
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 flex-1 min-h-0 overflow-hidden">
        {/* Sidebar Navigation */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 h-full overflow-y-auto shadow-sm">
           <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-6 px-3">Sections</h3>
           <ul className="space-y-2">
             {pages.map(page => (
               <li key={page.id} onClick={() => setActiveSection(page.id as any)}
                 className={`px-5 py-4 rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer transition-all flex items-center gap-3 ${activeSection === page.id ? 'bg-brand-black text-white shadow-lg scale-105' : 'text-stone-500 hover:bg-stone-100 hover:text-brand-black'}`}>
                 <page.icon size={14} />
                 {page.label}
               </li>
             ))}
           </ul>
        </div>
        
        {/* Main Editor Area */}
        <div className="lg:col-span-3 flex flex-col h-full overflow-hidden">
           <div className="bg-white rounded-3xl border border-stone-200 flex-1 flex flex-col overflow-hidden shadow-sm">
             <div className="bg-stone-50 border-b border-stone-200 p-4 flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-500">
                    {activeSection === 'newsletter' ? 'Aesthetic Entrance Ritual' : `Legal Narrative — ${pages.find(p => p.id === activeSection)?.label}`}
                </span>
                {activeSection !== 'newsletter' && (
                    <span className="text-[9px] font-black uppercase text-stone-400 flex items-center gap-1 italic">
                        <Info size={10} /> Auto-formatting: Double Enter = New Paragraph.
                    </span>
                )}
             </div>
             
             {activeSection === 'newsletter' ? (
                 <div className="p-10 space-y-10 overflow-y-auto custom-scrollbar">
                     {/* Master Toggle */}
                     <div className="flex items-center justify-between p-8 bg-stone-50 border border-stone-200 rounded-[2rem] shadow-inner">
                        <div className="flex gap-4 items-center">
                            <div className="p-4 bg-white rounded-2xl shadow-sm text-brand-black"><Eye size={24} /></div>
                            <div>
                                <h4 className="text-brand-black font-bold text-lg mb-1">Popup Visibility</h4>
                                <p className="text-xs text-stone-500 max-w-sm">Toggle the entrance invitation ritual for visitors.</p>
                            </div>
                        </div>
                        <button 
                            onClick={() => setNewsletterData({...newsletterData, enabled: !newsletterData.enabled})}
                            className={`w-16 h-10 rounded-full p-1.5 transition-colors duration-500 ${newsletterData.enabled ? 'bg-brand-crimson shadow-[0_0_15px_rgba(128,0,32,0.3)]' : 'bg-stone-300'}`}
                        >
                            <div className={`w-7 h-7 bg-white rounded-full shadow-md transition-transform duration-500 ${newsletterData.enabled ? 'translate-x-6' : 'translate-x-0'}`} />
                        </button>
                     </div>

                     <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                         <div className="space-y-6">
                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3">Entrance Headline</label>
                                <input type="text" value={newsletterData.title} onChange={e => setNewsletterData({...newsletterData, title: e.target.value})} className={`${glassInputClass} py-4 font-serif italic text-lg`} />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3">Olfactory Narrative</label>
                                <textarea rows={3} value={newsletterData.subtitle} onChange={e => setNewsletterData({...newsletterData, subtitle: e.target.value})} className={`${glassInputClass} resize-none leading-relaxed`} />
                            </div>
                         </div>

                         <div className="space-y-6">
                            <div className="p-8 bg-brand-crimson/5 rounded-3xl border border-brand-crimson/10">
                                <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-brand-crimson mb-4 flex items-center gap-2"><Tag size={12} /> Reward Code</label>
                                <input 
                                    type="text" 
                                    value={newsletterData.code} 
                                    onChange={e => setNewsletterData({...newsletterData, code: e.target.value.toUpperCase()})} 
                                    className={`${glassInputClass} text-2xl font-mono font-bold tracking-[0.5em] text-center bg-white border-brand-crimson/20`}
                                />
                            </div>

                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3 flex items-center gap-2"><ImageIcon size={12} /> Background Image URL</label>
                                <input type="text" value={newsletterData.image} onChange={e => setNewsletterData({...newsletterData, image: e.target.value})} className={glassInputClass} />
                            </div>
                         </div>
                     </div>
                 </div>
             ) : (
                 <div className="flex-1 flex flex-col p-8 bg-[#F9F6F2]">
                     <label className="block text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-4">Plain Text Archive</label>
                     <textarea 
                        value={editorContent} 
                        onChange={(e) => setEditorContent(e.target.value)}
                        className="flex-1 w-full bg-white border border-stone-200 rounded-2xl p-10 text-base font-serif text-brand-black focus:border-brand-black focus:outline-none resize-none leading-loose shadow-inner"
                        placeholder="Type or paste your information here. Use plain text only."
                        spellCheck={true}
                     />
                 </div>
             )}
           </div>
        </div>
      </div>
    </div>
  );
};
