
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { 
  Plus, Search, Edit2, Trash2, X, Save, Filter, 
  Download, AlertCircle, Image as ImageIcon, ImageOff, 
  FileUp, Loader2, CheckCircle2, Link as LinkIcon, FileText, 
  Layers, Package, ChevronRight, Tag, Star, Sparkles,
  Wind, ShieldCheck, Droplet, Ruler, RotateCcw, Upload, Wand2,
  Flame, Waves, MoreVertical, LayoutGrid, LayoutList, Palette,
  AlignLeft, ListPlus, Info, Hash, Weight, Droplets, Zap, Trash,
  Maximize2, ArrowBigUpDash, Diamond, ChevronDown, ChevronUp, Eye, EyeOff as EyeOffIcon, DollarSign, Check
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Product, ProductVariant } from '../../types';
import { motion, AnimatePresence } from 'framer-motion';
import { useCurrency } from '../../context/CurrencyContext';

// --- UTILS ---
const glassInputClass = "w-full bg-white border border-stone-200 py-3 px-4 rounded-xl text-brand-black font-medium outline-none focus:border-brand-black transition-all shadow-sm placeholder-stone-300 text-sm";

const getImageSize = (dataUrl: string) => {
    const sizeInBytes = dataUrl.length * 0.75; 
    const sizeInKb = sizeInBytes / 1024;
    return sizeInKb.toFixed(1) + ' KB';
};

const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 1000;
                let width = img.width;
                let height = img.height;

                if (width > MAX_WIDTH) {
                    height *= MAX_WIDTH / width;
                    width = MAX_WIDTH;
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                const dataUrl = canvas.toDataURL('image/webp', 0.8);
                resolve(dataUrl);
            };
            img.onerror = (error) => reject(error);
        };
        reader.onerror = (error) => reject(error);
    });
};

const Toggle = ({ label, enabled, onChange, icon: Icon }: any) => (
  <div className="flex items-center justify-between p-3 bg-stone-50/50 border border-stone-100 rounded-xl shadow-sm hover:border-brand-black/20 transition-colors cursor-pointer" onClick={() => onChange(!enabled)}>
    <div className="flex items-center gap-3">
      <div className={`p-1.5 rounded-lg transition-colors ${enabled ? 'bg-brand-black text-white' : 'bg-white text-stone-300'}`}>
        {Icon && <Icon size={14} strokeWidth={2.5} />}
      </div>
      <span className="text-[9px] font-black uppercase tracking-widest text-brand-black">{label}</span>
    </div>
    <button type="button" className={`w-9 h-5 rounded-full p-0.5 transition-all duration-500 ${enabled ? 'bg-brand-crimson' : 'bg-stone-200'}`}>
      <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-500 ${enabled ? 'translate-x-4' : 'translate-x-0'}`} />
    </button>
  </div>
);

const NoteAccordion = ({ label, notes, onUpdate, icon: Icon, colorClass, placeholder, isOpen, onToggle }: any) => {
    const [inputValue, setInputValue] = useState('');

    const handleAdd = () => {
        if (!inputValue.trim()) return;
        if (notes.includes(inputValue.trim())) return;
        onUpdate([...notes, inputValue.trim()]);
        setInputValue('');
    };

    const handleRemove = (noteToRemove: string) => {
        onUpdate(notes.filter((n: string) => n !== noteToRemove));
    };

    return (
        <div className={`border transition-all duration-300 rounded-xl overflow-hidden ${isOpen ? 'border-brand-black bg-white shadow-md' : 'border-stone-100 bg-stone-50/50'}`}>
            <button type="button" onClick={onToggle} className="w-full flex items-center justify-between p-4 focus:outline-none">
                <div className={`flex items-center gap-3 ${isOpen ? 'text-brand-black' : 'text-stone-400'}`}>
                    <div className={`p-2 rounded-lg ${isOpen ? colorClass.replace('text-', 'bg-').replace('400', '100').replace('crimson', 'crimson/10').replace('gold', 'gold/10') : 'bg-white'}`}>
                        <Icon size={16} className={isOpen ? colorClass : 'text-stone-300'} />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">{label}</span>
                    <span className="text-[9px] font-bold bg-stone-100 px-2 py-0.5 rounded text-stone-500">{notes.length}</span>
                </div>
                {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
            <AnimatePresence>
                {isOpen && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                        <div className="p-4 pt-0 border-t border-dashed border-stone-100">
                            <div className="flex flex-wrap gap-2 mb-3 mt-4">
                                {notes.map((note: string) => (
                                    <span key={note} className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold ${colorClass.replace('text-', 'bg-').replace('400', '100').replace('crimson', 'crimson/10').replace('gold', 'gold/10')} text-brand-black border border-white shadow-sm`}>
                                        {note}
                                        <button type="button" onClick={() => handleRemove(note)} className="hover:text-red-500"><X size={10} /></button>
                                    </span>
                                ))}
                            </div>
                            <div className="relative">
                                <input type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAdd())} onBlur={handleAdd} placeholder={placeholder} className="w-full bg-stone-50 border border-stone-200 rounded-lg px-4 py-3 text-xs outline-none focus:border-brand-black transition-all" />
                                <button type="button" onClick={handleAdd} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-brand-black text-white rounded-md hover:bg-brand-crimson transition-colors"><Plus size={12} /></button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

// --- IMAGE PREVIEW COMPONENT ---
const ImagePreview = ({ src, onDelete, isMain }: { src: string, onDelete: () => void, isMain?: boolean }) => {
    const [dims, setDims] = useState<string | null>(null);
    return (
        <div className={`relative group overflow-hidden ${isMain ? 'aspect-[4/5] max-h-[350px] bg-stone-50/50 rounded-2xl border-2 border-dashed border-stone-200 shadow-inner' : 'aspect-square bg-stone-50 rounded-xl border border-stone-200'}`}>
            <img 
                src={src} 
                className={`w-full h-full ${isMain ? 'object-contain p-6' : 'object-cover'}`} 
                onLoad={(e) => setDims(`${e.currentTarget.naturalWidth}x${e.currentTarget.naturalHeight}`)}
            />
            {dims && (
                <div className="absolute bottom-2 left-2 right-2 bg-black/70 backdrop-blur-md text-white text-[7px] font-mono rounded px-2 py-1 text-center truncate">
                    {dims} • {getImageSize(src)}
                </div>
            )}
            <button type="button" onClick={(e) => { e.stopPropagation(); onDelete(); }} className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"><X size={10} /></button>
        </div>
    );
};

export const Products: React.FC = () => {
  const { adminProducts, addProduct, updateProduct, deleteProduct } = useShop();
  const { formatPrice } = useCurrency();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isCatOpen, setIsCatOpen] = useState(false);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isProcessingImg, setIsProcessingImg] = useState(false);
  const [activeNoteSection, setActiveNoteSection] = useState<string | null>('top');
  const [tagInput, setTagInput] = useState('');
  const [newVariant, setNewVariant] = useState<ProductVariant>({ size: '', price: 0, compareAtPrice: 0 });

  const [formData, setFormData] = useState<Product>({
    id: '', sku: '', name: '', tagline: '', price: 0, compareAtPrice: 0, description: '', category: 'Unisex', stock: 100, images: [], size: '100ml', 
    sizes: ['30ml', '50ml', '100ml'], isBestSeller: false, isNew: true, isLimitedEdition: false, color: '#CFA75E',
    notes: { top: [], heart: [], base: [] }, highlights: [], tags: [], isActive: true, variants: []
  });

  useEffect(() => {
    if (isModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isModalOpen]);

  const filteredProducts = useMemo(() => {
    return adminProducts.filter(p => {
        const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.sku?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
        return matchesSearch && matchesCategory;
    });
  }, [adminProducts, searchTerm, selectedCategory]);

  const handleOpenAdd = () => {
      setIsEditMode(false);
      setFormData({
          id: 'p-' + Date.now(),
          sku: 'LZ-' + Math.random().toString(36).substr(2, 6).toUpperCase(),
          name: '', tagline: '', price: 0, compareAtPrice: 0, description: '', category: 'Unisex', stock: 100, images: [], size: '100ml', 
          sizes: [], isBestSeller: false, isNew: true, isLimitedEdition: false, color: '#CFA75E', 
          notes: { top: [], heart: [], base: [] }, tags: [], highlights: [], isActive: true, variants: []
      });
      setActiveNoteSection('top');
      setIsModalOpen(true);
  };

  const handleOpenEdit = (product: Product) => {
      setIsEditMode(true);
      let initializedVariants = product.variants || [];
      if (initializedVariants.length === 0 && product.sizes && product.sizes.length > 0) {
          initializedVariants = product.sizes.map(s => ({
              size: s,
              price: product.price,
              compareAtPrice: product.compareAtPrice
          }));
      }
      setFormData({
        ...product, 
        sku: product.sku || 'LZ-' + Math.random().toString(36).substr(2, 6).toUpperCase(),
        isActive: product.isActive !== undefined ? product.isActive : true,
        sizes: product.sizes || [],
        images: product.images || [],
        notes: product.notes || { top: [], heart: [], base: [] },
        tags: product.tags || [],
        variants: initializedVariants
      });
      setActiveNoteSection('top');
      setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent | React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (!formData.name?.trim()) { alert('Product Name is required.'); return; }
      
      const derivedSizes = formData.variants?.map(v => v.size) || formData.sizes;
      const productData: Product = { 
        ...formData, 
        id: formData.id || `p-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        sizes: derivedSizes,
        variants: formData.variants || []
      };

      if (isEditMode) updateProduct(productData);
      else addProduct(productData);
      setIsModalOpen(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (!files || files.length === 0) return;
      setIsProcessingImg(true);
      try {
          const processedImages: string[] = [];
          for (const file of Array.from(files)) {
              processedImages.push(await compressImage(file as File));
          }
          setFormData(prev => ({ ...prev, images: [...(prev.images || []), ...processedImages] }));
      } catch (err) { alert("Failed to process image."); } finally { setIsProcessingImg(false); e.target.value = ''; }
  };

  const removeImage = (index: number) => {
      setFormData(prev => ({ ...prev, images: prev.images.filter((_, i) => i !== index) }));
  };

  const promoteToMaster = (index: number) => {
      if (index === 0) return;
      setFormData(prev => {
          const newImages = [...prev.images];
          const [selected] = newImages.splice(index, 1);
          newImages.unshift(selected);
          return { ...prev, images: newImages };
      });
  };

  const addVariant = () => {
      if (!newVariant.size.trim()) { alert('Size is required'); return; }
      const price = parseFloat(newVariant.price as any) || 0;
      const compareAt = parseFloat(newVariant.compareAtPrice as any) || 0;
      const variantToAdd = { ...newVariant, price, compareAtPrice: compareAt };

      setFormData(prev => {
          const updatedVariants = [...(prev.variants || [])];
          const existingIdx = updatedVariants.findIndex(v => v.size === variantToAdd.size);
          if (existingIdx >= 0) updatedVariants[existingIdx] = variantToAdd;
          else updatedVariants.push(variantToAdd);
          return { ...prev, variants: updatedVariants, sizes: updatedVariants.map(v => v.size) };
      });
      setNewVariant({ size: '', price: 0, compareAtPrice: 0 });
  };

  const removeVariant = (size: string) => {
      setFormData(prev => {
          const updatedVariants = (prev.variants || []).filter(v => v.size !== size);
          return { ...prev, variants: updatedVariants, sizes: updatedVariants.map(v => v.size) };
      });
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter' && tagInput.trim()) {
          e.preventDefault();
          if (!formData.tags?.includes(tagInput.trim())) {
              setFormData(prev => ({ ...prev, tags: [...(prev.tags || []), tagInput.trim()] }));
          }
          setTagInput('');
      }
  };

  const categoriesList = ['All', 'Men', 'Women', 'Unisex', 'Attar'];

  return (
    <div className="animate-fade-in relative text-brand-black pb-12">
      {/* STICKY HEADER */}
      <div className="sticky -top-4 lg:-top-8 z-30 bg-[#FAFAFA]/95 backdrop-blur-md pb-6 pt-4 lg:pt-8 mb-6 -mx-4 lg:-mx-8 px-4 lg:px-8 border-b border-stone-200/50 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 shadow-sm transition-all">
        <div>
            <h1 className="text-3xl font-serif italic text-brand-black leading-tight">Archive Registry</h1>
            <p className="text-stone-500 text-xs lg:text-sm mt-1">Configure your signature olfactory library.</p>
        </div>
        <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleOpenAdd} 
            className="w-full lg:w-auto flex items-center justify-center gap-3 px-8 lg:px-10 py-5 bg-brand-black text-white rounded-[2rem] text-[10px] font-black uppercase tracking-[0.4em] hover:bg-brand-crimson transition-all shadow-2xl group"
        >
            <Plus size={18} className="group-hover:rotate-90 transition-transform" /> Register New Creation
        </motion.button>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-xl border border-stone-200 overflow-visible relative z-20">
         <div className="p-6 lg:p-8 border-b border-stone-100 bg-stone-50/30 flex flex-col xl:flex-row gap-4 lg:gap-6 justify-between items-center">
            <div className="relative w-full xl:max-w-md">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                <input type="text" placeholder="Search by name or SKU..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-14 pr-6 py-4 border border-stone-200 rounded-2xl text-sm outline-none focus:border-brand-black bg-white transition-all shadow-inner" />
            </div>
            
            {/* Custom Modern White Dropdown */}
            <div className="relative w-full lg:w-64 z-50">
                <button 
                    onClick={() => setIsCatOpen(!isCatOpen)}
                    className="w-full bg-white border border-stone-200 px-6 py-4 rounded-2xl flex justify-between items-center shadow-sm hover:border-brand-black transition-colors"
                >
                    <span className="text-[10px] font-black uppercase tracking-widest text-brand-black">{selectedCategory === 'All' ? 'All Categories' : selectedCategory}</span>
                    <motion.div animate={{ rotate: isCatOpen ? 180 : 0 }}>
                        <ChevronDown size={14} className="text-brand-black" />
                    </motion.div>
                </button>
                <AnimatePresence>
                    {isCatOpen && (
                        <motion.ul
                            initial={{ opacity: 0, y: 10, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.95 }}
                            transition={{ duration: 0.2 }}
                            className="absolute top-full right-0 mt-2 w-full bg-white border border-stone-100 rounded-2xl shadow-xl overflow-hidden py-2"
                        >
                            {categoriesList.map((cat) => (
                                <motion.li 
                                    key={cat}
                                    whileHover={{ backgroundColor: '#F5F5F4' }} // bg-stone-100
                                    onClick={() => { setSelectedCategory(cat); setIsCatOpen(false); }}
                                    className="px-6 py-3 cursor-pointer flex justify-between items-center group"
                                >
                                    <span className={`text-[10px] font-bold uppercase tracking-widest ${selectedCategory === cat ? 'text-brand-black' : 'text-stone-500 group-hover:text-brand-black'}`}>{cat === 'All' ? 'All Categories' : cat}</span>
                                    {selectedCategory === cat && <Check size={12} className="text-brand-black" />}
                                </motion.li>
                            ))}
                        </motion.ul>
                    )}
                </AnimatePresence>
            </div>
         </div>

         <div className="overflow-x-auto custom-scrollbar relative z-10">
            <table className="w-full text-left text-sm min-w-[900px]">
                <thead className="bg-stone-50 text-stone-400 uppercase text-[9px] lg:text-[10px] font-black tracking-[0.4em] border-b border-stone-100">
                <tr><th className="px-6 lg:px-8 py-6">Asset Narrative</th><th className="px-6 lg:px-8 py-6">Category</th><th className="px-6 lg:px-8 py-6">Status & Visibility</th><th className="px-6 lg:px-8 py-6">Availability</th><th className="px-6 lg:px-8 py-6">Base Valuation</th><th className="px-6 lg:px-8 py-6 text-right">Rituals</th></tr>
                </thead>
                <tbody className="divide-y divide-stone-50">
                {filteredProducts.map((product) => (
                    <tr key={product.id} className="hover:bg-stone-50/80 transition-colors group cursor-pointer" onClick={() => handleOpenEdit(product)}>
                        <td className="px-6 lg:px-8 py-6">
                            <div className="flex items-center gap-4 lg:gap-6">
                                <div className="w-14 h-14 lg:w-16 lg:h-16 bg-white border border-stone-100 rounded-2xl overflow-hidden p-2 flex items-center justify-center shadow-sm relative">
                                    {product.images[0] ? <img src={product.images[0]} alt="" className="w-full h-full object-contain" /> : <div className="text-stone-200"><ImageOff size={18} /></div>}
                                </div>
                                <div><p className="font-bold text-brand-black text-base lg:text-lg leading-tight mb-0.5">{product.name}</p><p className="text-[8px] lg:text-[9px] font-black uppercase tracking-widest text-stone-400 italic">REF: {product.sku || 'N/A'}</p></div>
                            </div>
                        </td>
                        <td className="px-6 lg:px-8 py-6"><span className="px-3 lg:px-4 py-1.5 bg-stone-100 text-stone-500 rounded-full text-[8px] lg:text-[9px] font-black uppercase tracking-widest">{product.category}</span></td>
                        <td className="px-6 lg:px-8 py-6"><div className="flex flex-wrap gap-2">{product.isBestSeller && <div className="flex items-center gap-1.5 px-2.5 py-1 bg-brand-gold/10 text-brand-gold rounded-full border border-brand-gold/20"><Star size={10} fill="currentColor" /><span className="text-[8px] font-black uppercase tracking-widest">Signature</span></div>}{product.isNew && <div className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-500 rounded-full border border-blue-100"><Sparkles size={10} /><span className="text-[8px] font-black uppercase tracking-widest">New</span></div>}</div></td>
                        <td className="px-6 lg:px-8 py-6">
                            <motion.div whileHover={{ scale: 1.05 }} className="flex items-center gap-3 bg-white border border-stone-100 px-3 py-1.5 rounded-xl w-fit shadow-sm">
                                <div className={`w-2 h-2 rounded-full ${product.stock && product.stock > 10 ? 'bg-green-500' : 'bg-red-500'}`} />
                                <span className="font-black text-[10px] uppercase tracking-widest text-stone-600">{product.stock || 0} Units</span>
                            </motion.div>
                        </td>
                        <td className="px-6 lg:px-8 py-6 font-serif font-bold text-lg lg:text-xl text-brand-black">{formatPrice(product.price)}</td>
                        <td className="px-6 lg:px-8 py-6 text-right" onClick={(e) => e.stopPropagation()}><div className="flex justify-end gap-2">
                            <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => handleOpenEdit(product)} className="p-3 bg-white border border-stone-200 rounded-xl hover:bg-brand-black hover:text-white transition-all shadow-sm"><Edit2 size={14} /></motion.button>
                            <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => deleteProduct(product.id)} className="p-3 bg-white border border-stone-200 rounded-xl hover:bg-red-50 hover:text-red-500 transition-all shadow-sm"><Trash2 size={14} /></motion.button>
                        </div></td>
                    </tr>
                ))}
                </tbody>
            </table>
         </div>
      </div>

      <AnimatePresence>
        {isModalOpen && (
            <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }} 
                className="fixed inset-0 z-[2000] flex items-start justify-center bg-white/60 backdrop-blur-md pt-16 md:pt-24 pb-8 px-4 sm:px-6 md:px-8" 
                onClick={() => setIsModalOpen(false)}
            >
                <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }} 
                    animate={{ scale: 1, opacity: 1 }} 
                    exit={{ scale: 0.95, opacity: 0 }} 
                    className="bg-white w-full max-w-5xl rounded-[2rem] shadow-2xl border border-stone-200 flex flex-col max-h-[calc(100dvh-6rem)] relative overflow-hidden" 
                    onClick={e => e.stopPropagation()}
                >
                    {/* Header */}
                    <div className="flex justify-between items-center p-5 lg:p-6 border-b border-stone-100 bg-[#FCFBFA]/90 backdrop-blur sticky top-0 z-20 shrink-0">
                        <div><h2 className="text-xl font-serif italic text-brand-black tracking-tight">{isEditMode ? 'Modify Record' : 'New Essence'}</h2><p className="text-[9px] font-black uppercase text-stone-400 tracking-[0.2em] mt-1">ARCHIVE PROTOCOL v2.5</p></div>
                        <button type="button" onClick={() => setIsModalOpen(false)} className="w-9 h-9 rounded-full bg-white border border-stone-100 flex items-center justify-center text-stone-400 hover:text-brand-black transition-all shadow-md active:scale-90"><X size={16} /></button>
                    </div>
                    
                    <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-5 lg:p-8 space-y-8 bg-white custom-scrollbar overscroll-contain">
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10">
                            {/* Left Side: Asset Management */}
                            <div className="lg:col-span-5 space-y-6">
                                <div>
                                    <label className="block text-[8px] font-black uppercase tracking-[0.4em] text-stone-400 mb-3">Asset Gallery</label>
                                    <div className="space-y-3">
                                        {/* Primary Image Uploader */}
                                        {isProcessingImg ? (
                                            <div className="aspect-[4/5] bg-stone-50 rounded-2xl flex flex-col items-center justify-center gap-2 border-2 border-dashed border-brand-black/20">
                                                <Loader2 size={24} className="animate-spin text-brand-black" />
                                                <span className="text-[9px] font-bold uppercase tracking-widest text-stone-400">Optimizing...</span>
                                            </div>
                                        ) : formData.images?.[0] ? (
                                            <ImagePreview src={formData.images[0]} onDelete={() => removeImage(0)} isMain />
                                        ) : (
                                            <div className="aspect-[4/5] bg-stone-50 rounded-2xl border-2 border-dashed border-stone-200 flex flex-col items-center justify-center relative hover:border-brand-black transition-all">
                                                <div className="text-stone-300 flex flex-col items-center gap-2">
                                                    <ImageIcon size={32} strokeWidth={1} />
                                                    <span className="text-[8px] font-black uppercase tracking-widest text-center">Primary Visual</span>
                                                    <span className="text-[7px] font-mono text-stone-400 bg-stone-100 px-1.5 py-0.5 rounded">Rec: 800x1000px</span>
                                                </div>
                                                <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" onChange={handleFileUpload} />
                                            </div>
                                        )}

                                        <div className="grid grid-cols-4 gap-2">
                                            {formData.images?.slice(1).map((img, idx) => (
                                                <div key={idx} onClick={() => promoteToMaster(idx + 1)} className="cursor-pointer">
                                                    <ImagePreview src={img} onDelete={() => removeImage(idx + 1)} />
                                                </div>
                                            ))}
                                            <div className="aspect-square bg-white border-2 border-dashed border-stone-200 rounded-xl flex items-center justify-center text-stone-300 hover:border-brand-black transition-all cursor-pointer relative shadow-inner">
                                                <Plus size={16} />
                                                <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" multiple onChange={handleFileUpload} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Toggle label="Archive Visible" enabled={formData.isActive} onChange={(val: boolean) => setFormData({...formData, isActive: val})} icon={ShieldCheck} />
                                    <Toggle label="Signature Scent" enabled={formData.isBestSeller} onChange={(val: boolean) => setFormData({...formData, isBestSeller: val})} icon={Star} />
                                    <Toggle label="New Arrival" enabled={formData.isNew} onChange={(val: boolean) => setFormData({...formData, isNew: val})} icon={Sparkles} />
                                    <Toggle label="Limited Edition" enabled={formData.isLimitedEdition} onChange={(val: boolean) => setFormData({...formData, isLimitedEdition: val})} icon={Diamond} />
                                </div>
                            </div>

                            {/* Right Side: Identity & Architecture */}
                            <div className="lg:col-span-7 space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-5">
                                    <div className="md:col-span-2"><label className="block text-[9px] font-black uppercase tracking-[0.4em] text-stone-400 mb-2">Designation</label><input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className={`${glassInputClass} text-lg font-serif italic py-3`} placeholder="Essence Name" /></div>
                                    <div className="md:col-span-2"><label className="block text-[9px] font-black uppercase tracking-[0.4em] text-stone-400 mb-2">Poetic Tagline</label><input type="text" value={formData.tagline} onChange={e => setFormData({...formData, tagline: e.target.value})} className={`${glassInputClass} font-serif italic py-3`} placeholder="Short poetic description" /></div>
                                    <div><label className="block text-[9px] font-black uppercase text-stone-400 mb-2 tracking-widest">SKU</label><input type="text" value={formData.sku} onChange={e => setFormData({...formData, sku: e.target.value.toUpperCase()})} className={`${glassInputClass} font-mono font-bold uppercase`} placeholder="LZ-XXXX" /></div>
                                    <div><label className="block text-[9px] font-black uppercase text-stone-400 mb-2 tracking-widest">Category</label><select value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className={`${glassInputClass} cursor-pointer`}><option value="Men">Men</option><option value="Women">Women</option><option value="Unisex">Unisex</option><option value="Attar">Attar</option></select></div>
                                    <div><label className="block text-[9px] font-black uppercase text-stone-400 mb-2 tracking-widest">Base Price (₹)</label><input type="number" value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} className={`${glassInputClass} font-bold`} /></div>
                                    <div><label className="block text-[9px] font-black uppercase text-stone-400 mb-2 tracking-widest">Stock</label><input type="number" value={formData.stock} onChange={e => setFormData({...formData, stock: parseInt(e.target.value)})} className={`${glassInputClass} font-bold`} /></div>
                                </div>

                                {/* VARIANT MANAGER */}
                                <div className="p-5 bg-stone-50 rounded-2xl border border-stone-200">
                                    <label className="block text-[9px] font-black uppercase tracking-[0.4em] text-brand-black mb-4 flex items-center gap-2"><Ruler size={12} /> Sizes & Variants</label>
                                    <div className="flex flex-col sm:flex-row gap-3 mb-4">
                                        <input placeholder="Size (e.g. 50ml)" value={newVariant.size} onChange={e => setNewVariant({...newVariant, size: e.target.value})} className={`${glassInputClass} flex-1`} />
                                        <div className="flex gap-3">
                                            <input type="number" placeholder="Price" value={newVariant.price || ''} onChange={e => setNewVariant({...newVariant, price: parseFloat(e.target.value)})} className={`${glassInputClass} w-24`} />
                                            <input type="number" placeholder="Cutoff" value={newVariant.compareAtPrice || ''} onChange={e => setNewVariant({...newVariant, compareAtPrice: parseFloat(e.target.value)})} className={`${glassInputClass} w-24`} />
                                            <button type="button" onClick={addVariant} className="bg-brand-black text-white p-3 rounded-xl hover:bg-stone-800 transition-colors shrink-0"><Plus size={16} /></button>
                                        </div>
                                    </div>
                                    <div className="space-y-2 max-h-32 overflow-y-auto custom-scrollbar">
                                        {formData.variants && formData.variants.length > 0 ? (formData.variants.map((v, idx) => ( <div key={idx} className="flex items-center justify-between p-3 bg-white border border-stone-100 rounded-xl text-sm"><span className="font-bold w-1/3">{v.size}</span><span className="font-mono">{formatPrice(v.price)}</span><span className="font-mono text-stone-400 line-through text-xs">{v.compareAtPrice ? formatPrice(v.compareAtPrice) : '-'}</span><button type="button" onClick={() => removeVariant(v.size)} className="text-stone-300 hover:text-red-500"><X size={14} /></button></div> ))) : ( <div className="text-center py-4 text-stone-400 text-xs italic">No variants defined. Using base price.</div> )}
                                    </div>
                                </div>

                                {/* Custom Tags Section */}
                                <div>
                                    <label className="block text-[9px] font-black uppercase tracking-[0.4em] text-stone-400 mb-2">Custom Tags</label>
                                    <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 flex flex-wrap gap-2 min-h-[50px] focus-within:border-brand-black transition-colors">
                                        {formData.tags?.map(tag => ( <span key={tag} className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-[9px] font-bold uppercase tracking-wide text-brand-black shadow-sm">{tag}<button type="button" onClick={() => setFormData(prev => ({ ...prev, tags: prev.tags?.filter(t => t !== tag) }))} className="hover:text-red-500"><X size={12} /></button></span> ))}
                                        <input type="text" value={tagInput} onChange={(e) => setTagInput(e.target.value)} onKeyDown={handleAddTag} placeholder="Type & Enter..." className="bg-transparent text-xs outline-none flex-1 min-w-[80px]" />
                                    </div>
                                </div>

                                <div className="p-5 bg-stone-50/50 rounded-2xl border border-stone-100 shadow-inner space-y-3">
                                    <div className="flex items-center justify-between border-b border-stone-200/50 pb-2 mb-2"><label className="text-[8px] font-black uppercase tracking-[0.4em] text-stone-500">Olfactory Architecture</label></div>
                                    <NoteAccordion label="Top Notes" icon={Wind} colorClass="text-blue-400" notes={formData.notes.top} isOpen={activeNoteSection === 'top'} onToggle={() => setActiveNoteSection(activeNoteSection === 'top' ? null : 'top')} onUpdate={(val: string[]) => setFormData({...formData, notes: {...formData.notes, top: val}})} placeholder="Add ingredient..." />
                                    <NoteAccordion label="Heart Notes" icon={Waves} colorClass="text-brand-crimson" notes={formData.notes.heart} isOpen={activeNoteSection === 'heart'} onToggle={() => setActiveNoteSection(activeNoteSection === 'heart' ? null : 'heart')} onUpdate={(val: string[]) => setFormData({...formData, notes: {...formData.notes, heart: val}})} placeholder="Add ingredient..." />
                                    <NoteAccordion label="Base Notes" icon={Flame} colorClass="text-brand-gold" notes={formData.notes.base} isOpen={activeNoteSection === 'base'} onToggle={() => setActiveNoteSection(activeNoteSection === 'base' ? null : 'base')} onUpdate={(val: string[]) => setFormData({...formData, notes: {...formData.notes, base: val}})} placeholder="Add ingredient..." />
                                </div>

                                <div><label className="block text-[9px] font-black uppercase tracking-[0.4em] text-stone-400 mb-2 flex items-center gap-1.5"><AlignLeft size={12} /> Full Narrative</label><textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} rows={4} className={`${glassInputClass} resize-none font-serif italic text-sm p-4 leading-relaxed shadow-inner`} placeholder="The soul of the essence..." /></div>
                            </div>
                        </div>
                    </form>

                    <div className="p-5 lg:p-6 border-t border-stone-100 bg-[#FCFBFA]/90 backdrop-blur shrink-0 flex justify-between items-center sticky bottom-0 z-20">
                        <span className="text-stone-400 italic text-[8px] font-serif uppercase tracking-widest hidden md:inline">Record integrity check passed.</span>
                        <div className="flex gap-3 w-full md:w-auto justify-end">
                            <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-3 text-stone-400 hover:text-brand-black text-[9px] font-black uppercase tracking-[0.3em] transition-all">Discard</button>
                            <button type="button" onClick={handleSave} className="flex-1 md:flex-none px-8 py-3 bg-brand-black text-white rounded-xl text-[9px] font-black uppercase tracking-[0.4em] hover:bg-brand-crimson transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2 group"><Save size={16} className="group-hover:scale-110" /> Finalize Record</button>
                        </div>
                    </div>
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
