
import React, { useState, useEffect } from 'react';
import { AlertTriangle, ArrowDown, ArrowUp, Download, RefreshCw, Search, Edit2, X, Check, Save, ChevronDown, Minus, Plus } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { InventoryLog } from '../../types';
import { AnimatePresence, motion } from 'framer-motion';
import { useCurrency } from '../../context/CurrencyContext';

export const Inventory: React.FC = () => {
  const { adminProducts, updateProduct, logAdminActivity } = useShop();
  const { formatPrice } = useCurrency();
  const [searchTerm, setSearchTerm] = useState('');
  
  // Adjustment Modal State
  const [adjustingProduct, setAdjustingProduct] = useState<any>(null);
  const [adjustmentAmount, setAdjustmentAmount] = useState<number>(0);
  const [adjustmentReason, setAdjustmentReason] = useState('Restock');
  const [isReasonOpen, setIsReasonOpen] = useState(false);

  const inventoryLogs: InventoryLog[] = [
    { id: '1', productName: 'Midnight Oud', change: -1, reason: 'Order', date: '2023-10-24 14:30' },
    { id: '2', productName: 'Royal Santal', change: -1, reason: 'Order', date: '2023-10-24 12:15' },
    { id: '3', productName: 'Crimson Rose', change: 50, reason: 'Restock', date: '2023-10-23 09:00' },
    { id: '4', productName: 'Amber Dust', change: -1, reason: 'Adjustment', date: '2023-10-22 16:45' },
  ];

  const reasons = ['Restock', 'Correction', 'Damage', 'Return', 'Marketing'];

  // Lock scroll when modal is open
  useEffect(() => {
    if (adjustingProduct) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [adjustingProduct]);

  const handleExportCSV = () => {
    const headers = ['Product Name', 'SKU', 'Category', 'Stock', 'Price', 'Status'];
    const rows = adminProducts.map(p => {
      const stock = p.stock || 0;
      const status = stock > 0 ? 'In Stock' : 'Out of Stock';
      const safeName = p.name.replace(/"/g, '""');
      return [`"${safeName}"`, `SKU-${p.id.substring(0, 4).toUpperCase()}`, p.category, stock, p.price, status];
    });
    const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `inventory_export_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveAdjustment = () => {
      if (adjustingProduct && adjustmentAmount !== 0) {
          const newStock = Math.max(0, (adjustingProduct.stock || 0) + adjustmentAmount);
          updateProduct({ ...adjustingProduct, stock: newStock });
          
          // Log (Simulated in this demo, real app would push to DB)
          logAdminActivity('Inventory Adjustment', `Adjusted ${adjustingProduct.name} by ${adjustmentAmount} (${adjustmentReason})`);
          
          setAdjustingProduct(null);
          setAdjustmentAmount(0);
          setAdjustmentReason('Restock');
          setIsReasonOpen(false);
      }
  };

  const filteredProducts = adminProducts.filter(p => 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const lowStockCount = adminProducts.filter(p => (p.stock || 0) < 10).length;
  const totalStockValue = adminProducts.reduce((acc, p) => acc + (p.price * (p.stock || 0)), 0);

  return (
    <div className="animate-fade-in relative pb-20">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-brand-black">Inventory Management</h1>
          <p className="text-stone-500 text-sm mt-1">Real-time stock monitoring and logs.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-stone-200 rounded-lg text-sm font-bold text-stone-600 hover:bg-stone-50 shadow-sm transition-colors"
          >
            <Download size={16} /> Export CSV
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
          <h3 className="text-stone-500 text-sm font-medium mb-4">Total Products</h3>
          <p className="text-3xl font-bold text-brand-black">{adminProducts.length}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
          <h3 className="text-stone-500 text-sm font-medium mb-4">Low Stock Alerts</h3>
          <p className="text-3xl font-bold text-brand-black text-brand-crimson">{lowStockCount}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
          <h3 className="text-stone-500 text-sm font-medium mb-4">Total Stock Value</h3>
          <p className="text-3xl font-bold text-brand-black">{formatPrice(totalStockValue)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden">
          <div className="p-6 border-b border-stone-200 flex justify-between items-center bg-stone-50/50">
            <h3 className="font-bold text-brand-black">Current Stock Levels</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={16} />
              <input 
                type="text" 
                placeholder="Search SKU or Name..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 pr-4 py-2 border border-stone-300 rounded-lg text-sm outline-none focus:border-brand-black bg-white text-brand-black w-64" 
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-stone-600">
                <thead className="bg-stone-50 border-b border-stone-200 text-xs uppercase font-bold text-stone-500">
                <tr>
                    <th className="px-6 py-4">Product</th>
                    <th className="px-6 py-4">Category</th>
                    <th className="px-6 py-4">Stock</th>
                    <th className="px-6 py-4">Action</th>
                </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                {filteredProducts.map(product => {
                    const stock = product.stock || 0;
                    return (
                    <tr key={product.id} className="hover:bg-stone-50 transition-colors">
                        <td className="px-6 py-4 font-medium text-brand-black">
                            <div className="flex items-center gap-3">
                                {product.images[0] ? (
                                    <div className="w-10 h-10 bg-white border border-stone-200 rounded-md overflow-hidden p-0.5 flex items-center justify-center">
                                        <img src={product.images[0]} className="w-full h-full object-contain" alt="" />
                                    </div>
                                ) : (
                                    <div className="w-10 h-10 bg-stone-100 rounded-md"></div>
                                )}
                                <div>
                                    <p className="font-bold text-xs">{product.name}</p>
                                    <p className="text-[10px] text-stone-400">{product.sku}</p>
                                </div>
                            </div>
                        </td>
                        <td className="px-6 py-4 text-xs uppercase">{product.category}</td>
                        <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                                <span className="text-xs font-bold">{stock}</span>
                                <span className={`w-2 h-2 rounded-full ${stock > 10 ? 'bg-green-500' : stock > 0 ? 'bg-yellow-500' : 'bg-red-500'}`} />
                            </div>
                        </td>
                        <td className="px-6 py-4">
                            <button 
                                onClick={() => { setAdjustingProduct(product); setAdjustmentAmount(0); setIsReasonOpen(false); }}
                                className="text-[10px] font-bold uppercase tracking-wider text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-md border border-blue-100 transition-colors flex items-center gap-1"
                            >
                                <Edit2 size={10} /> Adjust
                            </button>
                        </td>
                    </tr>
                    );
                })}
                </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-stone-200 h-fit">
          <div className="p-6 border-b border-stone-200">
            <h3 className="font-bold text-brand-black">Recent Activity</h3>
          </div>
          <div className="divide-y divide-stone-100">
            {inventoryLogs.map(log => (
              <div key={log.id} className="p-4 flex items-start gap-3">
                <div className={`mt-1 p-1 rounded-full ${log.change > 0 ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                  {log.change > 0 ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
                </div>
                <div>
                  <p className="text-sm font-medium text-brand-black">{log.productName}</p>
                  <p className="text-xs text-stone-500">{log.reason} • {Math.abs(log.change)} units</p>
                  <p className="text-[10px] text-stone-400 mt-1">{log.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <AnimatePresence>
          {adjustingProduct && (
              <div className="fixed inset-0 z-[2000] flex items-start justify-center bg-white/80 backdrop-blur-xl pt-24 md:pt-32 px-4">
                  <motion.div 
                    initial={{ scale: 0.9, opacity: 0, y: 20 }}
                    animate={{ scale: 1, opacity: 1, y: 0 }}
                    exit={{ scale: 0.9, opacity: 0, y: 20 }}
                    transition={{ type: "spring", stiffness: 300, damping: 25 }}
                    className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl border border-stone-200 overflow-visible relative flex flex-col"
                  >
                      {/* Close Button Absolute */}
                      <button 
                        onClick={() => setAdjustingProduct(null)} 
                        className="absolute -top-4 -right-4 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center shadow-lg hover:bg-brand-crimson transition-all z-50 hover:rotate-90"
                      >
                        <X size={18} />
                      </button>

                      <div className="p-8 pb-4">
                          <h3 className="font-serif text-3xl font-bold text-brand-black italic mb-1 text-center">Adjust Stock</h3>
                          <p className="text-center text-xs font-bold uppercase tracking-widest text-stone-400">Inventory Control</p>
                      </div>

                      <div className="px-8 pb-8 space-y-8">
                          {/* Product Mini Card */}
                          <div className="flex items-center gap-4 bg-stone-50 p-4 rounded-2xl border border-stone-100">
                              <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center border border-stone-200 p-2 shadow-sm">
                                  <img src={adjustingProduct.images[0]} className="w-full h-full object-contain" alt="" />
                              </div>
                              <div>
                                  <h4 className="font-bold text-brand-black">{adjustingProduct.name}</h4>
                                  <p className="text-[10px] font-black uppercase tracking-widest text-stone-400">Current Stock: <span className="text-brand-black">{adjustingProduct.stock}</span></p>
                              </div>
                          </div>

                          {/* Animated Amount Adjuster */}
                          <div className="text-center">
                              <label className="block text-[10px] font-black uppercase text-stone-400 mb-4 tracking-[0.2em]">Quantity Change</label>
                              <div className="flex items-center justify-center gap-6">
                                  <motion.button 
                                    whileTap={{ scale: 0.8 }} 
                                    onClick={() => setAdjustmentAmount(p => p - 1)} 
                                    className="w-14 h-14 rounded-2xl border-2 border-stone-100 flex items-center justify-center hover:border-brand-black hover:bg-stone-50 transition-all text-stone-400 hover:text-brand-black"
                                  >
                                      <Minus size={24} />
                                  </motion.button>
                                  
                                  <div className="w-32 h-20 flex items-center justify-center relative overflow-hidden">
                                      <AnimatePresence mode="popLayout">
                                          <motion.span 
                                            key={adjustmentAmount}
                                            initial={{ y: 20, opacity: 0, scale: 0.8 }}
                                            animate={{ y: 0, opacity: 1, scale: 1 }}
                                            exit={{ y: -20, opacity: 0, scale: 0.8 }}
                                            transition={{ type: "spring", stiffness: 900, damping: 15 }}
                                            className={`text-5xl font-serif font-bold absolute ${adjustmentAmount > 0 ? 'text-green-600' : adjustmentAmount < 0 ? 'text-red-500' : 'text-stone-300'}`}
                                          >
                                              {adjustmentAmount > 0 ? `+${adjustmentAmount}` : adjustmentAmount}
                                          </motion.span>
                                      </AnimatePresence>
                                  </div>

                                  <motion.button 
                                    whileTap={{ scale: 0.8 }} 
                                    onClick={() => setAdjustmentAmount(p => p + 1)} 
                                    className="w-14 h-14 rounded-2xl border-2 border-stone-100 flex items-center justify-center hover:border-brand-black hover:bg-stone-50 transition-all text-stone-400 hover:text-brand-black"
                                  >
                                      <Plus size={24} />
                                  </motion.button>
                              </div>
                              <p className="text-[10px] font-bold text-stone-400 mt-4 uppercase tracking-widest">
                                  New Total: <span className="text-brand-black">{Math.max(0, (adjustingProduct.stock || 0) + adjustmentAmount)}</span>
                              </p>
                          </div>

                          {/* Custom Animated Reason Dropdown */}
                          <div className="relative z-30">
                              <label className="block text-[10px] font-black uppercase text-stone-400 mb-2 tracking-[0.2em]">Audit Reason</label>
                              <button 
                                onClick={() => setIsReasonOpen(!isReasonOpen)}
                                className="w-full bg-white border border-stone-200 p-4 rounded-xl flex justify-between items-center text-sm font-bold text-brand-black hover:border-brand-black transition-all shadow-sm group"
                              >
                                  {adjustmentReason}
                                  <motion.div animate={{ rotate: isReasonOpen ? 180 : 0 }}>
                                      <ChevronDown size={16} className="text-stone-400 group-hover:text-brand-black" />
                                  </motion.div>
                              </button>
                              <AnimatePresence>
                                  {isReasonOpen && (
                                      <motion.ul 
                                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                        animate={{ opacity: 1, y: 0, scale: 1 }}
                                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                        className="absolute bottom-full left-0 right-0 mb-2 bg-white border border-stone-200 rounded-2xl shadow-xl overflow-hidden py-2 z-50 max-h-48 overflow-y-auto custom-scrollbar"
                                      >
                                          {reasons.map(reason => (
                                              <motion.li 
                                                key={reason}
                                                whileHover={{ backgroundColor: '#F5F5F4' }}
                                                onClick={() => { setAdjustmentReason(reason); setIsReasonOpen(false); }}
                                                className="px-6 py-3 cursor-pointer flex justify-between items-center group"
                                              >
                                                  <span className={`text-[10px] font-bold uppercase tracking-widest ${adjustmentReason === reason ? 'text-brand-black' : 'text-stone-500 group-hover:text-brand-black'}`}>{reason}</span>
                                                  {adjustmentReason === reason && <Check size={14} className="text-brand-black" />}
                                              </motion.li>
                                          ))}
                                      </motion.ul>
                                  )}
                              </AnimatePresence>
                          </div>

                          <button 
                            onClick={handleSaveAdjustment} 
                            disabled={adjustmentAmount === 0}
                            className="w-full bg-brand-black text-white py-5 rounded-2xl font-black uppercase tracking-[0.4em] text-[10px] hover:bg-brand-crimson transition-all shadow-xl active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                          >
                              <Save size={16} /> Confirm Update
                          </button>
                      </div>
                  </motion.div>
              </div>
          )}
      </AnimatePresence>
    </div>
  );
};
