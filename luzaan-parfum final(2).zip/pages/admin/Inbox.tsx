
import React, { useState } from 'react';
import { Search, Mail, CheckCircle, Clock, Trash2, Reply, MoreVertical, X, Send } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { ContactMessage } from '../../types';
import { AnimatePresence, motion } from 'framer-motion';

export const Inbox: React.FC = () => {
  const { adminMessages, markMessageAsRead } = useShop();
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'unread' | 'read'>('all');
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);
  
  // Reply State
  const [isReplyOpen, setIsReplyOpen] = useState(false);
  const [replyText, setReplyText] = useState('');

  const filteredMessages = adminMessages.filter(msg => {
      const matchesSearch = msg.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            msg.email.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            msg.subject.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = filter === 'all' ? true : msg.status === filter;
      return matchesSearch && matchesFilter;
  });

  const handleSelectMessage = (msg: ContactMessage) => {
      setSelectedMessage(msg);
      if (msg.status === 'unread') {
          markMessageAsRead(msg.id);
      }
  };

  const handleSendReply = () => {
      if (!replyText.trim()) return;
      alert(`Reply sent to ${selectedMessage?.email}`);
      setReplyText('');
      setIsReplyOpen(false);
  };

  return (
    <div className="animate-fade-in h-[calc(100vh-140px)] flex flex-col lg:flex-row gap-6 relative">
        
        {/* Message List Sidebar */}
        <div className="w-full lg:w-1/3 bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden flex flex-col">
            <div className="p-4 border-b border-stone-100 space-y-3 bg-stone-50/50">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={14} />
                    <input 
                        type="text" 
                        placeholder="Search inbox..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-9 pr-4 py-2 bg-white border border-stone-200 rounded-lg text-xs outline-none focus:border-brand-black text-brand-black transition-colors"
                    />
                </div>
                <div className="flex gap-2">
                    {['all', 'unread', 'read'].map(f => (
                        <button 
                            key={f} 
                            onClick={() => setFilter(f as any)}
                            className={`flex-1 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-md transition-colors ${filter === f ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}
                        >
                            {f}
                        </button>
                    ))}
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto divide-y divide-stone-100">
                {filteredMessages.length === 0 ? (
                    <div className="p-8 text-center text-stone-400">
                        <Mail size={32} className="mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No messages found.</p>
                    </div>
                ) : (
                    filteredMessages.map(msg => (
                        <div 
                            key={msg.id} 
                            onClick={() => handleSelectMessage(msg)}
                            className={`p-4 cursor-pointer hover:bg-stone-50 transition-colors border-l-4 ${selectedMessage?.id === msg.id ? 'bg-stone-50 border-brand-black' : (msg.status === 'unread' ? 'border-brand-crimson bg-white' : 'border-transparent bg-white')}`}
                        >
                            <div className="flex justify-between items-start mb-1">
                                <h4 className={`text-sm truncate pr-2 text-brand-black ${msg.status === 'unread' ? 'font-bold' : 'font-medium'}`}>{msg.name}</h4>
                                <span className="text-[10px] text-stone-400 whitespace-nowrap">{msg.date.split(',')[0]}</span>
                            </div>
                            <p className="text-xs text-stone-600 truncate font-medium mb-1">{msg.subject}</p>
                            <p className="text-xs text-stone-400 truncate">{msg.message}</p>
                        </div>
                    ))
                )}
            </div>
        </div>

        {/* Message Content View */}
        <div className="w-full lg:w-2/3 bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden flex flex-col">
            {selectedMessage ? (
                <>
                    {/* Header */}
                    <div className="p-6 border-b border-stone-100 flex justify-between items-start bg-stone-50/30">
                        <div>
                            <h2 className="text-xl font-bold text-brand-black mb-2">{selectedMessage.subject}</h2>
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center font-serif text-lg font-bold">
                                    {selectedMessage.name.charAt(0)}
                                </div>
                                <div>
                                    <p className="text-sm font-bold text-brand-black">{selectedMessage.name} <span className="text-stone-400 font-normal">&lt;{selectedMessage.email}&gt;</span></p>
                                    <p className="text-xs text-stone-500">{selectedMessage.date}</p>
                                </div>
                            </div>
                        </div>
                        <div className="flex gap-2">
                             <button onClick={() => setIsReplyOpen(true)} className="p-2 text-stone-400 hover:text-brand-black hover:bg-stone-100 rounded transition-colors" title="Reply">
                                 <Reply size={18} />
                             </button>
                             <button className="p-2 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors" title="Delete">
                                 <Trash2 size={18} />
                             </button>
                             <button className="p-2 text-stone-400 hover:text-brand-black hover:bg-stone-100 rounded transition-colors">
                                 <MoreVertical size={18} />
                             </button>
                        </div>
                    </div>
                    
                    {/* Body */}
                    <div className="flex-1 p-8 overflow-y-auto">
                        <div className="prose prose-sm prose-stone max-w-none">
                            <p className="whitespace-pre-wrap leading-relaxed text-brand-black">{selectedMessage.message}</p>
                        </div>
                    </div>
                    
                    {/* Footer / Reply Area */}
                    <div className="p-6 border-t border-stone-100 bg-stone-50">
                        <button onClick={() => setIsReplyOpen(true)} className="flex items-center gap-2 px-6 py-3 bg-white border border-stone-300 rounded-lg text-sm font-bold text-stone-600 hover:bg-brand-black hover:text-white hover:border-brand-black transition-all shadow-sm">
                            <Reply size={16} /> Reply to {selectedMessage.name.split(' ')[0]}
                        </button>
                    </div>
                </>
            ) : (
                <div className="h-full flex flex-col items-center justify-center text-stone-300 p-8">
                    <Mail size={64} className="mb-4 opacity-50" />
                    <p className="text-lg font-serif">Select a message to view details</p>
                </div>
            )}
        </div>

        {/* Reply Modal */}
        <AnimatePresence>
            {isReplyOpen && selectedMessage && (
                <div className="fixed inset-0 z-[2000] flex items-center justify-center bg-brand-black/50 backdrop-blur-sm p-6">
                    <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden"
                    >
                        <div className="p-4 border-b border-stone-100 flex justify-between items-center bg-stone-50">
                            <h3 className="font-bold text-brand-black">Reply to {selectedMessage.name}</h3>
                            <button onClick={() => setIsReplyOpen(false)} className="text-stone-400 hover:text-brand-black"><X size={20} /></button>
                        </div>
                        <div className="p-6 space-y-4">
                            <div className="bg-stone-50 p-3 rounded-lg text-xs text-stone-500 border border-stone-200">
                                <strong>Re:</strong> {selectedMessage.subject}
                            </div>
                            <textarea 
                                autoFocus
                                rows={6}
                                value={replyText}
                                onChange={(e) => setReplyText(e.target.value)}
                                className="w-full border border-stone-200 rounded-xl p-4 text-sm outline-none focus:border-brand-black resize-none"
                                placeholder="Type your response here..."
                            />
                            <div className="flex justify-end gap-3">
                                <button onClick={() => setIsReplyOpen(false)} className="px-4 py-2 text-stone-500 hover:bg-stone-50 rounded-lg text-sm font-bold">Cancel</button>
                                <button onClick={handleSendReply} className="px-6 py-2 bg-brand-black text-white rounded-lg text-sm font-bold hover:bg-stone-800 flex items-center gap-2">
                                    <Send size={14} /> Send Reply
                                </button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>

    </div>
  );
};
