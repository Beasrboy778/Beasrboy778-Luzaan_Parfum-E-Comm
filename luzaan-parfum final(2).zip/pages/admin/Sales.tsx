
import React, { useMemo, useState } from 'react';
import { 
  DollarSign, TrendingUp, CreditCard, Search, ShoppingBag, Calendar
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { useCurrency } from '../../context/CurrencyContext';
import { motion } from 'framer-motion';

type ViewMode = 'Today' | 'Month' | 'Year';

export const Sales: React.FC = () => {
  const { adminOrders } = useShop();
  const { formatPrice } = useCurrency();
  const [viewMode, setViewMode] = useState<ViewMode>('Month');
  const [ledgerSearch, setLedgerSearch] = useState('');
  const [customDate, setCustomDate] = useState('');

  // Precise Aggregation Logic
  const chartData = useMemo(() => {
    const data: Record<string, number> = {};
    let labels: string[] = [];
    const referenceDate = customDate ? new Date(customDate) : new Date();

    if (viewMode === 'Today') {
      // 00:00 to 23:00
      for (let i = 0; i < 24; i++) {
        const label = `${i.toString().padStart(2, '0')}:00`;
        data[label] = 0;
        labels.push(label);
      }
      
      adminOrders.forEach(order => {
        const d = new Date(order.date); // Assumes order.date is parsable string
        // Check if date matches reference date (ignoring time)
        if (d.toDateString() === referenceDate.toDateString()) {
           const label = `${d.getHours().toString().padStart(2, '0')}:00`;
           if (data[label] !== undefined) data[label] += order.total;
        }
      });

    } else if (viewMode === 'Month') {
      // Days in current month
      const year = referenceDate.getFullYear();
      const month = referenceDate.getMonth();
      const daysInMonth = new Date(year, month + 1, 0).getDate();

      for (let i = 1; i <= daysInMonth; i++) {
          const label = i.toString();
          data[label] = 0;
          labels.push(label);
      }

      adminOrders.forEach(order => {
          const d = new Date(order.date);
          if (d.getMonth() === month && d.getFullYear() === year) {
              const label = d.getDate().toString();
              if (data[label] !== undefined) data[label] += order.total;
          }
      });

    } else {
      // Year View (Jan - Dec)
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      labels = months;
      months.forEach(m => data[m] = 0);

      const targetYear = referenceDate.getFullYear();

      adminOrders.forEach(order => {
          const d = new Date(order.date);
          if (d.getFullYear() === targetYear) {
              const label = months[d.getMonth()];
              if (data[label] !== undefined) data[label] += order.total;
          }
      });
    }

    return labels.map(label => ({ label, value: data[label] }));
  }, [adminOrders, viewMode, customDate]);

  const maxVal = Math.max(...chartData.map(d => d.value), 100);
  const totalMoney = chartData.reduce((acc, d) => acc + d.value, 0);

  const filteredOrders = adminOrders.filter(o => 
      o.id.toLowerCase().includes(ledgerSearch.toLowerCase()) || 
      o.customer.name.toLowerCase().includes(ledgerSearch.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full overflow-hidden text-brand-black pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6 shrink-0">
          <div>
            <h1 className="text-3xl font-serif font-bold">Sales Room</h1>
            <p className="text-stone-500 text-sm">See how your shop is growing.</p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
             <div className="relative">
                 <input 
                    type="date" 
                    value={customDate}
                    onChange={(e) => setCustomDate(e.target.value)}
                    className="bg-white border border-stone-200 rounded-xl px-4 py-2 text-xs font-bold uppercase tracking-widest text-brand-black outline-none focus:border-brand-black"
                 />
             </div>
             <div className="bg-white border border-stone-200 rounded-xl p-1 flex shadow-sm">
                {(['Today', 'Month', 'Year'] as ViewMode[]).map((mode) => (
                <button 
                  key={mode} 
                  onClick={() => { setViewMode(mode); setCustomDate(''); }} 
                  className={`px-6 py-2 text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all ${viewMode === mode ? 'bg-brand-black text-white shadow-md' : 'text-stone-400 hover:text-brand-black hover:bg-stone-50'}`}
                >
                  {mode}
                </button>
                ))}
            </div>
          </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-8 overflow-hidden">
        
        {/* Money Graph */}
        <div className="lg:w-[55%] flex flex-col h-full">
            <div className="bg-white p-8 rounded-[2.5rem] border border-stone-200 shadow-sm relative overflow-hidden flex flex-col h-full">
                <div className="flex justify-between items-center mb-10">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-stone-400 flex items-center gap-2">
                    <TrendingUp size={14} className="text-red-900" /> 
                    {customDate ? `Specific Date Analysis` : `${viewMode} Performance`}
                  </h3>
                  <span className="text-[9px] font-bold text-stone-300 uppercase">
                      {customDate || new Date().toDateString()}
                  </span>
                </div>
                
                <div className="flex-1 flex items-end justify-between gap-1 mb-6 min-h-[300px] overflow-x-auto custom-scrollbar pb-4">
                    {chartData.map((d, i) => {
                        const barHeight = (d.value / maxVal) * 100;
                        const isSignificant = viewMode === 'Month' ? (i % 2 === 0) : (viewMode === 'Today' ? (i % 3 === 0) : true);
                        
                        return (
                          <div key={i} className="flex-1 group/bar relative h-full flex flex-col justify-end min-w-[20px]">
                              <motion.div 
                                initial={{ height: 0 }} 
                                animate={{ height: `${Math.max(barHeight, 2)}%` }} 
                                transition={{ duration: 0.5, delay: i * 0.02 }}
                                className={`w-full ${d.value > 0 ? 'bg-brand-black' : 'bg-stone-100'} rounded-t-sm group-hover/bar:bg-brand-crimson transition-colors cursor-pointer`}
                              />
                              
                              <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-brand-black text-white text-[8px] font-bold px-2 py-1 rounded opacity-0 group-hover/bar:opacity-100 transition-opacity whitespace-nowrap z-10 shadow-lg pointer-events-none">
                                {formatPrice(d.value)}
                              </div>
                              
                              <div className={`text-[8px] text-stone-400 mt-2 text-center ${isSignificant ? 'opacity-100' : 'opacity-0 group-hover/bar:opacity-100'}`}>
                                {d.label}
                              </div>
                          </div>
                        );
                    })}
                </div>

                <div className="grid grid-cols-2 gap-8 border-t border-stone-100 pt-8 mt-auto">
                    <div>
                        <p className="text-[10px] font-bold uppercase text-stone-400 mb-1">Period Revenue</p>
                        <h3 className="text-3xl font-serif font-bold text-brand-black">{formatPrice(totalMoney)}</h3>
                    </div>
                    <div className="text-right">
                        <p className="text-[10px] font-bold uppercase text-stone-400 mb-1">All Time Sales</p>
                        <h3 className="text-3xl font-serif font-bold text-brand-black">
                            {formatPrice(adminOrders.reduce((a,b) => a + b.total, 0))}
                        </h3>
                    </div>
                </div>
            </div>
        </div>

        {/* Recent Sales List */}
        <div className="lg:flex-1 flex flex-col h-full overflow-hidden">
            <div className="bg-white rounded-[2.5rem] border border-stone-200 shadow-sm flex flex-col h-full overflow-hidden">
                <div className="p-8 border-b border-stone-100 bg-stone-50/20 shrink-0">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-bold text-lg flex items-center gap-2"><ShoppingBag size={20} className="text-red-900" /> Recent Sales</h3>
                        <span className="text-[10px] font-bold uppercase text-stone-400">{filteredOrders.length} Records</span>
                    </div>
                    <div className="relative">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={16} />
                        <input 
                            type="text" placeholder="Find a sale by name or ID..." 
                            value={ledgerSearch} onChange={e => setLedgerSearch(e.target.value)}
                            className="w-full pl-12 pr-4 py-4 bg-white border border-stone-200 rounded-2xl text-sm outline-none focus:border-brand-black transition-all shadow-inner"
                        />
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-stone-50 text-[9px] font-bold uppercase text-stone-400 border-b border-stone-100 sticky top-0 z-10">
                            <tr>
                                <th className="px-8 py-4">Order ID</th>
                                <th className="px-8 py-4">Customer</th>
                                <th className="px-8 py-4 text-right">Amount</th>
                                <th className="px-8 py-4 text-right">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-stone-50">
                            {filteredOrders.length > 0 ? filteredOrders.map(o => (
                                <tr key={o.id} className="hover:bg-stone-50 transition-colors group">
                                    <td className="px-8 py-5 font-mono text-[10px] font-bold text-stone-500">{o.id}</td>
                                    <td className="px-8 py-5">
                                      <p className="font-bold text-sm text-brand-black">{o.customer.name}</p>
                                      <p className="text-[10px] text-stone-400">{o.date}</p>
                                    </td>
                                    <td className="px-8 py-5 text-right font-serif font-bold text-lg">{formatPrice(o.total)}</td>
                                    <td className="px-8 py-5 text-right">
                                        <span className={`inline-flex px-3 py-1 rounded-full text-[8px] font-bold uppercase ${o.status === 'Delivered' ? 'bg-green-100 text-green-700' : 'bg-red-50 text-red-900'}`}>
                                            {o.status}
                                        </span>
                                    </td>
                                </tr>
                            )) : (
                              <tr>
                                <td colSpan={4} className="p-20 text-center text-stone-300 italic font-serif text-xl">No sales found matching your search.</td>
                              </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};
