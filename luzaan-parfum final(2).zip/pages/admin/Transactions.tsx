import React from 'react';
import { ArrowUpRight, ArrowDownLeft, Download } from 'lucide-react';

export const Transactions: React.FC = () => {
  const transactions = [
    { id: 'TXN-001', type: 'Payment', amount: 185.00, status: 'Success', date: 'Oct 24, 10:30 AM' },
  ];

  const handleExportCSV = () => {
    // CSV export logic...
  };

  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold text-brand-black mb-8">Transactions</h1>
      <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
        <table className="w-full text-left text-sm text-stone-600">
          <thead className="bg-stone-50 text-stone-500 uppercase text-xs font-bold">
            <tr><th className="px-6 py-4">Transaction ID</th><th className="px-6 py-4">Type</th><th className="px-6 py-4">Amount</th><th className="px-6 py-4">Status</th></tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {transactions.map(txn => (
              <tr key={txn.id} className="hover:bg-stone-50">
                <td className="px-6 py-4 font-mono text-xs">{txn.id}</td>
                <td className="px-6 py-4 font-medium text-brand-black">{txn.type}</td>
                <td className="px-6 py-4 font-bold text-brand-black">${txn.amount.toFixed(2)}</td>
                <td className="px-6 py-4"><span className="px-2 py-1 rounded-full text-[10px] font-bold bg-green-100 text-green-700">{txn.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
