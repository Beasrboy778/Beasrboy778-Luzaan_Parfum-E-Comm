
import React, { useState, useRef } from 'react';
import { Database, Download, Save, Loader2, RotateCcw, Clock, Upload, CheckCircle2, AlertTriangle, FileText } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const Backup: React.FC = () => {
  const { 
      products, adminOrders, adminCustomers, storeSettings, 
      designSettings, siteContent, seoSettings, shippingSettings, 
      blogPosts, coupons, reviews, categories, adminMessages, securitySettings,
      restoreSystem 
  } = useShop();

  const [isLoading, setIsLoading] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCreateBackup = () => {
    setIsLoading(true);
    
    // Gather all state data
    const backupData = {
        meta: {
            version: "1.0",
            date: new Date().toISOString(),
            generator: "Aura Admin System"
        },
        products,
        orders: adminOrders,
        customers: adminCustomers,
        settings: storeSettings,
        design: designSettings,
        content: siteContent,
        seo: seoSettings,
        shipping: shippingSettings,
        blogPosts,
        coupons,
        reviews,
        categories,
        messages: adminMessages,
        security: securitySettings
    };

    setTimeout(() => {
        // Create downloadable blob
        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `aura_full_backup_${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        setIsLoading(false);
        setSuccessMsg('Backup generated successfully.');
        setTimeout(() => setSuccessMsg(''), 3000);
    }, 1500);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      if (window.confirm("CRITICAL WARNING: Restoring this file will OVERWRITE all current store data (products, orders, settings). This cannot be undone. Are you sure you want to proceed?")) {
          setIsRestoring(true);
          const reader = new FileReader();
          
          reader.onload = async (event) => {
              try {
                  const json = JSON.parse(event.target?.result as string);
                  if (json.meta && json.products) {
                      await restoreSystem(json);
                      alert('System restored successfully from backup.');
                  } else {
                      throw new Error("Invalid backup file format.");
                  }
              } catch (err) {
                  alert("Failed to restore: Invalid or corrupted backup file.");
                  console.error(err);
              } finally {
                  setIsRestoring(false);
                  if (fileInputRef.current) fileInputRef.current.value = '';
              }
          };
          
          reader.readAsText(file);
      } else {
          if (fileInputRef.current) fileInputRef.current.value = '';
      }
  };

  return (
    <div className="animate-fade-in text-brand-black pb-20">
      <div className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-3xl font-serif font-bold text-brand-black">System Archives</h1>
            <p className="text-stone-500 text-sm mt-1">Generate full database snapshots or restore previous states.</p>
          </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* BACKUP CARD */}
        <div className="bg-white p-10 rounded-[3rem] border border-stone-200 shadow-sm flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none">
                <Database size={200} />
            </div>
            
            <div>
                <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mb-6 shadow-sm border border-blue-100">
                    <Save size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2">Create Full Backup</h3>
                <p className="text-stone-500 text-sm leading-relaxed mb-8">
                    Generates a complete JSON snapshot of your entire store configuration, including products, orders, customers, and design settings.
                </p>
                <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 mb-8">
                    <p className="text-[10px] font-black uppercase text-stone-400 tracking-widest mb-2 flex items-center gap-2"><FileText size={12} /> Includes</p>
                    <div className="flex flex-wrap gap-2">
                        {['Products', 'Orders', 'Customers', 'Design', 'Settings', 'Blog'].map(tag => (
                            <span key={tag} className="text-[9px] bg-white px-2 py-1 rounded border border-stone-200 text-stone-600 font-bold">{tag}</span>
                        ))}
                    </div>
                </div>
            </div>

            <button 
                onClick={handleCreateBackup} 
                disabled={isLoading || isRestoring} 
                className="w-full py-5 bg-brand-black text-white font-black uppercase tracking-[0.4em] text-[10px] rounded-2xl hover:bg-brand-crimson transition-all shadow-xl flex items-center justify-center gap-3 active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed"
            >
                {isLoading ? <Loader2 className="animate-spin" /> : <Download size={18} />}
                {isLoading ? 'Archiving System...' : 'Download Snapshot'}
            </button>
            
            {successMsg && (
                <div className="absolute top-6 right-6 bg-green-50 text-green-700 px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 border border-green-100 animate-slide-up">
                    <CheckCircle2 size={14} /> {successMsg}
                </div>
            )}
        </div>

        {/* RESTORE CARD */}
        <div className="bg-white p-10 rounded-[3rem] border border-stone-200 shadow-sm flex flex-col justify-between relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none group-hover:opacity-[0.06] transition-opacity">
                <RotateCcw size={200} />
            </div>

            <div>
                <div className="w-16 h-16 bg-red-50 text-red-600 rounded-3xl flex items-center justify-center mb-6 shadow-sm border border-red-100">
                    <Upload size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2 text-brand-black">System Restore</h3>
                <p className="text-stone-500 text-sm leading-relaxed mb-8">
                    Revert your store to a previous state using a valid backup file. 
                </p>
                
                <div className="bg-red-50 p-6 rounded-2xl border border-red-100 mb-8">
                    <div className="flex items-start gap-3">
                        <AlertTriangle size={20} className="text-red-500 shrink-0 mt-0.5" />
                        <div>
                            <h4 className="text-xs font-bold text-red-700 uppercase tracking-wide mb-1">Critical Warning</h4>
                            <p className="text-[10px] text-red-600/80 leading-relaxed">
                                This action is destructive. All current data will be permanently replaced by the backup data. Ensure you have exported a current backup before proceeding.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="relative">
                <input 
                    type="file" 
                    accept=".json"
                    ref={fileInputRef}
                    onChange={handleRestoreFile}
                    disabled={isRestoring}
                    className="absolute inset-0 opacity-0 cursor-pointer z-20 w-full h-full disabled:cursor-not-allowed"
                />
                <button 
                    disabled={isRestoring}
                    className="w-full py-5 bg-white border-2 border-dashed border-stone-300 text-stone-400 font-black uppercase tracking-[0.4em] text-[10px] rounded-2xl hover:border-red-500 hover:text-red-500 hover:bg-red-50 transition-all flex items-center justify-center gap-3 relative z-10"
                >
                    {isRestoring ? <Loader2 className="animate-spin text-red-500" /> : <RotateCcw size={18} />}
                    {isRestoring ? 'Restoring Database...' : 'Select File to Restore'}
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
