
import React, { useState, useEffect, useRef } from 'react';
import { Plus, Trash2, X, Save, Tag, AlertCircle, ImageIcon, AlignLeft, Upload, Loader2, Image as LucideImage, Edit2 } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Category } from '../../types';

// Compression Utility
const compressImage = (file: File, maxWidth = 800): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height *= maxWidth / width;
                    width = maxWidth;
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
                resolve(dataUrl);
            };
            img.onerror = (error) => reject(error);
        };
        reader.onerror = (error) => reject(error);
    });
};

const getImageSize = (dataUrl: string) => {
    if(!dataUrl) return '0 KB';
    const sizeInBytes = dataUrl.length * 0.75; 
    const sizeInKb = sizeInBytes / 1024;
    return sizeInKb.toFixed(1) + ' KB';
};

export const Categories: React.FC = () => {
  const { categories, addCategory, updateCategory, deleteCategory, products } = useShop();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [formData, setFormData] = useState({ id: '', name: '', slug: '', image: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // State to hold dimensions for the active editing image
  const [imgDims, setImgDims] = useState<string | null>(null);

  useEffect(() => {
    if (isModalOpen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [isModalOpen]);

  const validate = () => {
      let newErrors: Record<string, string> = {};
      if (!formData.name.trim()) newErrors.name = 'Name is required.';
      if (!formData.slug.trim()) newErrors.slug = 'Slug ID is required.';
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  };

  const handleOpenAdd = () => {
      setIsEditMode(false);
      setFormData({ id: '', name: '', slug: '', image: '' });
      setImgDims(null);
      setIsModalOpen(true);
  };

  const handleOpenEdit = (cat: Category) => {
      setIsEditMode(true);
      setFormData({
          id: cat.id,
          name: cat.name,
          slug: cat.slug,
          image: cat.image || ''
      });
      setImgDims(null); // Reset until load
      setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if(validate()) {
        const categoryData = {
            id: isEditMode ? formData.id : formData.slug.toLowerCase(),
            name: formData.name,
            slug: formData.slug.toLowerCase(),
            image: formData.image,
            productCount: isEditMode ? (categories.find(c => c.id === formData.id)?.productCount || 0) : 0
        };

        if (isEditMode) {
            updateCategory(categoryData);
        } else {
            addCategory(categoryData);
        }

        setIsModalOpen(false);
        setFormData({ id: '', name: '', slug: '', image: '' });
        setErrors({});
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          setIsProcessing(true);
          try {
              const compressed = await compressImage(file);
              setFormData(prev => ({ ...prev, image: compressed }));
          } catch (err) {
              console.error("Upload failed", err);
          } finally {
              setIsProcessing(false);
          }
      }
  };

  const getProductCount = (catId: string) => {
      if (catId === 'all') return products.length;
      return products.filter(p => p.category.toLowerCase() === catId.toLowerCase()).length;
  };

  const glassInputClass = "w-full bg-white border border-stone-200 p-4 rounded-xl text-sm text-brand-black outline-none focus:border-brand-black transition-all shadow-sm placeholder-stone-400";

  return (
    <div className="animate-fade-in relative pb-20">
      <div className="flex justify-between items-center mb-10">
        <div>
            <h1 className="text-3xl font-serif font-bold text-brand-black">Collection Archetypes</h1>
            <p className="text-stone-500 text-sm mt-1">Manage the visual categories displayed on the landing page.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {/* ADD BUTTON IS NOW FIRST */}
        <motion.button layout onClick={handleOpenAdd} className="border-2 border-dashed border-stone-300 rounded-[2.5rem] flex flex-col items-center justify-center p-8 text-stone-400 hover:text-brand-black hover:border-brand-black hover:bg-white transition-all min-h-[400px] group shadow-inner order-first">
          <div className="w-16 h-16 rounded-full bg-stone-50 flex items-center justify-center mb-4 group-hover:bg-brand-black group-hover:text-white transition-all shadow-inner"><Plus size={32} strokeWidth={1} /></div>
          <span className="font-black uppercase tracking-[0.4em] text-[10px]">Create Entry</span>
        </motion.button>

        {categories.map(cat => (
          <motion.div layout key={cat.id} className="bg-white rounded-[2.5rem] border border-stone-200 shadow-sm group hover:border-brand-black/20 hover:shadow-xl transition-all relative overflow-hidden flex flex-col">
             <div className="aspect-[4/5] relative bg-stone-100 overflow-hidden">
                 {cat.image ? (
                     <img src={cat.image} alt={cat.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                 ) : (
                     <div className="w-full h-full flex items-center justify-center text-stone-300"><LucideImage size={48} /></div>
                 )}
                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60" />
                 <div className="absolute top-4 right-4 flex gap-2">
                    <button onClick={() => handleOpenEdit(cat)} className="w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center text-brand-black hover:bg-brand-black hover:text-white transition-all shadow-lg"><Edit2 size={14} /></button>
                    {cat.id !== 'all' && (
                        <button onClick={() => { if(window.confirm('Delete this category?')) deleteCategory(cat.id) }} className="w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center text-red-500 hover:bg-red-500 hover:text-white transition-all shadow-lg"><Trash2 size={14} /></button>
                    )}
                 </div>
                 <div className="absolute bottom-6 left-6 text-white">
                     <h3 className="text-2xl font-serif italic font-bold leading-none mb-2">{cat.name}</h3>
                     <p className="text-[9px] font-black uppercase tracking-[0.3em] opacity-80">{getProductCount(cat.id)} Scents</p>
                 </div>
             </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
      {isModalOpen && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[2000] flex items-start justify-center bg-white/60 backdrop-blur-md pt-24 md:pt-28 pb-4 px-4 overflow-hidden" onClick={() => setIsModalOpen(false)}>
            <motion.div initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }} className="bg-white w-full max-w-lg rounded-[2.5rem] shadow-[0_60px_100px_rgba(0,0,0,0.3)] overflow-hidden border border-stone-100 max-h-[85vh] flex flex-col relative shrink-0" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-6 border-b border-stone-100 bg-[#FCFBFA]/90 backdrop-blur sticky top-0 z-10 shrink-0">
                    <div><h2 className="text-2xl font-serif font-bold italic text-brand-black">{isEditMode ? 'Edit Collection' : 'New Collection'}</h2><p className="text-[9px] font-black uppercase text-stone-400 tracking-[0.2em] mt-1">Landing Page Architecture</p></div>
                    <button onClick={() => setIsModalOpen(false)} className="text-stone-400 hover:text-brand-black transition-colors p-2"><X size={24} /></button>
                </div>
                
                <form onSubmit={handleSave} className="p-8 space-y-8 overflow-y-auto custom-scrollbar flex-1 bg-white">
                    <div>
                        <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-3 flex items-center gap-2"><Tag size={12} /> Formal Name</label>
                        <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value, slug: !isEditMode ? e.target.value.toLowerCase().replace(/\s+/g, '-') : formData.slug})} className={glassInputClass} placeholder="e.g. Imperial Rose" />
                        {errors.name && <p className="text-red-500 text-[10px] mt-2 flex items-center gap-1"><AlertCircle size={10} /> {errors.name}</p>}
                    </div>
                    <div>
                        <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-3 flex items-center gap-2"><AlignLeft size={12} /> Slug Protocol</label>
                        <input type="text" value={formData.slug} onChange={(e) => setFormData({...formData, slug: e.target.value})} className={`${glassInputClass} font-mono text-xs ${formData.id === 'all' ? 'cursor-not-allowed bg-stone-50' : ''}`} placeholder="e.g. imperial-rose" disabled={isEditMode} />
                        {errors.slug && <p className="text-red-500 text-[10px] mt-2 flex items-center gap-1"><AlertCircle size={10} /> {errors.slug}</p>}
                    </div>
                    <div>
                        <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-3 flex items-center gap-2"><ImageIcon size={12} /> Visual Asset (Home Page)</label>
                        <div onClick={() => fileInputRef.current?.click()} className="aspect-[4/3] bg-stone-50 border-2 border-dashed border-stone-200 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-brand-black hover:bg-stone-100 transition-all group relative overflow-hidden">
                            {isProcessing ? (
                                <div className="flex flex-col items-center gap-2"><Loader2 className="animate-spin text-brand-black" size={24} /><span className="text-[9px] font-black uppercase tracking-widest text-stone-400">Optimizing...</span></div>
                            ) : formData.image ? (
                                <>
                                    <img 
                                        src={formData.image} 
                                        alt="Preview" 
                                        className="absolute inset-0 w-full h-full object-cover" 
                                        onLoad={(e) => setImgDims(`${e.currentTarget.naturalWidth}x${e.currentTarget.naturalHeight}`)}
                                    />
                                    {imgDims && (
                                        <div className="absolute bottom-2 left-2 right-2 bg-black/60 backdrop-blur text-white text-[8px] font-mono text-center rounded py-1 pointer-events-none">
                                            {imgDims} • {getImageSize(formData.image)}
                                        </div>
                                    )}
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                        <span className="text-white font-bold text-xs uppercase tracking-widest flex items-center gap-2"><Upload size={14} /> Replace</span>
                                    </div>
                                </>
                            ) : (
                                <div className="text-stone-300 group-hover:text-stone-500 transition-colors flex flex-col items-center gap-2">
                                    <Upload size={24} />
                                    <span className="text-[9px] font-black uppercase tracking-widest">Upload Cover</span>
                                    <span className="text-[7px] font-mono text-stone-400 bg-stone-100 px-1.5 py-0.5 rounded">Rec: 800x1000px</span>
                                </div>
                            )}
                            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                        </div>
                    </div>
                </form>
                <div className="p-6 border-t border-stone-100 bg-[#FCFBFA]/90 backdrop-blur shrink-0 sticky bottom-0 z-10">
                    <button onClick={handleSave} type="submit" disabled={isProcessing} className="w-full py-5 bg-brand-black text-white font-black uppercase text-[11px] tracking-[0.4em] rounded-2xl hover:bg-brand-crimson transition-all flex items-center justify-center gap-3 shadow-2xl active:scale-95 disabled:opacity-50">
                        <Save size={18} /> {isEditMode ? 'Update Collection' : 'Register Collection Entry'}
                    </button>
                </div>
            </motion.div>
        </motion.div>
      )}
      </AnimatePresence>
    </div>
  );
};
