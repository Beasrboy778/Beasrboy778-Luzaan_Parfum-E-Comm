
import React, { useState, useEffect } from 'react';
import { Mail, Shield, CreditCard, Download, CheckCircle, XCircle, Search, Edit2, X, Save, Key, Globe, Activity, Fingerprint, Calendar } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { User } from '../../types';
import { motion, AnimatePresence } from 'framer-motion';
import { useCurrency } from '../../context/CurrencyContext';

export const Customers: React.FC = () => {
  const { adminCustomers, updateCustomer } = useShop();
  const { formatPrice } = useCurrency();
  const [searchTerm, setSearchTerm] = useState('');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Lock scroll when modal is open
  useEffect(() => {
    if (isEditModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => { document.body.style.overflow = 'unset'; };
  }, [isEditModalOpen]);

  // Strict Filter: Exclude Admins explicitly by role and specific email
  const filteredCustomers = adminCustomers.filter(c => 
      c.role !== 'admin' && 
      c.email !== 'admin@aura.com' &&
      (c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      c.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleExportCSV = () => {
    const headers = ['Name', 'Email', 'Role', 'Region', 'Join Date', 'Auth', 'Orders', 'Spent'];
    const rows = filteredCustomers.map(u => [ `"${u.name}"`, u.email, u.role || 'user', u.region || 'Global', u.joinDate || '', u.provider || 'Email', u.ordersCount || 0, u.totalSpent || 0 ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `customer_list.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleEditClick = (user: User) => {
      setEditingUser({ ...user });
      setIsEditModalOpen(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
      e.preventDefault();
      if (editingUser) {
          updateCustomer(editingUser);
          setIsEditModalOpen(false);
          setEditingUser(null);
      }
  };

  const glassInputClass = "w-full bg-white/40 backdrop-blur-md border border-stone-200/50 p-4 rounded-xl text-sm text-brand-black outline-none focus:bg-white/70 focus:border-brand-black transition-all shadow-inner placeholder-stone-400";

  return (
    <div className="animate-fade-in relative text-brand-black pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6">
        <div>
          <h1 className="text-3xl font-serif font-bold">Your Customers</h1>
          <p className="text-stone-500 text-sm">Manage the people who shop at Aura.</p>
        </div>
        <div className="flex gap-4">
            <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400 group-focus-within:text-brand-black transition-colors" size={16} />
                <input type="text" placeholder="Search customers..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-12 pr-6 py-3 border border-stone-200 rounded-xl text-sm outline-none focus:border-brand-black bg-white shadow-inner w-72" />
            </div>
            <button onClick={handleExportCSV} className="flex items-center gap-2 px-6 py-3 bg-white border border-stone-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-stone-600 hover:text-brand-black hover:border-brand-black shadow-sm transition-all active:scale-95"><Download size={16} /> Export List</button>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-stone-200 overflow-hidden">
         <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
                <thead className="bg-stone-50 text-stone-400 uppercase text-[10px] font-black tracking-[0.4em] border-b border-stone-100">
                <tr>
                    <th className="px-8 py-6">Customer</th>
                    <th className="px-8 py-6">Login Mode</th>
                    <th className="px-8 py-6">Region</th>
                    <th className="px-8 py-6">Total Spent</th>
                    <th className="px-8 py-6">Join Date</th>
                    <th className="px-8 py-6 text-right">Edit</th>
                </tr>
                </thead>
                <tbody className="divide-y divide-stone-50">
                {filteredCustomers.length > 0 ? (
                    filteredCustomers.map(user => (
                        <tr key={user.id} className="hover:bg-stone-50/50 transition-colors group">
                        <td className="px-8 py-6">
                            <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-brand-black font-serif text-xl font-bold border border-stone-100 shadow-sm relative overflow-hidden">
                                {user.photoURL ? <img src={user.photoURL} alt="" className="w-full h-full object-cover" /> : <span>{user.name.charAt(0)}</span>}
                                <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white bg-green-500" />
                            </div>
                            <div>
                                <p className="font-bold text-brand-black flex items-center gap-2">{user.name}</p>
                                <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">{user.email}</p>
                            </div>
                            </div>
                        </td>
                        <td className="px-8 py-6">
                            <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${user.provider === 'google' ? 'bg-blue-50 text-blue-700 border-blue-100' : 'bg-stone-50 text-stone-500 border-stone-200'}`}><Key size={10} /> {user.provider === 'google' ? 'Google' : 'Email'}</div>
                        </td>
                        <td className="px-8 py-6"><div className="flex items-center gap-2 text-stone-600 font-bold text-xs uppercase tracking-tight"><Globe size={14} className="text-stone-300" />{user.region || 'Global'}</div></td>
                        <td className="px-8 py-6"><div className="flex flex-col"><span className="font-serif font-bold text-lg text-brand-black">{formatPrice(user.totalSpent || 0)}</span><span className="text-[9px] text-stone-400 font-black uppercase tracking-widest">{user.ordersCount || 0} Orders</span></div></td>
                        <td className="px-8 py-6"><div className="flex items-center gap-2 text-stone-500 text-xs font-medium"><Calendar size={14} className="text-stone-300" />{user.joinDate}</div></td>
                        <td className="px-8 py-6 text-right"><button onClick={() => handleEditClick(user)} className="p-3 text-stone-400 hover:text-brand-black hover:bg-white rounded-xl border border-transparent hover:border-stone-100 transition-all shadow-sm"><Fingerprint size={18} /></button></td>
                        </tr>
                    ))
                ) : (
                    <tr>
                        <td colSpan={6} className="px-8 py-12 text-center text-stone-400 italic">No customers found matching your criteria.</td>
                    </tr>
                )}
                </tbody>
            </table>
         </div>
      </div>

      <AnimatePresence>
        {isEditModalOpen && editingUser && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[999] flex items-start justify-center pt-24 md:pt-32 px-6 bg-brand-black/90 backdrop-blur-xl">
                <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }} className="bg-brand-cream w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden border border-white/50 flex flex-col">
                    <div className="flex justify-between items-center p-10 border-b border-stone-200/50 bg-stone-50/30">
                        <div>
                            <h2 className="text-3xl font-serif font-bold italic">Identity Registry</h2>
                            <p className="text-[10px] text-stone-400 font-black uppercase tracking-[0.4em] mt-1">Record ID: {editingUser.id}</p>
                        </div>
                        <button onClick={() => setIsEditModalOpen(false)} className="text-stone-300 hover:text-brand-black transition-colors"><X size={24} /></button>
                    </div>
                    <form onSubmit={handleSaveUser} className="p-10 space-y-8 overflow-y-auto custom-scrollbar">
                        <div className="grid grid-cols-2 gap-8">
                            <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest">Formal Name</label><input type="text" value={editingUser.name} onChange={e => setEditingUser({...editingUser, name: e.target.value})} className={glassInputClass} /></div>
                            <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest">Digital Coordinate</label><input type="email" value={editingUser.email} onChange={e => setEditingUser({...editingUser, email: e.target.value})} className={glassInputClass} /></div>
                        </div>
                        <div className="grid grid-cols-2 gap-8">
                            <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest">Security Clearance</label><select value={editingUser.role || 'user'} onChange={e => setEditingUser({...editingUser, role: e.target.value as any})} className={glassInputClass} disabled><option value="user">Verified Collector</option></select><p className="text-[8px] text-red-400 mt-1 italic">Role modification is restricted for security.</p></div>
                            <div><label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest">Narrative Sync (Newsletter)</label><div onClick={() => setEditingUser({...editingUser, isSubscribed: !editingUser.isSubscribed})} className={`w-full h-[58px] border-2 rounded-xl flex items-center justify-between px-6 cursor-pointer transition-all ${editingUser.isSubscribed ? 'bg-brand-black text-white border-brand-black shadow-lg' : 'bg-white border-stone-100 text-stone-400 hover:border-stone-300'}`}><span className="text-[10px] font-black uppercase tracking-widest">{editingUser.isSubscribed ? 'Subscribed' : 'Opt-Out'}</span>{editingUser.isSubscribed ? <CheckCircle size={18} /> : <XCircle size={18} />}</div></div>
                        </div>
                        <div className="flex justify-end gap-6 pt-6 border-t border-stone-100">
                            <button type="button" onClick={() => setIsEditModalOpen(false)} className="text-[10px] font-black uppercase tracking-widest text-stone-400 hover:text-brand-black transition-colors">Discard Changes</button>
                            <button type="submit" className="px-12 py-5 bg-brand-black text-white rounded-full text-[10px] font-black uppercase tracking-[0.4em] hover:bg-brand-crimson transition-all shadow-xl active:scale-95 flex items-center gap-3"><Save size={18} /> Finalize Record</button>
                        </div>
                    </form>
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
