
import React, { useMemo, useState } from 'react';
import { TrendingUp, ShoppingBag, Calendar, PieChart, Activity, Globe, DollarSign } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { useCurrency } from '../../context/CurrencyContext';
import { motion, AnimatePresence } from 'framer-motion';

export const Analytics: React.FC = () => {
  const { adminOrders, products } = useShop();
  const { formatPrice } = useCurrency();
  const [timeframe, setTimeframe] = useState<'day' | 'month' | 'year'>('month');

  // Sales Trend Data Generation
  const chartData = useMemo(() => {
    const now = new Date();
    const data: Record<string, number> = {};
    let labels: string[] = [];

    if (timeframe === 'day') {
        // Last 7 days
        for (let i = 6; i >= 0; i--) {
            const d = new Date();
            d.setDate(now.getDate() - i);
            const label = d.toLocaleDateString('en-US', { weekday: 'short' });
            data[label] = 0;
            labels.push(label);
        }
        adminOrders.forEach(o => {
            const label = new Date(o.date).toLocaleDateString('en-US', { weekday: 'short' });
            if (data[label] !== undefined) data[label] += o.total;
        });
    } else if (timeframe === 'month') {
        // Last 30 days grouped in 5-day chunks
        for (let i = 5; i >= 0; i--) {
            const label = `Period ${6-i}`;
            data[label] = 0;
            labels.push(label);
        }
        adminOrders.forEach(o => {
            const label = 'Period 1'; // Simulated grouping for brevity in mock
            if (data[label] !== undefined) data[label] += o.total;
        });
    } else {
        // Last 5 Years
        const years = [2021, 2022, 2023, 2024, 2025];
        labels = years.map(String);
        years.forEach(y => data[y] = 0);
        adminOrders.forEach(o => {
            const y = new Date(o.date).getFullYear().toString();
            if (data[y] !== undefined) data[y] += o.total;
        });
    }

    return labels.map(label => ({ label, value: data[label] }));
  }, [adminOrders, timeframe]);

  const maxValue = Math.max(...chartData.map(d => d.value), 500);

  const categoryPerformance = useMemo(() => {
      const cats: Record<string, number> = {};
      adminOrders.forEach(o => o.items.forEach(i => {
          const c = i.category || 'Unisex';
          cats[c] = (cats[c] || 0) + i.quantity;
      }));
      return Object.entries(cats).sort((a,b) => b[1] - a[1]);
  }, [adminOrders]);

  return (
    <div className="animate-fade-in text-brand-black pb-20">
      <div className="flex justify-between items-end mb-12">
        <div>
            <h1 className="text-3xl font-serif font-bold">Revenue Intelligence</h1>
            <p className="text-stone-500 text-sm mt-1">Real-time financial tracking of the Aura archive.</p>
        </div>
        
        <div className="bg-white border border-stone-200 rounded-xl p-1 flex gap-1 shadow-sm">
            {(['day', 'month', 'year'] as const).map(t => (
                <button 
                    key={t}
                    onClick={() => setTimeframe(t)}
                    className={`px-6 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${timeframe === t ? 'bg-brand-black text-white shadow-md' : 'text-stone-400 hover:text-brand-black hover:bg-stone-50'}`}
                >
                    {t === 'day' ? 'Daily' : t === 'month' ? 'Monthly' : 'Yearly'}
                </button>
            ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
         {/* MAIN SALES CHART */}
         <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] shadow-sm border border-stone-200">
             <div className="flex justify-between items-center mb-12">
                <h3 className="font-bold text-lg flex items-center gap-2">
                    <TrendingUp size={20} className="text-brand-crimson" /> 
                    Sales Velocity Trend
                </h3>
                <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">Aura Global Protocol</span>
             </div>
             
             <div className="h-80 w-full flex items-end justify-between gap-4">
                {chartData.map((d, i) => {
                    const h = (d.value / maxValue) * 100;
                    return (
                        <div key={i} className="flex-1 flex flex-col items-center group relative h-full justify-end">
                            <div className="absolute -top-10 opacity-0 group-hover:opacity-100 transition-all bg-brand-black text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-xl z-20 whitespace-nowrap">
                                {formatPrice(d.value)}
                            </div>
                            <motion.div 
                                initial={{ height: 0 }}
                                animate={{ height: `${Math.max(h, 5)}%` }}
                                transition={{ duration: 0.8, delay: i * 0.05, ease: [0.22, 1, 0.36, 1] }}
                                className="w-full max-w-[50px] bg-brand-black/10 group-hover:bg-brand-crimson rounded-t-xl transition-colors duration-500 shadow-inner"
                            />
                            <span className="text-[9px] text-stone-400 mt-4 font-black uppercase tracking-widest text-center truncate w-full">
                                {d.label}
                            </span>
                        </div>
                    );
                })}
             </div>
         </div>

         {/* STATS & BREAKDOWN */}
         <div className="space-y-8">
             <div className="bg-brand-black text-white p-10 rounded-[3rem] shadow-2xl relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-125 transition-transform duration-1000"><DollarSign size={120} /></div>
                 <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-gold mb-4">Total Net Worth</h4>
                 <div className="text-5xl font-serif font-bold italic mb-8">
                     {formatPrice(adminOrders.reduce((a,b) => a + b.total, 0))}
                 </div>
                 <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-brand-gold bg-white/5 px-4 py-2 rounded-full w-fit">
                    <Activity size={12} /> Sync: Operational
                 </div>
             </div>

             <div className="bg-white p-8 rounded-[3rem] border border-stone-200 shadow-sm">
                 <h3 className="font-bold text-brand-black mb-8 flex items-center gap-2"><PieChart size={18} /> Market Share</h3>
                 <div className="space-y-6">
                     {categoryPerformance.slice(0, 3).map(([name, count], i) => (
                         <div key={name}>
                             <div className="flex justify-between text-xs font-bold mb-2">
                                 <span>{name}</span>
                                 <span className="text-stone-400">{count} Sales</span>
                             </div>
                             <div className="w-full bg-stone-50 h-2 rounded-full overflow-hidden">
                                 <motion.div 
                                    initial={{ width: 0 }}
                                    animate={{ width: `${(count/adminOrders.length)*100}%` }}
                                    className={`h-full ${i === 0 ? 'bg-brand-crimson' : i === 1 ? 'bg-brand-gold' : 'bg-brand-black'}`}
                                 />
                             </div>
                         </div>
                     ))}
                 </div>
             </div>
         </div>
      </div>
    </div>
  );
};
