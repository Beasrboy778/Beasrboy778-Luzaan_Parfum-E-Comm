
import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Edit2, Calendar, Tag, X, Save, AlertCircle, Percent, DollarSign, CheckCircle, AlignLeft, Info, Activity, Hash, Layers, ListFilter } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { useCurrency } from '../../context/CurrencyContext';
import { Coupon } from '../../types';
import { motion, AnimatePresence } from 'framer-motion';

export const Coupons: React.FC = () => {
  const { coupons, addCoupon, updateCoupon, deleteCoupon } = useShop();
  const { formatPrice } = useCurrency();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentCoupon, setCurrentCoupon] = useState<any>({
      code: '',
      discountType: 'percent',
      value: 0,
      minOrderValue: 0,
      expiryDate: '',
      status: 'active',
      description: '',
      usageLimit: 0,
      usageCount: 0
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (isModalOpen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = 'unset';
    return () => { document.body.style.overflow = 'unset'; };
  }, [isModalOpen]);

  const handleOpenAdd = () => {
      setIsEditMode(false);
      setCurrentCoupon({
          code: '',
          discountType: 'percent',
          value: 0,
          minOrderValue: 0,
          expiryDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0],
          status: 'active',
          description: '',
          usageLimit: 100,
          usageCount: 0
      });
      setError('');
      setIsModalOpen(true);
  };

  const handleOpenEdit = (coupon: Coupon) => {
      setIsEditMode(true);
      setCurrentCoupon({ ...coupon });
      setError('');
      setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
      e.preventDefault();
      if (!currentCoupon.code) {
          setError('Protocol Code is required');
          return;
      }
      const couponData = { ...currentCoupon, code: currentCoupon.code.toUpperCase() } as Coupon;
      if (isEditMode && currentCoupon.id) {
          updateCoupon(couponData);
      } else {
          addCoupon({ ...couponData, id: Date.now().toString() });
      }
      setIsModalOpen(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      const { name, value } = e.target;
      setCurrentCoupon((prev: any) => ({
          ...prev,
          [name]: name === 'value' || name === 'minOrderValue' || name === 'usageLimit' ? parseFloat(value) : value
      }));
  };

  const inputClass = "w-full bg-white border border-stone-200 p-4 rounded-2xl text-sm text-brand-black outline-none focus:border-brand-black transition-all shadow-sm placeholder-stone-300";

  return (
    <div className="animate-fade-in relative text-brand-black pb-20">
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-3xl font-serif font-bold text-brand-black">Incentive Protocols</h1>
          <p className="text-stone-500 text-sm mt-1">Manage transactional honorariums and promotional codes.</p>
        </div>
        <button onClick={handleOpenAdd} className="flex items-center gap-3 px-10 py-5 bg-brand-black text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-stone-800 transition-all shadow-xl active:scale-95">
          <Plus size={20} /> Deploy Protocol
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {coupons.map(coupon => (
            <div key={coupon.id} className="bg-white rounded-[2.5rem] shadow-sm border border-stone-200 p-8 relative group hover:border-brand-black/30 hover:shadow-2xl transition-all overflow-hidden">
                <div className="flex justify-between items-start mb-6">
                    <div className="bg-brand-crimson text-white p-4 rounded-2xl shadow-xl"><Tag size={24} /></div>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => handleOpenEdit(coupon)} className="p-3 bg-stone-50 rounded-xl hover:bg-brand-black hover:text-white transition-colors shadow-sm"><Edit2 size={16} /></button>
                        <button onClick={() => deleteCoupon(coupon.id)} className="p-3 bg-red-50 text-red-500 rounded-xl hover:bg-red-600 hover:text-white transition-colors shadow-sm"><Trash2 size={16} /></button>
                    </div>
                </div>
                <h3 className="text-2xl font-mono font-bold text-brand-black tracking-[0.2em] uppercase mb-2">{coupon.code}</h3>
                <p className="text-4xl font-serif font-bold text-brand-black italic mb-6">
                    {coupon.discountType === 'percent' ? `${coupon.value}% OFF` : `${formatPrice(coupon.value)} OFF`}
                </p>
                <div className="space-y-3 pt-6 border-t border-stone-50">
                    <div className="flex justify-between text-[9px] font-black uppercase tracking-widest text-stone-400">
                        <span>Expiry Date</span>
                        <span>{coupon.expiryDate}</span>
                    </div>
                    <div className="flex justify-between text-[9px] font-black uppercase tracking-widest text-stone-400">
                        <span>Used Count</span>
                        <span>{coupon.usageCount} / { (coupon as any).usageLimit || '∞' }</span>
                    </div>
                </div>
            </div>
        ))}
        
        <button onClick={handleOpenAdd} className="border-2 border-dashed border-stone-200 rounded-[2.5rem] p-10 flex flex-col items-center justify-center text-stone-400 hover:border-brand-crimson hover:text-brand-crimson transition-all min-h-[200px] group shadow-inner">
           <Plus size={32} strokeWidth={1} className="mb-4 group-hover:scale-110 transition-transform" />
           <span className="font-black uppercase tracking-[0.4em] text-[10px]">Define New Protocol</span>
        </button>
      </div>

      <AnimatePresence>
      {isModalOpen && (
        // Changed overlay to white/60 blur
        <div 
            className="fixed inset-0 z-[2000] flex items-start justify-center pt-24 md:pt-28 pb-6 px-4 bg-white/60 backdrop-blur-md overflow-hidden"
            onClick={() => setIsModalOpen(false)}
        >
          {/* Main Modal Card with max-height and flex-col for internal scrolling */}
          <motion.div 
            initial={{ scale: 0.95, opacity: 0, y: 20 }} 
            animate={{ scale: 1, opacity: 1, y: 0 }} 
            exit={{ scale: 0.95, opacity: 0, y: 20 }} 
            className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-[0_60px_100px_rgba(0,0,0,0.3)] overflow-hidden border border-stone-100 flex flex-col max-h-[85vh] relative shrink-0" 
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex justify-between items-center p-6 border-b border-stone-100 bg-[#FCFBFA]/90 backdrop-blur shrink-0 sticky top-0 z-10">
              <div>
                <h2 className="text-2xl font-serif font-bold italic text-brand-black">{isEditMode ? 'Protocol Modification' : 'Deploy Protocol'}</h2>
                <p className="text-[9px] font-black uppercase text-stone-400 tracking-[0.2em] mt-1">Incentive Layer Configuration</p>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)} 
                className="w-10 h-10 rounded-full bg-white border border-stone-100 flex items-center justify-center text-stone-400 hover:text-brand-black transition-all hover:rotate-90 duration-300 shadow-md active:scale-90"
              >
                <X size={20} />
              </button>
            </div>
            
            {/* Modal Content - Scrollable Area */}
            <form onSubmit={handleSave} className="p-8 space-y-8 overflow-y-auto min-h-0 custom-scrollbar flex-1 bg-white">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="md:col-span-2">
                      <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-[0.4em] flex items-center gap-2"><Tag size={12} /> Protocol Identifier (Code)</label>
                      <input 
                        type="text" 
                        name="code" 
                        value={currentCoupon.code} 
                        onChange={(e) => handleChange({ ...e, target: { ...e.target, value: e.target.value.toUpperCase() } })} 
                        placeholder="e.g. SOLSTICE2025" 
                        className={`${inputClass} font-mono font-bold tracking-[0.4em] py-5 text-xl`} 
                        required 
                      />
                  </div>
                  
                  <div>
                      <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest flex items-center gap-2"><Layers size={12} /> Reduction Class</label>
                      <select name="discountType" value={currentCoupon.discountType} onChange={handleChange} className={inputClass}>
                          <option value="percent">Percentage (%)</option>
                          <option value="fixed">Fixed Amount ($)</option>
                      </select>
                  </div>

                  <div>
                      <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest flex items-center gap-2"><Activity size={12} /> Honorarium Value</label>
                      <input type="number" name="value" value={currentCoupon.value} onChange={handleChange} className={`${inputClass} font-bold text-lg`} min="0" required />
                  </div>

                  <div>
                      <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest flex items-center gap-2"><Info size={12} /> Entry Threshold ($)</label>
                      <input type="number" name="minOrderValue" value={currentCoupon.minOrderValue} onChange={handleChange} className={inputClass} placeholder="0.00" min="0" />
                  </div>

                  <div>
                      <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest flex items-center gap-2"><Calendar size={12} /> Sunset (Expiry Date)</label>
                      <input type="date" name="expiryDate" value={currentCoupon.expiryDate} onChange={handleChange} className={inputClass} required />
                  </div>

                  <div>
                      <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest flex items-center gap-2"><Hash size={12} /> Usage Limit</label>
                      <input type="number" name="usageLimit" value={currentCoupon.usageLimit} onChange={handleChange} className={inputClass} placeholder="100" min="1" />
                  </div>

                  <div>
                      <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest">Protocol Status</label>
                      <select name="status" value={currentCoupon.status} onChange={handleChange} className={`${inputClass} font-bold text-xs uppercase tracking-widest`}>
                          <option value="active">Active Sequence</option>
                          <option value="expired">Archived / Paused</option>
                      </select>
                  </div>
                  
                  <div className="md:col-span-2">
                      <label className="block text-[10px] font-black uppercase text-stone-400 mb-3 tracking-widest flex items-center gap-2"><AlignLeft size={12} /> Internal Registry Narrative</label>
                      <textarea 
                        name="description" 
                        value={currentCoupon.description} 
                        onChange={handleChange} 
                        rows={3} 
                        className={`${inputClass} resize-none font-serif italic text-base p-5`} 
                        placeholder="Contextual notes for this protocol..." 
                      />
                  </div>
              </div>

              {error && <p className="text-red-500 text-[10px] flex items-center gap-2 font-bold uppercase tracking-widest"><AlertCircle size={14} /> {error}</p>}
            </form>

            {/* Modal Footer */}
            <div className="p-6 border-t border-stone-100 bg-[#FCFBFA]/90 backdrop-blur shrink-0 sticky bottom-0 z-10">
                <button 
                  onClick={handleSave}
                  className="w-full py-5 bg-brand-black text-white font-black uppercase tracking-[0.5em] text-[11px] rounded-2xl hover:bg-brand-crimson transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-4"
                >
                  <Save size={18} /> Finalize Archive Protocol
                </button>
            </div>
          </motion.div>
        </div>
      )}
      </AnimatePresence>
    </div>
  );
};
