
import React, { useState } from 'react';
import { Shield, Lock, AlertOctagon, AlertCircle } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const Security: React.FC = () => {
  const { securitySettings, updateSecuritySettings, blockedIPs, addBlockedIP, removeBlockedIP } = useShop();
  const [newIP, setNewIP] = useState('');
  const [error, setError] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setNewIP(val);
      if (val && !/^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(val)) {
          setError('Invalid IP format');
      } else {
          setError('');
      }
  };

  const handleBlockIP = () => {
    if (newIP && !error) {
      addBlockedIP(newIP);
      setNewIP('');
    } else if (!newIP) {
        setError('Enter an IP address');
    }
  };

  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold text-brand-black mb-8">Security Center</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
           <div className="flex items-center gap-3 mb-6 pb-4 border-b border-stone-100"><Lock className="text-brand-crimson" size={20} /><h3 className="font-bold text-brand-black">Access Control</h3></div>
           <div className="space-y-6">
              <div className="flex items-center justify-between">
                 <h4 className="font-bold text-sm text-brand-black">Two-Factor Authentication (2FA)</h4>
                 <button onClick={() => updateSecuritySettings({ twoFactor: !securitySettings.twoFactor })} className={`w-12 h-6 rounded-full p-1 transition-colors ${securitySettings.twoFactor ? 'bg-brand-black' : 'bg-stone-200'}`}><div className={`w-4 h-4 bg-white rounded-full transition-transform shadow-sm ${securitySettings.twoFactor ? 'translate-x-6' : 'translate-x-0'}`} /></button>
              </div>
           </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
           <div className="flex items-center gap-3 mb-6 pb-4 border-b border-stone-100"><AlertOctagon className="text-red-500" size={20} /><h3 className="font-bold text-brand-black">IP Blacklist</h3></div>
           <div className="space-y-4">
              <div className="flex gap-2">
                 <div className="flex-1">
                    <input 
                        type="text" 
                        value={newIP} 
                        onChange={handleInputChange} 
                        placeholder="Enter IP Address" 
                        className={`w-full bg-white border rounded-lg p-2 text-sm text-brand-black outline-none transition-colors ${error ? 'border-red-500 focus:border-red-500' : 'border-stone-300 focus:border-brand-black'}`} 
                    />
                 </div>
                 <button onClick={handleBlockIP} className="bg-brand-crimson text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-red-800 h-10">Block</button>
              </div>
              {error && <p className="text-red-500 text-[10px] flex items-center gap-1"><AlertCircle size={10} /> {error}</p>}
           </div>
        </div>
      </div>
    </div>
  );
};
