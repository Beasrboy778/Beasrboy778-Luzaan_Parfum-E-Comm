
import React, { useState } from 'react';
import { Truck, MapPin, Globe, Save, Plus, X, ShieldCheck, AlertCircle, Zap, Clock, Info, Server, Key, Eye, EyeOff } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { ShippingConfig } from '../../types';
import { motion, AnimatePresence } from 'framer-motion';

export const Shipping: React.FC = () => {
  const { shippingSettings, updateShippingSettings } = useShop();
  const [formData, setFormData] = useState<ShippingConfig>(shippingSettings);
  const [newZoneName, setNewZoneName] = useState('');
  const [newZoneRate, setNewZoneRate] = useState('');
  const [newZoneTime, setNewZoneTime] = useState('5-7 Business Days');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showApiKey, setShowApiKey] = useState(false);

  const handleSave = () => {
    // Crucial: Pass the new object to context to trigger state update
    updateShippingSettings(formData);
    
    const btn = document.getElementById('save-shipping-btn');
    if (btn) {
        const originalText = btn.innerHTML;
        btn.innerHTML = 'Logistics Synced';
        btn.classList.replace('bg-brand-black', 'bg-green-600');
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.classList.replace('bg-green-600', 'bg-brand-black');
        }, 2000);
    }
  };

  const toggleCarrier = (carrier: keyof ShippingConfig['carriers']) => {
    setFormData(prev => ({
        ...prev,
        carriers: { ...prev.carriers, [carrier]: !prev.carriers[carrier] }
    }));
  };

  const validateZone = () => {
      const newErrors: Record<string, string> = {};
      if (!newZoneName.trim()) newErrors.name = 'Protocol name required';
      if (!newZoneRate || parseFloat(newZoneRate) < 0) newErrors.rate = 'Value protocol required';
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  };

  const addZone = () => {
    if (validateZone()) {
        const isExpress = newZoneName.toLowerCase().includes('express') || 
                          newZoneName.toLowerCase().includes('priority') || 
                          newZoneName.toLowerCase().includes('overnight');
        
        const newZone = { 
            id: Date.now().toString(), 
            name: newZoneName, 
            rate: parseFloat(newZoneRate),
            deliveryTime: newZoneTime,
            isExpress
        };

        setFormData(prev => ({
            ...prev,
            zones: [...prev.zones, newZone]
        }));
        
        setNewZoneName('');
        setNewZoneRate('');
        setNewZoneTime('5-7 Business Days');
        setErrors({});
    }
  };

  const removeZone = (id: string) => {
    setFormData(prev => ({ 
        ...prev, 
        zones: prev.zones.filter(z => z.id !== id) 
    }));
  };

  const handleThresholdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = parseFloat(e.target.value) || 0;
      setFormData(prev => ({ ...prev, freeShippingThreshold: val }));
  };

  const glassInputClass = "w-full bg-white/40 backdrop-blur-md border border-stone-200/50 p-3 rounded-xl text-sm text-brand-black outline-none focus:bg-white/70 focus:border-brand-black transition-all shadow-inner placeholder-stone-400";

  return (
    <div className="animate-fade-in pb-20 text-brand-black">
      <div className="flex justify-between items-center mb-10">
        <div>
            <h1 className="text-3xl font-serif font-bold">Logistics Infrastructure</h1>
            <p className="text-stone-500 mt-1">Direct the global movement of your signature archive.</p>
        </div>
        <button 
            id="save-shipping-btn"
            onClick={handleSave} 
            className="flex items-center gap-2 px-10 py-4 bg-brand-black text-white rounded-xl text-xs font-black uppercase tracking-[0.2em] hover:bg-stone-800 transition-all shadow-2xl active:scale-95"
        >
            <Save size={18} /> Archive Logistics
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
         <div className="lg:col-span-2 space-y-10">
             {/* Global Protocol Card */}
             <div className="bg-white p-10 rounded-[2.5rem] border border-stone-200 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 opacity-[0.03] pointer-events-none">
                    <Globe size={200} />
                </div>
                <h3 className="font-bold text-lg text-brand-black mb-8 flex items-center gap-3 border-b border-stone-50 pb-6">
                    <Zap size={20} className="text-brand-crimson" /> Core Global Protocol
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div className="p-8 bg-stone-50/50 border border-stone-100 rounded-[2rem] flex items-center justify-between shadow-inner">
                        <div>
                            <h4 className="font-black text-[10px] uppercase tracking-[0.3em] text-stone-400 mb-1">Global Access</h4>
                            <p className="text-sm font-bold text-brand-black">International Delivery</p>
                        </div>
                        <button 
                            onClick={() => setFormData(p => ({ ...p, enableInternational: !p.enableInternational }))}
                            className={`w-16 h-9 rounded-full p-1.5 transition-all duration-500 ${formData.enableInternational ? 'bg-brand-crimson' : 'bg-stone-300'}`}
                        >
                            <div className={`w-6 h-6 bg-white rounded-full shadow-lg transition-transform duration-500 ${formData.enableInternational ? 'translate-x-7' : 'translate-x-0'}`} />
                        </button>
                    </div>

                    <div className="p-8 bg-stone-50/50 border border-stone-100 rounded-[2rem] shadow-inner">
                        <h4 className="font-black text-[10px] uppercase tracking-[0.3em] text-stone-400 mb-3">Honors Threshold</h4>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-crimson font-black text-xl">$</span>
                            <input 
                                type="number" 
                                value={formData.freeShippingThreshold}
                                onChange={handleThresholdChange}
                                className="w-full bg-white border border-stone-200 rounded-xl pl-10 pr-4 py-4 text-2xl font-serif font-bold text-brand-black outline-none focus:border-brand-black shadow-sm"
                            />
                        </div>
                        <p className="text-[9px] text-stone-400 mt-3 font-bold uppercase tracking-widest italic opacity-60">Minimum purchase for complimentary delivery</p>
                    </div>
                </div>
             </div>

             {/* Carrier API Integration Section */}
             <div className="bg-white p-10 rounded-[2.5rem] border border-stone-200 shadow-sm relative overflow-hidden">
                 <h3 className="font-bold text-lg text-brand-black mb-8 flex items-center gap-3 border-b border-stone-50 pb-6">
                    <Server size={20} className="text-brand-crimson" /> External Fulfillment API
                 </h3>
                 <p className="text-sm text-stone-500 mb-6 italic">Connect your shipping provider API to automate label generation and returns.</p>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                     <div>
                         <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-3">Provider Gateway</label>
                         <select 
                            value={formData.apiProvider || 'manual'} 
                            onChange={(e) => setFormData({...formData, apiProvider: e.target.value as any})}
                            className="w-full bg-stone-50 border border-stone-200 p-4 rounded-xl text-sm font-bold text-brand-black outline-none focus:border-brand-black transition-all cursor-pointer"
                         >
                             <option value="manual">Manual Entry Only</option>
                             <option value="shippo">Shippo API</option>
                             <option value="easypost">EasyPost API</option>
                             <option value="fedex_api">FedEx Direct</option>
                         </select>
                     </div>
                     <div>
                         <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-3 flex items-center gap-2"><Key size={12} /> Live API Key</label>
                         <div className="relative">
                             <input 
                                type={showApiKey ? "text" : "password"}
                                placeholder="pk_live_..."
                                value={formData.apiKey || ''}
                                onChange={(e) => setFormData({...formData, apiKey: e.target.value})}
                                className={`${glassInputClass} pr-10`}
                             />
                             <button 
                                type="button" 
                                onClick={() => setShowApiKey(!showApiKey)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-brand-black"
                             >
                                 {showApiKey ? <EyeOff size={16} /> : <Eye size={16} />}
                             </button>
                         </div>
                     </div>
                 </div>
                 
                 {formData.apiProvider && formData.apiProvider !== 'manual' && (
                     <div className="mt-6 p-4 bg-green-50 border border-green-100 rounded-xl flex items-center gap-3 text-green-700 text-xs font-bold">
                         <ShieldCheck size={16} /> 
                         Automated Return Labels & Tracking Generation Enabled via {formData.apiProvider.toUpperCase()}
                     </div>
                 )}
             </div>

             {/* Delivery Methods Card */}
             <div className="bg-white p-10 rounded-[2.5rem] border border-stone-200 shadow-sm">
                <div className="flex justify-between items-center mb-10 border-b border-stone-50 pb-6">
                    <h3 className="font-bold text-lg text-brand-black flex items-center gap-3">
                        <MapPin size={22} className="text-brand-crimson" /> Delivery Tiers
                    </h3>
                    <div className="flex items-center gap-2 text-[10px] bg-brand-crimson/5 text-brand-crimson px-5 py-2 rounded-full font-black uppercase tracking-widest border border-brand-crimson/10 shadow-sm">
                        <Info size={14} /> {formData.zones.length} Active Methods
                    </div>
                </div>

                <div className="space-y-6 mb-12">
                  {formData.zones.map((zone) => (
                    <motion.div layout key={zone.id} className="flex items-center justify-between p-8 bg-stone-50/30 border border-stone-100 rounded-3xl hover:border-brand-black/20 hover:bg-white transition-all group shadow-sm">
                       <div className="flex items-center gap-6">
                           <div className={`p-5 rounded-2xl ${zone.isExpress ? 'bg-brand-crimson/10 text-brand-crimson shadow-[0_0_15px_rgba(128,0,32,0.1)]' : 'bg-white text-stone-400 shadow-sm'} border border-white`}>
                               {zone.isExpress ? <Zap size={24} /> : <Clock size={24} />}
                           </div>
                           <div>
                               <span className="text-brand-black text-xl font-serif italic block leading-tight mb-1">{zone.name}</span>
                               <span className="text-[10px] text-stone-400 font-black uppercase tracking-[0.3em]">{zone.deliveryTime}</span>
                           </div>
                       </div>
                       <div className="flex items-center gap-10">
                           <div className="text-right">
                               <p className="text-[9px] text-stone-400 font-black uppercase tracking-widest mb-1 opacity-60">Flat Protocol Rate</p>
                               <span className="text-2xl font-serif font-bold text-brand-black">${zone.rate.toFixed(2)}</span>
                           </div>
                           <button 
                                onClick={() => removeZone(zone.id)} 
                                className="p-4 text-stone-300 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all shadow-sm group-hover:scale-110"
                           >
                               <X size={22} />
                           </button>
                       </div>
                    </motion.div>
                  ))}
                </div>
                
                {/* Form to add new methods */}
                <div className="p-10 border-2 border-dashed border-stone-200 rounded-[3rem] bg-stone-50/20">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-stone-400 mb-10 flex items-center justify-center gap-3">
                        <Plus size={16} /> Register New Logistics Node
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
                        <div className="md:col-span-2">
                            <label className="block text-[10px] font-black uppercase text-stone-500 mb-3 tracking-widest">Protocol Identifier</label>
                            <input 
                                type="text" 
                                placeholder="e.g. Continental Express" 
                                value={newZoneName}
                                onChange={(e) => { setNewZoneName(e.target.value); if(e.target.value) setErrors(prev => ({...prev, name: ''})) }}
                                className={`${glassInputClass} py-5 font-serif italic text-lg`}
                            />
                            {errors.name && <p className="text-[10px] text-red-500 mt-2 font-bold uppercase tracking-widest italic">{errors.name}</p>}
                        </div>
                        <div>
                            <label className="block text-[10px] font-black uppercase text-stone-500 mb-3 tracking-widest">Value ($)</label>
                            <input 
                                type="number" 
                                placeholder="0.00" 
                                value={newZoneRate}
                                onChange={(e) => { setNewZoneRate(e.target.value); if(e.target.value) setErrors(prev => ({...prev, rate: ''})) }}
                                className={`${glassInputClass} py-5 text-xl font-bold`}
                            />
                            {errors.rate && <p className="text-[10px] text-red-500 mt-2 font-bold uppercase tracking-widest italic">{errors.rate}</p>}
                        </div>
                        <div className="md:col-span-3">
                            <label className="block text-[10px] font-black uppercase text-stone-500 mb-3 tracking-widest">Fulfillment Window</label>
                            <select 
                                value={newZoneTime}
                                onChange={(e) => setNewZoneTime(e.target.value)}
                                className={`${glassInputClass} h-[60px] cursor-pointer`}
                            >
                                <option>1-2 Business Days</option>
                                <option>2-3 Business Days</option>
                                <option>5-7 Business Days</option>
                                <option>7-14 Business Days</option>
                                <option>Overnight Express</option>
                            </select>
                        </div>
                    </div>
                    <button 
                        onClick={addZone} 
                        className="w-full bg-brand-black text-white font-black text-[11px] uppercase tracking-[0.5em] py-6 rounded-2xl hover:bg-brand-crimson transition-all shadow-xl active:scale-[0.98] flex items-center justify-center gap-4"
                    >
                        Register Logistics Route
                    </button>
                </div>
             </div>
         </div>

         {/* Sidebar Controls */}
         <div className="space-y-10">
             <div className="bg-white p-10 rounded-[2.5rem] border border-stone-200 shadow-sm h-fit">
                <h3 className="font-bold text-lg text-brand-black mb-6 flex items-center gap-3 border-b border-stone-50 pb-4">
                    <Truck size={22} className="text-brand-crimson" /> Carrier Integration
                </h3>
                <p className="text-xs text-stone-500 mb-10 leading-relaxed italic opacity-70">Link Tier-1 carriers for automated real-time tracking.</p>
                
                <div className="space-y-4">
                  {[
                      { id: 'fedex', label: 'FedEx Signature', color: '#4D148C' },
                      { id: 'dhl', label: 'DHL Priority', color: '#FFCC00' },
                      { id: 'ups', label: 'UPS Worldwide', color: '#351C15' },
                      { id: 'usps', label: 'USPS Ground', color: '#004B87' },
                  ].map((carrier) => {
                    const isActive = formData.carriers[carrier.id as keyof typeof formData.carriers];
                    return (
                        <div key={carrier.id} className={`flex items-center justify-between p-6 rounded-2xl border transition-all duration-500 ${isActive ? 'bg-stone-50 border-stone-300 shadow-sm' : 'bg-white border-stone-100 opacity-40 grayscale'}`}>
                            <div className="flex items-center gap-4">
                                <div 
                                    className="w-12 h-12 rounded-xl flex items-center justify-center font-black text-xl shadow-inner border border-white/20"
                                    style={{ backgroundColor: carrier.color, color: (carrier.id === 'dhl' || carrier.id === 'usps' && false) ? '#000' : '#fff' }}
                                >
                                    {carrier.label.charAt(0)}
                                </div>
                                <span className={`text-[10px] font-black uppercase tracking-widest ${isActive ? 'text-brand-black' : 'text-stone-400'}`}>
                                    {carrier.label}
                                </span>
                            </div>
                            <button 
                                onClick={() => toggleCarrier(carrier.id as any)}
                                className={`w-14 h-8 rounded-full p-1.5 transition-all duration-300 relative ${isActive ? 'bg-brand-black' : 'bg-stone-200'}`}
                            >
                                <div className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform ${isActive ? 'translate-x-6' : 'translate-x-0'}`} />
                            </button>
                        </div>
                    );
                  })}
                </div>

                <div className="mt-12 p-8 bg-stone-50 rounded-[2.5rem] border border-stone-100 shadow-inner text-center">
                    <p className="text-[10px] text-stone-400 font-black uppercase tracking-[0.4em] mb-4 opacity-60">System Resilience</p>
                    <div className="flex items-center justify-center gap-3">
                        <div className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-[0_0_12px_rgba(34,197,94,0.6)] animate-pulse" />
                        <span className="text-xs font-bold text-brand-black uppercase tracking-widest">Global Sync Active</span>
                    </div>
                </div>
             </div>

             <div className="bg-brand-black text-white p-12 rounded-[2.5rem] shadow-2xl relative overflow-hidden group">
                 <div className="absolute -right-8 -bottom-8 opacity-10 group-hover:scale-125 transition-transform duration-[2s] rotate-12">
                     <ShieldCheck size={180} />
                 </div>
                 <h4 className="font-serif text-3xl mb-6 italic">Secure API Interface</h4>
                 <p className="text-stone-400 text-sm leading-relaxed mb-10 font-light tracking-wide opacity-80">
                     Connect your fulfillment API keys to unlock automated label generation and real-time transit insurance.
                 </p>
                 <button className="w-full py-5 bg-white text-brand-black text-[10px] font-black uppercase tracking-[0.5em] rounded-xl hover:bg-brand-gold hover:text-brand-black transition-all duration-500 shadow-xl active:scale-95">
                     Interface API Keys
                 </button>
             </div>
         </div>
      </div>
    </div>
  );
};
