
import React, { useState, useEffect, useRef } from 'react';
import { Plus, Edit2, Trash2, Search, X, Save, Image as ImageIcon, AlignLeft, Calendar, Clock, Tag, AlertCircle, Upload, Loader2 } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { BlogPost } from '../../types';

// Utils
const getImageSize = (dataUrl: string) => {
    if (!dataUrl) return '0 KB';
    const sizeInBytes = dataUrl.length * 0.75; 
    const sizeInKb = sizeInBytes / 1024;
    return sizeInKb.toFixed(1) + ' KB';
};

const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 1200; // Blog images might be wider
                let width = img.width;
                let height = img.height;

                if (width > MAX_WIDTH) {
                    height *= MAX_WIDTH / width;
                    width = MAX_WIDTH;
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                const dataUrl = canvas.toDataURL('image/webp', 0.8);
                resolve(dataUrl);
            };
            img.onerror = (error) => reject(error);
        };
        reader.onerror = (error) => reject(error);
    });
};

export const Stories: React.FC = () => {
  const { blogPosts, addBlogPost, updateBlogPost, deleteBlogPost } = useShop();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imgDims, setImgDims] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<Partial<BlogPost>>({
    title: '', excerpt: '', content: '', category: 'Scent Guide', readTime: '5 min read', image: '', date: ''
  });

  useEffect(() => {
    if (isModalOpen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [isModalOpen]);

  const filteredPosts = blogPosts.filter(p => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData({
      title: '', 
      excerpt: '', 
      content: '<p>Start writing your story here...</p>', 
      category: 'Scent Guide', 
      readTime: '5 min read', 
      image: '',
      date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    });
    setErrors({});
    setIsModalOpen(true);
  };

  const handleOpenEdit = (post: BlogPost) => {
    setIsEditMode(true);
    setFormData({ ...post });
    setErrors({});
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this story?')) {
      deleteBlogPost(id);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          setIsProcessing(true);
          try {
              const compressed = await compressImage(file);
              setFormData(prev => ({ ...prev, image: compressed }));
          } catch (e) {
              console.error(e);
          } finally {
              setIsProcessing(false);
          }
      }
  };

  const validate = (name: string, value: string) => {
      let error = '';
      if (name === 'title' && !value.trim()) error = 'Title is required.';
      if (name === 'content' && !value.trim()) error = 'Content is required.';
      setErrors(prev => ({...prev, [name]: error}));
      return error === '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const isTitleValid = validate('title', formData.title || '');
    const isContentValid = validate('content', formData.content || '');
    
    if(!isTitleValid || !isContentValid) return;

    if (isEditMode && formData.id) {
        updateBlogPost(formData as BlogPost);
    } else {
        const newPost: BlogPost = {
            id: Date.now().toString(),
            title: formData.title || 'Untitled',
            excerpt: formData.excerpt || '',
            content: formData.content || '',
            category: formData.category || 'General',
            readTime: formData.readTime || '3 min read',
            image: formData.image || 'https://picsum.photos/800/600',
            date: formData.date || new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
        };
        addBlogPost(newPost);
    }
    setIsModalOpen(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
      validate(name, value);
  };

  const glassInputClass = "w-full bg-white border border-stone-200 p-4 rounded-xl text-sm text-brand-black outline-none focus:border-brand-black transition-all shadow-sm placeholder-stone-400";

  return (
    <div className="animate-fade-in relative text-brand-black">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-brand-black">Stories & Blog</h1>
          <p className="text-stone-500 text-sm mt-1">Manage journal entries and content marketing.</p>
        </div>
        <button onClick={handleOpenAdd} className="flex items-center gap-2 px-6 py-3 bg-brand-black text-white rounded-lg text-sm font-bold uppercase tracking-wide hover:bg-stone-800 transition-colors shadow-sm">
          <Plus size={16} /> Write Story
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden">
         <div className="p-4 border-b border-stone-200 bg-stone-50/50">
            <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                <input type="text" placeholder="Search stories..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-stone-300 rounded-lg text-sm outline-none focus:border-brand-black bg-white text-brand-black" />
            </div>
         </div>
         <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
                <thead className="bg-stone-50 text-stone-500 uppercase text-xs font-bold border-b border-stone-200">
                <tr><th className="px-6 py-4">Title</th><th className="px-6 py-4">Category</th><th className="px-6 py-4">Date</th><th className="px-6 py-4 text-right">Actions</th></tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                {filteredPosts.length > 0 ? (
                    filteredPosts.map(post => (
                        <tr key={post.id} className="hover:bg-stone-50 transition-colors">
                            <td className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded bg-stone-200 overflow-hidden flex-shrink-0">
                                        <img src={post.image} alt="" className="w-full h-full object-cover" />
                                    </div>
                                    <span className="font-bold text-brand-black">{post.title}</span>
                                </div>
                            </td>
                            <td className="px-6 py-4"><span className="px-2 py-1 bg-stone-100 text-stone-600 rounded text-xs font-medium border border-stone-200">{post.category}</span></td>
                            <td className="px-6 py-4 text-stone-500 text-xs">{post.date}</td>
                            <td className="px-6 py-4 text-right">
                                <div className="flex items-center justify-end gap-2">
                                    <button onClick={() => handleOpenEdit(post)} className="p-2 text-stone-500 hover:text-brand-black hover:bg-stone-100 rounded-md"><Edit2 size={16} /></button>
                                    <button onClick={() => handleDelete(post.id)} className="p-2 text-stone-500 hover:text-red-600 hover:bg-red-50 rounded-md"><Trash2 size={16} /></button>
                                </div>
                            </td>
                        </tr>
                    ))
                ) : (
                    <tr><td colSpan={4} className="px-6 py-8 text-center text-stone-400">No stories found.</td></tr>
                )}
                </tbody>
            </table>
         </div>
      </div>

      {isModalOpen && (
        // Changed overlay to white/60 blur
        <div className="fixed inset-0 z-[2000] flex items-start justify-center pt-24 md:pt-32 pb-6 px-4 bg-white/60 backdrop-blur-md overflow-hidden" onClick={() => setIsModalOpen(false)}>
            <div className="bg-white w-full max-w-4xl rounded-[2.5rem] shadow-[0_60px_100px_rgba(0,0,0,0.3)] overflow-hidden border border-stone-100 max-h-[calc(100vh-8rem)] flex flex-col relative shrink-0" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-6 border-b border-stone-100 bg-[#FCFBFA]/90 backdrop-blur sticky top-0 z-20 shrink-0">
                    <h2 className="text-xl font-bold text-brand-black">{isEditMode ? 'Edit Story' : 'New Story'}</h2>
                    <button onClick={() => setIsModalOpen(false)} className="text-stone-400 hover:text-brand-black w-9 h-9 flex items-center justify-center rounded-full hover:bg-stone-50 transition-colors"><X size={20} /></button>
                </div>
                
                <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8 bg-white custom-scrollbar">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        {/* Main Content Column */}
                        <div className="lg:col-span-2 space-y-6">
                            <div>
                                <label className="block text-xs font-bold uppercase text-stone-500 mb-2">Title <span className="text-red-500">*</span></label>
                                <input type="text" name="title" value={formData.title} onChange={handleChange} className={glassInputClass} placeholder="Enter story title..." required />
                                {errors.title && <p className="text-red-500 text-[10px] mt-1 flex items-center gap-1"><AlertCircle size={10} /> {errors.title}</p>}
                            </div>
                            
                            <div>
                                <label className="block text-xs font-bold uppercase text-stone-500 mb-2">Excerpt</label>
                                <textarea name="excerpt" value={formData.excerpt} onChange={handleChange} rows={3} className={`${glassInputClass} resize-none`} placeholder="Brief summary for list view..." />
                            </div>

                            <div>
                                <label className="block text-xs font-bold uppercase text-stone-500 mb-2 flex items-center gap-2"><AlignLeft size={14} /> Content (HTML Supported) <span className="text-red-500">*</span></label>
                                <textarea name="content" value={formData.content} onChange={handleChange} rows={12} className={`${glassInputClass} font-mono`} placeholder="<p>Write your content here...</p>" required />
                                {errors.content && <p className="text-red-500 text-[10px] mt-1 flex items-center gap-1"><AlertCircle size={10} /> {errors.content}</p>}
                                <p className="text-[10px] text-stone-400 mt-2">Use simple HTML tags for formatting: &lt;p&gt;, &lt;h3&gt;, &lt;b&gt;, &lt;ul&gt;</p>
                            </div>
                        </div>

                        {/* Sidebar Settings Column */}
                        <div className="space-y-6">
                            <div className="bg-stone-50/50 border border-stone-200/50 p-6 rounded-2xl">
                                <h3 className="font-bold text-sm mb-4 border-b border-stone-200/50 pb-2">Publishing</h3>
                                <div className="space-y-4">
                                    <div>
                                        <label className="block text-[10px] font-bold uppercase text-stone-500 mb-1">Category</label>
                                        <select name="category" value={formData.category} onChange={handleChange} className={glassInputClass}>
                                            <option>Scent Guide</option>
                                            <option>Behind the Scenes</option>
                                            <option>Lifestyle</option>
                                            <option>News</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-bold uppercase text-stone-500 mb-1 flex items-center gap-1"><Clock size={10} /> Read Time</label>
                                        <input type="text" name="readTime" value={formData.readTime} onChange={handleChange} className={glassInputClass} placeholder="e.g. 5 min read" />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-bold uppercase text-stone-500 mb-1 flex items-center gap-1"><Calendar size={10} /> Publish Date</label>
                                        <input type="text" name="date" value={formData.date} onChange={handleChange} className={glassInputClass} placeholder="October 12, 2023" />
                                    </div>
                                </div>
                            </div>

                            <div className="bg-stone-50/50 border border-stone-200/50 p-6 rounded-2xl">
                                <h3 className="font-bold text-sm mb-4 border-b border-stone-200/50 pb-2 flex items-center gap-2"><ImageIcon size={14} /> Featured Image</h3>
                                <div onClick={() => fileInputRef.current?.click()} className="aspect-video w-full rounded-lg overflow-hidden border-2 border-dashed border-stone-200 bg-white cursor-pointer relative group hover:border-brand-black transition-all">
                                    {isProcessing ? (
                                        <div className="flex flex-col items-center justify-center h-full gap-2">
                                            <Loader2 size={24} className="animate-spin text-brand-black" />
                                            <span className="text-[9px] font-bold uppercase tracking-widest text-stone-400">Compressing...</span>
                                        </div>
                                    ) : formData.image ? (
                                        <>
                                            <img 
                                                src={formData.image} 
                                                alt="Preview" 
                                                className="w-full h-full object-cover" 
                                                onLoad={(e) => setImgDims(`${e.currentTarget.naturalWidth}x${e.currentTarget.naturalHeight}`)}
                                            />
                                            {imgDims && (
                                                <div className="absolute bottom-2 left-2 right-2 bg-black/60 backdrop-blur text-white text-[7px] font-mono text-center rounded py-1 pointer-events-none">
                                                    {imgDims} • {getImageSize(formData.image)}
                                                </div>
                                            )}
                                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                                <Upload className="text-white" size={24} />
                                            </div>
                                        </>
                                    ) : (
                                        <div className="flex flex-col items-center justify-center h-full text-stone-300">
                                            <Upload size={24} />
                                            <span className="text-[9px] mt-2 font-black uppercase tracking-widest">Upload Cover</span>
                                            <span className="text-[7px] font-mono text-stone-400 bg-stone-100 px-1.5 py-0.5 rounded">Rec: 1200x800px</span>
                                        </div>
                                    )}
                                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                                </div>
                                <div className="mt-4">
                                    <label className="block text-[8px] font-black uppercase tracking-widest text-stone-400 mb-1">Or Paste URL</label>
                                    <input type="text" name="image" value={formData.image} onChange={handleChange} className={`${glassInputClass} py-2 text-xs`} placeholder="https://..." />
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

                <div className="p-6 border-t border-stone-100 bg-[#FCFBFA]/90 backdrop-blur shrink-0 sticky bottom-0 z-10 flex justify-end gap-4">
                    <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-3 text-brand-black font-bold uppercase tracking-widest text-[10px] hover:bg-stone-100 rounded-xl transition-colors">Cancel</button>
                    <button onClick={handleSubmit} type="submit" disabled={isProcessing} className="px-8 py-3 bg-brand-black text-white font-black uppercase tracking-widest text-[10px] rounded-xl hover:bg-stone-800 flex items-center gap-2 shadow-lg transition-all active:scale-95 disabled:opacity-50">
                        <Save size={16} /> Save Story
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
