
import React, { useState } from 'react';
import { Check, X, MessageSquare, AlertCircle, Trash2 } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const Comments: React.FC = () => {
  const { blogComments, updateBlogCommentStatus, deleteBlogComment } = useShop();
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const filteredComments = blogComments.filter(c => filter === 'all' ? true : c.status === filter);
  const pendingCount = blogComments.filter(c => c.status === 'pending').length;

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <div>
           <h1 className="text-2xl font-bold text-brand-black">Blog Moderation</h1>
           <p className="text-stone-500 text-sm mt-1">Review and approve reader engagement.</p>
        </div>
        <div className="bg-white px-4 py-2 rounded-lg border border-stone-200 shadow-sm flex items-center gap-2">
             <div className="p-1 bg-brand-crimson/10 rounded text-brand-crimson"><MessageSquare size={14} /></div>
             <div>
                 <p className="text-[10px] font-bold uppercase text-stone-400">Total Comments</p>
                 <p className="font-bold text-brand-black">{blogComments.length}</p>
             </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden">
        <div className="p-6 border-b border-stone-200 flex flex-col md:flex-row gap-4 justify-between items-center bg-stone-50/50">
          <div className="flex gap-2">
            <button onClick={() => setFilter('all')} className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${filter === 'all' ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}>All</button>
            <button onClick={() => setFilter('pending')} className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${filter === 'pending' ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}>
                Pending {pendingCount > 0 && <span className="ml-1 bg-red-500 text-white px-1.5 py-0.5 rounded-full text-[9px]">{pendingCount}</span>}
            </button>
            <button onClick={() => setFilter('approved')} className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${filter === 'approved' ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}>Approved</button>
            <button onClick={() => setFilter('rejected')} className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${filter === 'rejected' ? 'bg-brand-black text-white' : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'}`}>Rejected</button>
          </div>
        </div>
        
        <div className="divide-y divide-stone-100">
          {filteredComments.length === 0 ? (
              <div className="p-12 text-center text-stone-400">
                  <AlertCircle size={48} className="mx-auto mb-4 opacity-50" />
                  <p>No comments found matching this filter.</p>
              </div>
          ) : (
            filteredComments.map(comment => (
                <div key={comment.id} className="p-6 flex flex-col md:flex-row gap-6 hover:bg-stone-50 transition-colors group">
                <div className="md:w-48 flex-shrink-0">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-stone-200 flex items-center justify-center font-bold text-stone-600 text-xs">
                            {comment.userName.charAt(0)}
                        </div>
                        <div>
                            <h4 className="font-bold text-brand-black text-sm">{comment.userName}</h4>
                            <p className="text-[10px] text-stone-500">{comment.date}</p>
                        </div>
                    </div>
                    <p className="text-[10px] text-stone-400 truncate">{comment.email}</p>
                </div>
                
                <div className="flex-1">
                    <h5 className="font-bold text-xs uppercase text-stone-400 mb-2">Story: <span className="text-brand-crimson">{comment.postTitle || 'Unknown Post'}</span></h5>
                    <p className="text-stone-700 text-sm leading-relaxed mb-4 bg-white p-4 border border-stone-100 rounded-xl italic">"{comment.comment}"</p>
                    
                    <div className="flex items-center gap-3">
                        <span className={`px-2 py-1 rounded text-[10px] uppercase font-bold border ${comment.status === 'approved' ? 'bg-green-50 text-green-700 border-green-100' : comment.status === 'rejected' ? 'bg-red-50 text-red-700 border-red-100' : 'bg-yellow-50 text-yellow-700 border-yellow-100'}`}>
                            {comment.status}
                        </span>
                        
                        <div className="flex-1 border-b border-stone-100"></div>

                        {comment.status === 'pending' && (
                            <div className="flex gap-2">
                                <button onClick={() => updateBlogCommentStatus(comment.id, 'approved')} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white text-xs font-bold rounded-lg hover:bg-green-700 shadow-sm transition-colors"><Check size={14} /> Approve</button>
                                <button onClick={() => updateBlogCommentStatus(comment.id, 'rejected')} className="flex items-center gap-2 px-4 py-2 bg-white border border-red-200 text-red-600 text-xs font-bold rounded-lg hover:bg-red-50 transition-colors"><X size={14} /> Reject</button>
                            </div>
                        )}
                        {comment.status !== 'pending' && (
                            <button onClick={() => updateBlogCommentStatus(comment.id, 'pending')} className="text-xs text-stone-400 hover:text-brand-black underline font-medium">Re-Moderate</button>
                        )}
                        <button onClick={() => deleteBlogComment(comment.id)} className="p-2 text-stone-300 hover:text-red-500 transition-colors" title="Delete Comment">
                            <Trash2 size={16} />
                        </button>
                    </div>
                </div>
                </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
