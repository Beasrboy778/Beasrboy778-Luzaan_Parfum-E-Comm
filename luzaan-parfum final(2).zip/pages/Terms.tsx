
import React from 'react';
import { useShop } from '../context/ShopContext';

export const Terms: React.FC = () => {
  const { siteContent } = useShop();

  const formatText = (text: string) => {
    return text.split('\n\n').map((para, i) => (
      <p key={i} className="mb-8 last:mb-0">
        {para.split('\n').map((line, j) => (
          <React.Fragment key={j}>
            {line}
            <br />
          </React.Fragment>
        ))}
      </p>
    ));
  };

  return (
    <div className="pt-32 pb-24 px-6 max-w-4xl mx-auto animate-fade-in text-brand-black">
      <div className="mb-12 border-b border-brand-black/10 pb-8">
        <h1 className="font-serif text-4xl md:text-5xl mb-4 text-brand-black italic">Terms of Service</h1>
        <p className="text-stone-500 text-sm font-bold uppercase tracking-widest">Official Governance of the Aura Flagship</p>
      </div>

      <div className="font-serif text-xl leading-relaxed text-stone-700 italic max-w-2xl mx-auto">
         {formatText(siteContent.terms)}
      </div>
    </div>
  );
};
