
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useShop } from '../context/ShopContext';
import { useCurrency } from '../context/CurrencyContext';
// @ts-ignore
import { Navigate, useLocation } from 'react-router-dom';
import { Package, MapPin, User, LogOut, Plus, Trash2, Edit2, CheckCircle, Clock, Truck, XCircle, Mail, Bell, X, Globe, ArrowRight, Copy, Box } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Order } from '../types';

const TrackingModal = ({ order, onClose }: { order: Order; onClose: () => void }) => {
    const steps = [
        { id: 'placed', label: 'Order Placed', date: order.date, completed: true, icon: Package },
        { id: 'processing', label: 'Processing', date: 'In Progress', completed: ['Processing', 'Shipped', 'Delivered'].includes(order.status), icon: Box },
        { id: 'shipped', label: 'Shipped', date: 'Pending Carrier', completed: ['Shipped', 'Delivered'].includes(order.status), icon: Truck },
        { id: 'delivered', label: 'Delivered', date: 'Estimated Arrival', completed: order.status === 'Delivered', icon: CheckCircle },
    ];

    // Determine current step index for progress bar
    const currentStepIndex = steps.filter(s => s.completed).length;
    
    // Copy tracking number logic
    const [copied, setCopied] = useState(false);
    const handleCopy = () => {
        if (order.trackingNumber) {
            navigator.clipboard.writeText(order.trackingNumber);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    return (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 lg:p-8 bg-white/60 backdrop-blur-md" onClick={onClose}>
            <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white w-full max-w-4xl max-h-[90vh] rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row relative border border-stone-100"
            >
                {/* Close Button */}
                <button onClick={onClose} className="absolute top-5 right-5 z-20 p-2 bg-white/50 backdrop-blur rounded-full hover:bg-stone-100 transition-colors">
                    <X size={20} className="text-stone-500" />
                </button>

                {/* Left: Map / Visual */}
                <div className="w-full md:w-1/3 bg-stone-100 relative overflow-hidden min-h-[200px] md:min-h-full">
                    {/* Simulated Map Background */}
                    <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#121111 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
                        <div className="w-24 h-24 bg-white rounded-full shadow-xl flex items-center justify-center mb-6 relative">
                            <div className="absolute inset-0 rounded-full border-2 border-dashed border-brand-crimson animate-spin-slow" style={{ animationDuration: '10s' }} />
                            <Truck size={32} className="text-brand-crimson" />
                        </div>
                        <h3 className="font-serif text-2xl text-brand-black font-bold mb-2">
                            {order.status === 'Delivered' ? 'Arrived' : 'In Transit'}
                        </h3>
                        <p className="text-xs text-stone-500 uppercase tracking-widest font-bold">
                            {order.shippingAddress?.city}, {order.shippingAddress?.country}
                        </p>
                    </div>
                </div>

                {/* Right: Details & Timeline */}
                <div className="flex-1 p-8 lg:p-10 overflow-y-auto">
                    <div className="flex justify-between items-start mb-10">
                        <div>
                            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-brand-gold mb-2 block">Order ID</span>
                            <h2 className="text-2xl font-serif font-bold text-brand-black">{order.id}</h2>
                        </div>
                        <div className="text-right">
                            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-2 block">Estimated Delivery</span>
                            <p className="text-sm font-bold text-brand-black">
                                {order.status === 'Delivered' ? 'Delivered' : '3-5 Business Days'}
                            </p>
                        </div>
                    </div>

                    {/* Timeline */}
                    <div className="relative pl-4 space-y-10 mb-12">
                        {/* Vertical Line */}
                        <div className="absolute top-2 left-[19px] bottom-2 w-0.5 bg-stone-100 -z-10" />
                        
                        {steps.map((step, idx) => (
                            <div key={step.id} className="flex gap-6 items-start group">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border-4 transition-all duration-500 z-10 ${step.completed ? 'bg-brand-black border-brand-black text-white' : 'bg-white border-stone-200 text-stone-300'}`}>
                                    <step.icon size={16} />
                                </div>
                                <div className={`pt-1 transition-opacity duration-500 ${step.completed ? 'opacity-100' : 'opacity-40'}`}>
                                    <h4 className="font-bold text-sm text-brand-black mb-1">{step.label}</h4>
                                    <p className="text-xs text-stone-500">{step.date}</p>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Tracking Info Box */}
                    {order.trackingNumber && (
                        <div className="bg-stone-50 border border-stone-200 p-6 rounded-2xl mb-8 flex items-center justify-between">
                            <div>
                                <span className="text-[9px] font-black uppercase tracking-widest text-stone-400 block mb-1">Carrier Tracking ID</span>
                                <p className="font-mono font-bold text-brand-black text-lg">{order.trackingNumber}</p>
                            </div>
                            <button 
                                onClick={handleCopy}
                                className="p-3 bg-white border border-stone-200 rounded-xl hover:bg-brand-black hover:text-white transition-all shadow-sm flex items-center gap-2 group"
                            >
                                {copied ? <CheckCircle size={16} className="text-green-500" /> : <Copy size={16} className="group-hover:text-white" />}
                                <span className="text-[9px] font-bold uppercase tracking-widest">{copied ? 'Copied' : 'Copy'}</span>
                            </button>
                        </div>
                    )}

                    {/* Order Items Preview */}
                    <div>
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-6 block">Package Contents</span>
                        <div className="space-y-4">
                            {order.items.map((item, i) => (
                                <div key={i} className="flex items-center gap-4">
                                    <div className="w-12 h-12 bg-stone-50 border border-stone-100 rounded-lg p-1 flex items-center justify-center">
                                        <img src={item.images[0]} className="w-full h-full object-contain" alt="" />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-brand-black">{item.name}</p>
                                        <p className="text-[10px] text-stone-500 uppercase tracking-wider">{item.size} x {item.quantity}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </motion.div>
        </div>
    );
};

export const Account: React.FC = () => {
  const { user, logout, updateUser } = useAuth();
  const { adminOrders } = useShop(); 
  const { formatPrice } = useCurrency();
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'addresses'>('profile');
  const location = useLocation();
  
  // Tracking Modal State
  const [trackingOrder, setTrackingOrder] = useState<Order | null>(null);

  // Auto-open tracking if redirected from confirmation
  useEffect(() => {
      if (location.state?.focusOrderId) {
          const target = adminOrders.find(o => o.id === location.state.focusOrderId);
          if (target) {
              setActiveTab('orders');
              setTrackingOrder(target);
              window.history.replaceState({}, document.title);
          }
      }
  }, [location.state, adminOrders]);
  
  // Address State
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);
  const [newAddress, setNewAddress] = useState({
    firstName: '', lastName: '', street: '', city: '', state: '', zip: '', country: 'United States'
  });

  // LOGICAL FIX: Admins are the owners, they use the Dashboard, not the Customer Account page.
  if (user?.role === 'admin') {
    return <Navigate to="/admin" replace />;
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  const regions = [
    { name: 'United States', flag: '🇺🇸' },
    { name: 'United Kingdom', flag: '🇬🇧' },
    { name: 'Europe', flag: '🇪🇺' },
    { name: 'India', flag: '🇮🇳' },
    { name: 'Canada', flag: '🇨🇦' },
    { name: 'Australia', flag: '🇦🇺' }
  ];

  const userFlag = regions.find(r => r.name === user.region)?.flag || '🌐';

  // Filter orders for this user (mocking backend filtering)
  const myOrders = adminOrders.filter(o => o.customer.email === user.email);

  const handleLogout = () => {
    logout();
  };

  const handleToggleSubscription = async () => {
      await updateUser({ isSubscribed: !user.isSubscribed });
  };

  const handleEditAddress = (addr: any) => {
      setNewAddress({
          firstName: addr.firstName,
          lastName: addr.lastName,
          street: addr.street,
          city: addr.city,
          state: addr.state || '',
          zip: addr.zip,
          country: addr.country
      });
      setEditingAddressId(addr.id);
      setShowAddressForm(true);
  };

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    let updatedAddresses = user.addresses || [];
    
    if (editingAddressId) {
        // Update existing
        updatedAddresses = updatedAddresses.map(a => 
            a.id === editingAddressId ? { ...a, ...newAddress } : a
        );
    } else {
        // Add new
        const address = {
            id: Date.now().toString(),
            type: 'Shipping' as const,
            ...newAddress
        };
        updatedAddresses = [...updatedAddresses, address];
    }

    await updateUser({ addresses: updatedAddresses });
    setShowAddressForm(false);
    setEditingAddressId(null);
    setNewAddress({ firstName: '', lastName: '', street: '', city: '', state: '', zip: '', country: 'United States' });
  };

  const handleDeleteAddress = async (id: string) => {
      if(window.confirm('Are you sure you want to remove this location?')) {
          const updatedAddresses = user.addresses?.filter(a => a.id !== id) || [];
          await updateUser({ addresses: updatedAddresses });
      }
  };

  const getStatusIcon = (status: string) => {
      switch(status) {
          case 'Delivered': return <CheckCircle size={14} />;
          case 'Processing': return <Clock size={14} />;
          case 'Shipped': return <Truck size={14} />;
          case 'Cancelled': return <XCircle size={14} />;
          default: return <Clock size={14} />;
      }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Delivered': return 'bg-green-100 text-green-800';
      case 'Processing': return 'bg-blue-100 text-blue-800';
      case 'Shipped': return 'bg-purple-100 text-purple-800';
      case 'Cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-stone-100 text-stone-600';
    }
  };

  return (
    <div className="pt-32 pb-24 px-6 max-w-6xl mx-auto min-h-screen animate-fade-in bg-brand-cream text-brand-black">
      <AnimatePresence>
          {trackingOrder && <TrackingModal order={trackingOrder} onClose={() => setTrackingOrder(null)} />}
      </AnimatePresence>

      <div className="flex flex-col md:flex-row gap-8">
        
        {/* Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
            <div className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm text-center mb-6">
                <div className="w-20 h-20 bg-stone-100 rounded-full mx-auto mb-4 overflow-hidden border border-stone-200">
                    {user.photoURL ? (
                        <img src={user.photoURL} alt={user.name} className="w-full h-full object-cover" />
                    ) : (
                        <div className="w-full h-full flex items-center justify-center text-2xl font-serif text-stone-400 font-bold">
                            {user.name.charAt(0)}
                        </div>
                    )}
                </div>
                <h2 className="font-bold text-lg text-brand-black">{user.name}</h2>
                <p className="text-xs text-stone-500 mb-4">{user.email}</p>
                
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-stone-50 rounded-full border border-stone-100">
                    <span className="text-lg">{userFlag}</span>
                    <span className="text-[10px] font-black uppercase tracking-widest text-stone-500">{user.region || 'Global'}</span>
                </div>

                <div className="mt-4 pt-4 border-t border-stone-100 text-left">
                     <p className="text-[10px] uppercase font-bold text-stone-400 tracking-widest">Member Since</p>
                     <p className="text-xs font-medium">{user.joinDate}</p>
                </div>
            </div>

            <nav className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
                <button 
                    onClick={() => setActiveTab('profile')} 
                    className={`w-full text-left px-6 py-4 flex items-center gap-3 text-sm font-bold transition-colors ${activeTab === 'profile' ? 'bg-brand-black text-white' : 'text-stone-500 hover:bg-stone-50'}`}
                >
                    <User size={18} /> Profile
                </button>
                <button 
                    onClick={() => setActiveTab('orders')} 
                    className={`w-full text-left px-6 py-4 flex items-center gap-3 text-sm font-bold transition-colors ${activeTab === 'orders' ? 'bg-brand-black text-white' : 'text-stone-500 hover:bg-stone-50'}`}
                >
                    <Package size={18} /> My Orders
                </button>
                <button 
                    onClick={() => setActiveTab('addresses')} 
                    className={`w-full text-left px-6 py-4 flex items-center gap-3 text-sm font-bold transition-colors ${activeTab === 'addresses' ? 'bg-brand-black text-white' : 'text-stone-500 hover:bg-stone-50'}`}
                >
                    <MapPin size={18} /> Addresses
                </button>
                <button 
                    onClick={handleLogout} 
                    className="w-full text-left px-6 py-4 flex items-center gap-3 text-sm font-bold text-red-500 hover:bg-red-50 transition-colors border-t border-stone-100"
                >
                    <LogOut size={18} /> Sign Out
                </button>
            </nav>
        </div>

        {/* Content Area */}
        <div className="flex-1">
            
            {/* PROFILE TAB */}
            {activeTab === 'profile' && (
              <div className="space-y-6 animate-fade-in">
                 <h2 className="font-serif text-2xl text-brand-black mb-6">Account Details</h2>
                 <div className="bg-white p-8 rounded-xl border border-stone-200 shadow-sm">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-xs font-bold uppercase text-stone-500 mb-2">Full Name</label>
                            <input disabled value={user.name} className="w-full bg-stone-50 border border-stone-200 p-3 rounded-lg text-sm text-stone-600" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold uppercase text-stone-500 mb-2">Email</label>
                            <input disabled value={user.email} className="w-full bg-stone-50 border border-stone-200 p-3 rounded-lg text-sm text-stone-600" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold uppercase text-stone-500 mb-2">Shopping Region</label>
                            <div className="flex items-center gap-3 w-full bg-stone-50 border border-stone-200 p-3 rounded-lg text-sm text-brand-black">
                                <span className="text-xl">{userFlag}</span>
                                <span className="font-bold">{user.region}</span>
                            </div>
                        </div>
                    </div>
                 </div>

                 {/* Newsletter Preference Card */}
                 <div className="bg-white/80 backdrop-blur-xl p-8 rounded-xl border border-white/50 shadow-sm relative overflow-hidden">
                     <div className="absolute top-0 right-0 p-6 opacity-10">
                         <Mail size={120} />
                     </div>
                     <div className="relative z-10">
                         <h3 className="font-serif text-xl text-brand-black mb-2 flex items-center gap-2">
                             Newsletter Preferences
                         </h3>
                         <p className="text-stone-500 text-sm mb-6 max-w-md">
                             Manage your subscription to our exclusive newsletter. Subscribers receive early access to new drops and a 15% discount on eligible orders.
                         </p>
                         
                         <div className="flex items-center gap-4">
                             <div className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest border ${user.isSubscribed ? 'bg-green-50 text-green-700 border-green-100' : 'bg-stone-50 text-stone-500 border-stone-200'}`}>
                                 Status: {user.isSubscribed ? 'Subscribed' : 'Not Subscribed'}
                             </div>
                             
                             <button 
                                onClick={handleToggleSubscription}
                                className={`px-6 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-colors shadow-sm ${
                                    user.isSubscribed 
                                    ? 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-50 hover:text-red-500' 
                                    : 'bg-brand-black text-white hover:bg-stone-800'
                                }`}
                             >
                                 {user.isSubscribed ? 'Unsubscribe' : 'Subscribe Now'}
                             </button>
                         </div>
                         {user.isSubscribed && (
                             <p className="text-[10px] text-green-600 mt-3 font-medium flex items-center gap-1">
                                 <CheckCircle size={12} /> 15% OFF Discount Active
                             </p>
                         )}
                     </div>
                 </div>
              </div>
            )}

            {/* ORDERS TAB */}
            {activeTab === 'orders' && (
              <div className="space-y-6 animate-fade-in">
                <h2 className="font-serif text-2xl text-brand-black mb-6">Order History</h2>
                {myOrders.length === 0 ? (
                    <div className="bg-white p-12 text-center rounded-xl border border-stone-200 shadow-sm">
                        <Package size={48} className="mx-auto text-stone-300 mb-4" />
                        <p className="text-stone-500 font-serif text-lg">You haven't placed any orders yet.</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {myOrders.map(order => (
                            <div key={order.id} className="bg-white border border-stone-200 rounded-xl overflow-hidden shadow-sm">
                                <div className="p-6 border-b border-stone-100 flex flex-wrap gap-4 justify-between items-center bg-stone-50/50">
                                    <div>
                                        <p className="text-xs font-bold uppercase text-stone-400 tracking-wider">Order Placed</p>
                                        <p className="font-bold text-brand-black text-sm">{order.date}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs font-bold uppercase text-stone-400 tracking-wider">Total</p>
                                        <p className="font-bold text-brand-black text-sm">{formatPrice(order.total)}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs font-bold uppercase text-stone-400 tracking-wider">Order #</p>
                                        <p className="font-bold text-brand-black text-sm font-mono">{order.id}</p>
                                    </div>
                                    <div className="flex gap-4 items-center">
                                         <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase ${getStatusColor(order.status)}`}>
                                            {getStatusIcon(order.status)} {order.status}
                                         </span>
                                         <button 
                                            onClick={() => setTrackingOrder(order)}
                                            className="bg-brand-black text-white px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-brand-crimson transition-all flex items-center gap-2"
                                         >
                                             Track Package <ArrowRight size={10} />
                                         </button>
                                    </div>
                                </div>
                                <div className="p-6">
                                    <div className="space-y-4">
                                        {order.items.map((item, idx) => (
                                            <div key={idx} className="flex gap-4 items-center">
                                                <div className="w-16 h-16 bg-white border border-stone-200 rounded-lg overflow-hidden flex-shrink-0 p-1 flex items-center justify-center">
                                                    <img src={item.images[0]} alt={item.name} className="w-full h-full object-contain" />
                                                </div>
                                                <div className="flex-1">
                                                    <h4 className="font-serif font-bold text-brand-black">{item.name}</h4>
                                                    <p className="text-xs text-stone-500">{item.size} • Qty: {item.quantity}</p>
                                                </div>
                                                <p className="text-sm font-bold text-brand-black">{formatPrice(item.price)}</p>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
              </div>
            )}

            {/* ADDRESSES TAB */}
            {activeTab === 'addresses' && (
              <div className="space-y-6 animate-fade-in">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="font-serif text-2xl text-brand-black">Address Book</h2>
                    <button 
                        onClick={() => { setShowAddressForm(!showAddressForm); setEditingAddressId(null); setNewAddress({ firstName: '', lastName: '', street: '', city: '', state: '', zip: '', country: 'United States' }); }} 
                        className="flex items-center gap-2 bg-brand-black text-white px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-brand-crimson transition-colors"
                    >
                        <Plus size={14} /> Add Address
                    </button>
                </div>

                {showAddressForm && (
                    <div className="bg-white p-6 rounded-xl border border-stone-200 mb-6 animate-slide-up shadow-sm">
                        <h3 className="font-bold text-brand-black mb-4">{editingAddressId ? 'Edit Address' : 'New Address'}</h3>
                        <form onSubmit={handleSaveAddress} className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <input required placeholder="First Name" value={newAddress.firstName} onChange={e => setNewAddress({...newAddress, firstName: e.target.value})} className="border border-stone-200 p-3 rounded-lg text-sm w-full text-brand-black bg-white outline-none focus:border-brand-black" />
                                <input required placeholder="Last Name" value={newAddress.lastName} onChange={e => setNewAddress({...newAddress, lastName: e.target.value})} className="border border-stone-200 p-3 rounded-lg text-sm w-full text-brand-black bg-white outline-none focus:border-brand-black" />
                            </div>
                            <input required placeholder="Street Address" value={newAddress.street} onChange={e => setNewAddress({...newAddress, street: e.target.value})} className="border border-stone-200 p-3 rounded-lg text-sm w-full text-brand-black bg-white outline-none focus:border-brand-black" />
                            <div className="grid grid-cols-3 gap-4">
                                <input required placeholder="City" value={newAddress.city} onChange={e => setNewAddress({...newAddress, city: e.target.value})} className="border border-stone-200 p-3 rounded-lg text-sm w-full text-brand-black bg-white outline-none focus:border-brand-black" />
                                <input required placeholder="State" value={newAddress.state} onChange={e => setNewAddress({...newAddress, state: e.target.value})} className="border border-stone-200 p-3 rounded-lg text-sm w-full text-brand-black bg-white outline-none focus:border-brand-black" />
                                <input required placeholder="ZIP Code" value={newAddress.zip} onChange={e => setNewAddress({...newAddress, zip: e.target.value})} className="border border-stone-200 p-3 rounded-lg text-sm w-full text-brand-black bg-white outline-none focus:border-brand-black" />
                            </div>
                            <div className="flex gap-3 pt-2">
                                <button type="submit" className="bg-brand-black text-white px-6 py-2 rounded-lg text-xs font-bold uppercase hover:bg-stone-800 transition-colors">Save Address</button>
                                <button type="button" onClick={() => setShowAddressForm(false)} className="text-stone-500 px-6 py-2 text-xs font-bold uppercase hover:text-brand-black border border-stone-200 rounded-lg hover:bg-stone-50 transition-colors">Cancel</button>
                            </div>
                        </form>
                    </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {user.addresses && user.addresses.length > 0 ? user.addresses.map(addr => (
                        <div key={addr.id} className="bg-white p-6 border border-stone-200 rounded-xl relative group hover:shadow-md transition-shadow">
                            {addr.isDefault && (
                                <span className="absolute top-6 right-6 bg-stone-100 text-stone-600 text-[10px] px-2 py-1 uppercase font-bold tracking-widest rounded">Default</span>
                            )}
                            <h4 className="font-bold text-brand-black mb-1">{addr.firstName} {addr.lastName}</h4>
                            <p className="text-sm text-stone-600">{addr.street}</p>
                            <p className="text-sm text-stone-600">{addr.city}, {addr.state} {addr.zip}</p>
                            <p className="text-sm text-stone-600">{addr.country}</p>
                            
                            <div className="mt-4 pt-4 border-t border-stone-100 flex justify-between items-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => handleEditAddress(addr)} className="text-xs font-bold text-brand-black hover:underline flex items-center gap-1"><Edit2 size={12}/> Edit</button>
                                <button onClick={() => handleDeleteAddress(addr.id)} className="text-stone-400 hover:text-red-500 transition-colors">
                                    <Trash2 size={16} />
                                </button>
                            </div>
                        </div>
                    )) : (
                        <div className="col-span-full text-center py-12 text-stone-400 border-2 border-dashed border-stone-200 rounded-xl">
                            <MapPin size={32} className="mx-auto mb-2 opacity-50" />
                            <p>No addresses saved yet.</p>
                        </div>
                    )}
                </div>
              </div>
            )}

        </div>
      </div>
    </div>
  );
};
