
import React, { useState, useEffect, useMemo } from 'react';
// @ts-ignore
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import { 
  Heart, Wind, Flame, Waves, Plus, ArrowRight, ShieldCheck, 
  ChevronRight, Clock, Activity, Wand2, 
  RotateCcw, Zap, ChevronLeft, Sparkles, AlertTriangle, Star, MessageSquare, Check, User
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { QuantitySelector } from '../components/QuantitySelector';
import { Toast } from '../components/Toast';
import { ProductCard } from '../components/ProductCard';
import { GoogleGenAI } from "@google/genai";
import { Review } from '../types';
import { api } from '../services/api';

interface PerformanceData {
    projection: number;
    longevity: number;
    sillage: number;
    insight: string;
}

const PerformanceProfile = ({ product }: { product: any }) => {
    const { storeSettings } = useShop();
    const [analysis, setAnalysis] = useState<PerformanceData | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPerformance = async () => {
            setLoading(true);
            try {
                // Use Admin configured Key or fallback to env
                const activeKey = storeSettings.geminiApiKey || process.env.API_KEY;

                if (!activeKey) throw new Error("No API Key Configured");

                const ai = new GoogleGenAI({ apiKey: activeKey });
                const notes = `Top: ${product.notes.top.join(', ')}. Heart: ${product.notes.heart.join(', ')}. Base: ${product.notes.base.join(', ')}.`;
                
                const prompt = `Analyze the performance of a perfume with these notes: ${notes}. 
                Return a valid JSON object only with these keys:
                1. projection (integer 0-100)
                2. longevity (integer 0-100)
                3. sillage (integer 0-100)
                4. insight (A single 15-20 word simple explanation).
                No other text.`;

                const response = await ai.models.generateContent({
                    model: 'gemini-3-flash-preview',
                    contents: prompt,
                    config: { responseMimeType: "application/json" }
                });

                const data = JSON.parse(response.text || '{}');
                setAnalysis({
                    projection: data.projection || 75,
                    longevity: data.longevity || 80,
                    sillage: data.sillage || 70,
                    insight: data.insight || "A beautifully balanced scent designed to stay with you throughout the entire day."
                });
            } catch (error) {
                // Fallback mock data if API fails or key is missing
                setAnalysis({
                    projection: 70,
                    longevity: 85,
                    sillage: 75,
                    insight: "This fragrance features a robust profile with excellent longevity on the skin."
                });
            } finally {
                setLoading(false);
            }
        };

        fetchPerformance();
    }, [product, storeSettings.geminiApiKey]);

    return (
        <div className="p-5 bg-brand-black text-white rounded-[1.5rem] shadow-xl space-y-5 relative overflow-hidden group h-full flex flex-col justify-center">
            <div className="flex justify-between items-center relative z-10">
                <h4 className="text-[7px] font-black uppercase tracking-[0.3em] text-brand-gold flex items-center gap-2">
                    Scent Guide
                </h4>
                {loading && (
                    <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity, ease: "linear" }}>
                        <RotateCcw size={10} className="text-brand-gold opacity-50" />
                    </motion.div>
                )}
            </div>

            <div className="space-y-3 relative z-10">
                {[
                    { label: 'Longevity', value: analysis?.longevity, icon: Clock },
                    { label: 'Sillage', value: analysis?.sillage, icon: Waves },
                    { label: 'Projection', value: analysis?.projection, icon: Zap }
                ].map((stat, i) => (
                    <div key={stat.label}>
                        <div className="flex justify-between items-end text-[7px] font-black uppercase tracking-widest mb-1">
                            <span className="text-stone-400 flex items-center gap-1.5">
                                {stat.label}
                            </span>
                            <span className="text-brand-gold font-mono text-[9px]">{loading ? '--' : `${stat.value}%`}</span>
                        </div>
                        <div className="h-0.5 bg-white/5 rounded-full overflow-hidden">
                            <motion.div 
                                initial={{ width: 0 }} 
                                animate={{ width: loading ? '10%' : `${stat.value}%` }} 
                                transition={{ duration: 1.5, delay: i * 0.2 }} 
                                className="h-full bg-gradient-to-r from-brand-crimson to-brand-gold" 
                            />
                        </div>
                    </div>
                ))}
            </div>

            <AnimatePresence mode="wait">
                {!loading && analysis && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white/[0.03] p-3 rounded-xl border border-white/5 backdrop-blur-sm">
                        <p className="text-[8px] font-serif italic text-stone-300 leading-relaxed text-center">"{analysis.insight}"</p>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { products, addToCart, addToWishlist, removeFromWishlist, isInWishlist, cart, addReview } = useShop();
  const { formatPrice } = useCurrency();
  const { user } = useAuth();
  
  const [selectedSize, setSelectedSize] = useState('100ml');
  const [selectedConcentration, setSelectedConcentration] = useState('Eau de Parfum');
  const [quantity, setQuantity] = useState(1);
  const [toastMessage, setToastMessage] = useState('');
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  // Review State
  const [rating, setRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);
  const [localReviews, setLocalReviews] = useState<Review[]>([]);

  const product = useMemo(() => products.find(p => p.id === id), [id, products]);
  
  // Fetch reviews specifically for this product
  useEffect(() => {
      if (id) {
          api.getProductReviews(id).then(data => setLocalReviews(data));
      }
  }, [id]);

  const averageRating = useMemo(() => {
      if (localReviews.length === 0) return product?.rating || 0;
      const total = localReviews.reduce((acc, r) => acc + r.rating, 0);
      return (total / localReviews.length).toFixed(1);
  }, [localReviews, product]);

  const concentrations = ["Eau de Parfum", "Parfum", "Extrait"];

  // DYNAMIC PRICING LOGIC
  const { displayPrice, displayCompareAt, availableSizes } = useMemo(() => {
    if (!product) return { displayPrice: 0, displayCompareAt: undefined, availableSizes: [] };

    let price = product.price;
    let compareAt = product.compareAtPrice;
    
    if (product.variants && product.variants.length > 0) {
        const variant = product.variants.find(v => v.size === selectedSize);
        if (variant) {
            price = variant.price;
            compareAt = variant.compareAtPrice;
        }
    } else {
        if (selectedSize === '30ml') price *= 0.6;
        if (selectedSize === '50ml') price *= 0.8;
        if (selectedSize === '200ml') price *= 1.7;
    }

    if (selectedConcentration === 'Parfum') price += 40;
    if (selectedConcentration === 'Extrait') price += 85;

    const sizes = (product.variants && product.variants.length > 0) 
        ? product.variants.map(v => v.size) 
        : (product.sizes || ['30ml', '50ml', '100ml']);

    return { 
        displayPrice: Math.round(price), 
        displayCompareAt: compareAt,
        availableSizes: sizes
    };
  }, [product, selectedSize, selectedConcentration]);

  const relatedCreations = useMemo(() => {
    return products
      .filter(p => p.id !== id && (p.category === product?.category))
      .sort(() => Math.random() - 0.5)
      .slice(0, 3);
  }, [id, products, product]);

  const suggestions = useMemo(() => {
    return products
      .filter(p => p.id !== id)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3);
  }, [id, products]);

  useEffect(() => { 
      window.scrollTo({ top: 0, behavior: 'smooth' }); 
      if (product) {
          const firstSize = (product.variants && product.variants.length > 0) 
              ? product.variants[0].size 
              : (product.sizes?.[0] || product.size || '100ml');
          setSelectedSize(firstSize);
          setActiveImageIndex(0);
          setReviewSubmitted(false);
          setReviewComment('');
          setRating(5);
      }
  }, [id, product]);

  if (!product) return null;

  const isWishlisted = isInWishlist(product.id);
  const currentStock = product.stock || 0;
  const isOutOfStock = currentStock <= 0;
  const isLowStock = currentStock < 10 && currentStock > 0;

  const handleAddToCart = () => {
    if (isOutOfStock) {
        setToastMessage("Sorry, this item is currently out of stock.");
        return;
    }
    
    const cartVariantId = `${product.id}-${selectedSize}`; 
    const existingInCart = cart.find(i => i.cartItemId === cartVariantId)?.quantity || 0;
    const totalRequested = existingInCart + quantity;

    if (totalRequested > currentStock) {
        const remaining = Math.max(0, currentStock - existingInCart);
        if (remaining === 0) {
            setToastMessage(`You already have all ${currentStock} available units in your bag.`);
        } else {
            setToastMessage(`Stock limited. You have ${existingInCart} in bag. Only ${remaining} more available.`);
        }
        return;
    }

    const variantProduct = { ...product, price: displayPrice, size: `${selectedSize} - ${selectedConcentration}` };
    addToCart(variantProduct, quantity, true);
    setToastMessage(`${product.name} (${selectedSize}) added to bag.`);
  };

  const handleSubmitReview = (e: React.FormEvent) => {
      e.preventDefault();
      if (!user) {
          navigate('/login', { state: { from: `/product/${id}` } });
          return;
      }
      if (reviewComment.trim()) {
          const newReview: Review = {
              id: Date.now().toString(),
              productId: product.id,
              productName: product.name,
              userName: user.name || 'Anonymous',
              rating: rating,
              comment: reviewComment,
              status: 'pending',
              date: new Date().toLocaleDateString()
          };
          addReview(newReview);
          setReviewSubmitted(true);
      }
  };

  const nextImage = () => {
    setDirection(1);
    setActiveImageIndex((prev) => (prev + 1) % product.images.length);
  };

  const prevImage = () => {
    setDirection(-1);
    setActiveImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
  };

  const carouselVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
      scale: 0.95
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0,
      scale: 0.95
    })
  };

  return (
    <div className="pt-24 pb-20 px-6 lg:px-12 min-h-screen bg-brand-cream text-brand-black animate-fade-in font-sans">
      <Toast message={toastMessage} onClose={() => setToastMessage('')} />
      
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-2 text-[7px] font-black uppercase tracking-[0.4em] text-stone-400 mb-6">
            <Link to="/" className="hover:text-brand-black transition-colors">Home</Link>
            <ChevronRight size={8} className="text-brand-crimson" />
            <Link to="/shop" className="hover:text-brand-black transition-colors">Shop</Link>
            <ChevronRight size={8} className="text-brand-crimson" />
            <span className="text-brand-black">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 lg:gap-16 items-start">
          {/* Visuals */}
          <div className="space-y-6">
              <div className="flex flex-col gap-6">
                  <div className="aspect-[4/5] bg-white rounded-[2rem] border border-stone-100 shadow-xl flex items-center justify-center relative group overflow-hidden">
                    <AnimatePresence initial={false} custom={direction} mode="wait">
                      <motion.div
                        key={activeImageIndex}
                        custom={direction}
                        variants={carouselVariants}
                        initial="enter"
                        animate="center"
                        exit="exit"
                        transition={{ x: { type: "spring", stiffness: 300, damping: 32 }, opacity: { duration: 0.4 }, scale: { duration: 0.4 } }}
                        className="w-full h-full flex items-center justify-center"
                      >
                         <img src={product.images[activeImageIndex]} alt={product.name} className="w-full h-full object-contain p-12 drop-shadow-xl" />
                      </motion.div>
                    </AnimatePresence>

                    {product.images.length > 1 && (
                      <div className="absolute inset-x-4 top-1/2 -translate-y-1/2 flex justify-between z-20 pointer-events-none">
                        <button onClick={prevImage} className="w-10 h-10 rounded-full bg-white/40 backdrop-blur-xl border border-white/20 text-brand-black flex items-center justify-center pointer-events-auto hover:bg-white hover:scale-110 transition-all shadow-md"><ChevronLeft size={18} /></button>
                        <button onClick={nextImage} className="w-10 h-10 rounded-full bg-white/40 backdrop-blur-xl border border-white/20 text-brand-black flex items-center justify-center pointer-events-auto hover:bg-white hover:scale-110 transition-all shadow-md"><ChevronRight size={18} /></button>
                      </div>
                    )}

                    <button onClick={() => isWishlisted ? removeFromWishlist(product.id) : addToWishlist(product)} className={`absolute top-5 right-5 p-3 rounded-full shadow-md transition-all duration-500 z-20 ${isWishlisted ? 'bg-brand-crimson text-white scale-110' : 'bg-white/80 text-stone-300 hover:text-brand-black opacity-0 group-hover:opacity-100'}`}>
                        <Heart size={16} className={isWishlisted ? "fill-current" : ""} />
                    </button>
                  </div>

                  {product.images.length > 1 && (
                    <div className="flex gap-3 overflow-x-auto pb-2 custom-scrollbar justify-center">
                        {product.images.map((img, idx) => (
                            <button key={idx} onClick={() => { setDirection(idx > activeImageIndex ? 1 : -1); setActiveImageIndex(idx); }} className={`w-16 h-20 rounded-xl border-2 transition-all p-1 shrink-0 bg-white shadow-sm hover:shadow-md ${activeImageIndex === idx ? 'border-brand-black scale-105' : 'border-stone-100 opacity-60 hover:opacity-100'}`}>
                                <img src={img} className="w-full h-full object-contain" alt="" />
                            </button>
                        ))}
                    </div>
                  )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <PerformanceProfile product={product} />
                  <div className="p-6 bg-white rounded-[1.5rem] border border-stone-100 shadow-sm flex flex-col justify-center gap-5">
                      {[
                        { label: 'Quality', value: 'Natural Extracts', icon: ShieldCheck, color: 'text-brand-crimson', bg: 'bg-brand-crimson/5' },
                        { label: 'Aging', value: '180 Day Process', icon: Clock, color: 'text-brand-gold', bg: 'bg-brand-gold/5' },
                        { label: 'Refillable', value: 'Sustainable Bottle', icon: RotateCcw, color: 'text-stone-400', bg: 'bg-stone-50' }
                      ].map((item) => (
                        <div key={item.label} className="flex items-center gap-3">
                            <div className={`w-8 h-8 ${item.bg} ${item.color} rounded-lg flex items-center justify-center shrink-0 border border-stone-50`}><item.icon size={16} /></div>
                            <div>
                                <p className="text-[7px] font-black uppercase text-stone-400 tracking-widest leading-none mb-1">{item.label}</p>
                                <p className="text-[10px] font-bold leading-none">{item.value}</p>
                            </div>
                        </div>
                      ))}
                  </div>
              </div>
          </div>

          {/* Details */}
          <div className="space-y-10">
             <div className="space-y-4">
                <div className="flex items-center gap-3 flex-wrap">
                  <span className="text-brand-crimson font-black uppercase tracking-[0.5em] text-[8px] block">{product.category}</span>
                  <div className="w-1 h-1 rounded-full bg-stone-300" />
                  <span className="text-brand-gold font-black uppercase tracking-[0.5em] text-[8px] block flex items-center gap-1"><Sparkles size={8}/> Rare Extract</span>
                  {/* DISPLAY ADMIN TAGS */}
                  {product.tags && product.tags.length > 0 && product.tags.map(tag => (
                      <React.Fragment key={tag}>
                          <div className="w-1 h-1 rounded-full bg-stone-300" />
                          <span className="text-stone-500 font-black uppercase tracking-[0.5em] text-[8px] block">{tag}</span>
                      </React.Fragment>
                  ))}
                </div>
                <h1 className="font-serif text-3xl lg:text-4xl italic text-brand-black tracking-tight leading-tight">{product.name}</h1>
                <div className="flex flex-col gap-2 pt-2">
                    <div className="flex items-baseline gap-4">
                        <motion.p key={displayPrice} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-2xl font-serif font-bold text-brand-black">{formatPrice(displayPrice)}</motion.p>
                        {displayCompareAt && displayCompareAt > displayPrice && (
                            <span className="text-base text-stone-400 line-through font-serif decoration-brand-crimson decoration-2">
                                {formatPrice(displayCompareAt)}
                            </span>
                        )}
                        <p className="text-[7px] text-stone-400 font-black uppercase tracking-widest italic border-l border-stone-200 pl-4">Global Shipping Included</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="flex text-brand-gold">
                            {[...Array(5)].map((_, i) => (
                                <Star key={i} size={12} className={i < Math.floor(Number(averageRating)) ? "fill-current" : "text-stone-200"} />
                            ))}
                        </div>
                        <span className="text-xs font-bold text-stone-500">({localReviews.length} reviews)</span>
                    </div>
                    {isLowStock && (
                        <div className="inline-flex items-center gap-2 text-brand-crimson text-[10px] font-bold bg-brand-crimson/5 px-3 py-1 rounded-lg w-fit mt-1 border border-brand-crimson/10 animate-pulse">
                            <AlertTriangle size={12} /> Only {currentStock} units left
                        </div>
                    )}
                </div>
             </div>
             <p className="text-stone-500 text-base font-serif italic leading-relaxed opacity-80">"{product.description}"</p>

             <div className="space-y-3">
                <label className="block text-[8px] font-black uppercase tracking-[0.4em] text-stone-400">Select Concentration</label>
                <div className="flex flex-wrap gap-2">
                   {concentrations.map(conc => (
                      <button key={conc} onClick={() => setSelectedConcentration(conc)} className={`px-6 py-3 rounded-xl text-[8px] font-black uppercase tracking-widest border transition-all ${selectedConcentration === conc ? 'bg-brand-black text-white border-brand-black shadow-md' : 'bg-white border-stone-100 text-stone-400 hover:border-brand-black'}`}>{conc}</button>
                   ))}
                </div>
             </div>

             <div className="space-y-3">
                <label className="block text-[8px] font-black uppercase tracking-[0.4em] text-stone-400">Select Size</label>
                <div className="flex flex-wrap gap-2">
                   {availableSizes.map(size => (
                      <button key={size} onClick={() => setSelectedSize(size)} className={`px-6 py-3 rounded-xl text-[8px] font-black uppercase tracking-widest border transition-all ${selectedSize === size ? 'bg-brand-black text-white border-brand-black shadow-md' : 'bg-white border-stone-100 text-stone-400 hover:border-brand-black'}`}>{size}</button>
                   ))}
                </div>
             </div>

             <div className="flex gap-4 pt-6 border-t border-stone-100">
                <QuantitySelector 
                    quantity={quantity} 
                    onDecrease={() => setQuantity(Math.max(1, quantity - 1))} 
                    onIncrease={() => {
                        if (quantity < currentStock) setQuantity(quantity + 1);
                        else setToastMessage(`Not available. Only ${currentStock} left.`);
                    }} 
                    size="md"
                    max={currentStock}
                />
                <button onClick={handleAddToCart} disabled={isOutOfStock} className="flex-1 h-12 bg-brand-black text-white rounded-full font-black uppercase text-[10px] tracking-[0.3em] hover:bg-brand-crimson transition-all shadow-lg flex items-center justify-center gap-3 active:scale-95 group overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed">
                   {isOutOfStock ? 'Sold Out' : <><Plus size={14} className="group-hover:rotate-90 transition-transform" /> <span>Add to Bag</span></>}
                </button>
             </div>

             <div className="p-6 bg-brand-paper rounded-[2rem] border border-white shadow-inner">
                 <h4 className="text-[8px] font-black uppercase tracking-[0.4em] text-brand-black text-center flex items-center justify-center gap-3 mb-4">Try Layering With</h4>
                 <div className="grid grid-cols-3 gap-3">
                    {suggestions.map(s => (
                        <Link to={`/product/${s.id}`} key={s.id} className="group text-center">
                            <div className="aspect-[4/5] bg-white rounded-xl p-2 mb-2 border border-stone-100 group-hover:scale-105 transition-all flex items-center justify-center overflow-hidden shadow-sm group-hover:shadow-md">
                                <img src={s.images[0]} className="w-full h-full object-contain" alt="" />
                            </div>
                            <span className="text-[6px] font-black uppercase tracking-widest text-stone-500 block truncate">{s.name}</span>
                        </Link>
                    ))}
                 </div>
             </div>
          </div>
        </div>

        {/* BEST-IN-CLASS VISUAL OLFACTORY PYRAMID */}
        <div className="mt-24 pt-16 border-t border-stone-200">
            <div className="text-center mb-16 max-w-xl mx-auto">
                <span className="text-[9px] font-black uppercase tracking-[0.6em] text-brand-gold block mb-3">Scent Architecture</span>
                <h3 className="font-serif text-3xl md:text-4xl text-brand-black italic tracking-tight">Olfactory Composition</h3>
                <p className="text-stone-400 text-base font-serif italic mt-4 opacity-80">"Witness the transformation of botanical extracts as they touch your skin and breathe with time."</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-6 max-w-5xl mx-auto">
                {[
                  { 
                    title: 'Top Notes', 
                    phase: 'Opening', 
                    duration: '0 - 15 Minutes',
                    desc: 'The immediate impression. Volatile citrus and fresh molecules designed to introduce the story.',
                    icon: Wind, 
                    color: 'text-blue-400', 
                    bg: 'bg-blue-50/50', 
                    notes: product.notes.top 
                  },
                  { 
                    title: 'Heart Notes', 
                    phase: 'Evolution', 
                    duration: '15 Min - 4 Hours',
                    desc: 'The soul of the fragrance. Rich florals and spices that define the character and sillage.',
                    icon: Waves, 
                    color: 'text-brand-crimson', 
                    bg: 'bg-brand-crimson/5', 
                    notes: product.notes.heart 
                  },
                  { 
                    title: 'Base Notes', 
                    phase: 'Foundation', 
                    duration: '4 - 12+ Hours',
                    desc: 'The lingering memory. Deep resins, woods, and musks that provide persistence and depth.',
                    icon: Flame, 
                    color: 'text-brand-gold', 
                    bg: 'bg-stone-900', 
                    notes: product.notes.base 
                  }
                ].map((tier, idx) => (
                    <motion.div 
                        key={tier.title} 
                        initial={{ opacity: 0, y: 20 }} 
                        whileInView={{ opacity: 1, y: 0 }} 
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.15 }}
                        className="group flex flex-col items-center text-center gap-5 p-6 lg:p-8 bg-white rounded-[2rem] border border-stone-100 shadow-sm hover:shadow-xl transition-all duration-700 relative overflow-hidden"
                    >
                        <div className={`absolute top-0 inset-x-0 h-24 ${tier.bg} opacity-50 rounded-t-[2rem]`} />
                        
                        <div className={`w-16 h-16 bg-white rounded-[1.5rem] flex items-center justify-center shrink-0 border border-stone-100 group-hover:scale-110 transition-transform duration-500 shadow-sm relative z-10`}>
                            <tier.icon size={24} strokeWidth={1.5} className={tier.color} />
                        </div>
                        
                        <div className="relative z-10 flex flex-col items-center flex-1 w-full">
                            <span className={`text-[7px] font-black uppercase tracking-[0.3em] mb-1 ${tier.color} opacity-80`}>{tier.phase}</span>
                            <h4 className="font-serif text-xl lg:text-2xl text-brand-black italic mb-2">{tier.title}</h4>
                            <p className="text-[8px] font-black uppercase tracking-widest text-stone-400 mb-4 border-b border-stone-100 pb-3 w-full">{tier.duration}</p>
                            
                            <p className="text-stone-500 text-[10px] font-serif italic mb-4 leading-relaxed opacity-80 min-h-[30px]">{tier.desc}</p>
                            
                            <div className="flex flex-wrap justify-center gap-1.5 w-full mt-auto">
                                {/* STRICT LIMIT: Only show first 3 notes */}
                                {tier.notes.slice(0, 3).map((note: string) => (
                                    <span key={note} className="px-2.5 py-1.5 bg-stone-50 text-brand-black rounded-lg text-[8px] font-bold uppercase tracking-wider border border-stone-100 shadow-sm w-full">
                                        {note}
                                    </span>
                                ))}
                                {tier.notes.length > 3 && (
                                    <span className="text-[7px] text-stone-400 italic mt-1">
                                        +{tier.notes.length - 3} more
                                    </span>
                                )}
                            </div>
                        </div>
                    </motion.div>
                ))}
            </div>
        </div>

        {/* REVIEW SYSTEM */}
        <div className="mt-32 pt-16 border-t border-stone-200">
            <h3 className="font-serif text-3xl text-brand-black italic mb-10 text-center">Olfactory Impressions</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                {/* Review List */}
                <div className="space-y-6">
                    {localReviews.length === 0 ? (
                        <div className="text-center py-10 bg-white rounded-2xl border border-dashed border-stone-200">
                            <MessageSquare className="mx-auto text-stone-300 mb-2" />
                            <p className="text-stone-500 italic">No reviews yet. Be the first to share your experience.</p>
                        </div>
                    ) : (
                        localReviews.map(review => (
                            <div key={review.id} className="p-6 bg-white rounded-2xl border border-stone-100 shadow-sm">
                                <div className="flex justify-between items-start mb-2">
                                    <div className="flex items-center gap-2">
                                        <div className="w-8 h-8 rounded-full bg-brand-black text-brand-gold flex items-center justify-center font-bold text-xs">
                                            {review.userName.charAt(0)}
                                        </div>
                                        <div>
                                            <p className="text-xs font-bold text-brand-black">{review.userName}</p>
                                            <p className="text-[9px] text-stone-400">{review.date}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-0.5 text-brand-gold">
                                        {[...Array(5)].map((_, i) => (
                                            <Star key={i} size={10} className={i < review.rating ? "fill-current" : "text-stone-200"} />
                                        ))}
                                    </div>
                                </div>
                                <p className="text-sm text-stone-600 italic leading-relaxed">"{review.comment}"</p>
                            </div>
                        ))
                    )}
                </div>

                {/* Review Form */}
                <div className="bg-stone-50 p-8 rounded-[2rem] border border-stone-100 h-fit">
                    {reviewSubmitted ? (
                        <div className="text-center py-10">
                            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600">
                                <Check size={32} />
                            </div>
                            <h4 className="font-serif text-2xl text-brand-black italic">Thank You</h4>
                            <p className="text-stone-500 text-sm mt-2">Your review has been submitted for moderation.</p>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmitReview} className="space-y-6">
                            <h4 className="font-bold text-lg text-brand-black">Share Your Experience</h4>
                            
                            {!user && (
                                <div className="bg-brand-crimson/5 border border-brand-crimson/10 p-4 rounded-xl flex items-center gap-3 text-brand-crimson text-xs font-bold">
                                    <User size={16} />
                                    <Link to="/login" className="underline">Log in</Link> to submit a review.
                                </div>
                            )}

                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Rating</label>
                                <div className="flex gap-2">
                                    {[1, 2, 3, 4, 5].map((star) => (
                                        <button 
                                            key={star} 
                                            type="button"
                                            onClick={() => setRating(star)}
                                            className={`transition-transform hover:scale-110 ${star <= rating ? 'text-brand-gold' : 'text-stone-300'}`}
                                        >
                                            <Star size={24} className={star <= rating ? 'fill-current' : ''} />
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div>
                                <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Comment</label>
                                <textarea 
                                    rows={4}
                                    value={reviewComment}
                                    onChange={(e) => setReviewComment(e.target.value)}
                                    className="w-full bg-white border border-stone-200 rounded-xl p-4 text-sm outline-none focus:border-brand-black resize-none"
                                    placeholder="Tell us about the longevity, sillage, and your overall impression..."
                                    required
                                    disabled={!user}
                                />
                            </div>

                            <button 
                                type="submit" 
                                disabled={!user}
                                className="w-full py-4 bg-brand-black text-white font-black uppercase tracking-[0.3em] text-[10px] rounded-xl hover:bg-brand-crimson transition-all shadow-lg active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Submit Review
                            </button>
                        </form>
                    )}
                </div>
            </div>
        </div>

        {/* Unified Recommendation Grids */}
        <div className="mt-32 pt-16 border-t border-stone-200">
            <div className="flex justify-between items-end mb-16 px-2">
                <div>
                    <span className="text-brand-crimson font-black uppercase tracking-[0.4em] text-[9px] block mb-2">Curated Pairing</span>
                    <h2 className="font-serif text-3xl italic text-brand-black tracking-tighter">You May Also Like</h2>
                </div>
                <Link to="/shop" className="text-[9px] font-black uppercase tracking-[0.3em] border-b border-brand-black pb-1 hover:text-brand-crimson hover:border-brand-crimson transition-all">Shop Collection</Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
                {relatedCreations.map((p) => (
                    <ProductCard key={p.id} product={p} />
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};
