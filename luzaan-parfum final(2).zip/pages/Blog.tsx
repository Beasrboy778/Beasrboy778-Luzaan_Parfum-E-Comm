
import React, { useState, useMemo } from 'react';
import { useShop } from '../context/ShopContext';
// @ts-ignore
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

export const Blog: React.FC = () => {
  const { blogPosts, designSettings } = useShop();
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Extract unique categories from blog posts
  const categories = useMemo(() => {
    const cats = new Set(blogPosts.map(p => p.category));
    return ['All', ...Array.from(cats)];
  }, [blogPosts]);

  // Filter posts based on selection
  const filteredPosts = useMemo(() => {
    if (selectedCategory === 'All') return blogPosts;
    return blogPosts.filter(p => p.category === selectedCategory);
  }, [blogPosts, selectedCategory]);

  return (
    <div className="pt-32 pb-24 px-6 max-w-7xl mx-auto animate-fade-in min-h-screen">
      {/* Blog Header with optional dynamic image */}
      <div className="relative mb-24 rounded-[3rem] overflow-hidden">
          {designSettings.blogHeaderImage && (
              <div className="absolute inset-0 z-0">
                  <img src={designSettings.blogHeaderImage} className="w-full h-full object-cover" alt="Journal Header" />
                  <div className="absolute inset-0 bg-black/40" />
              </div>
          )}
          
          <div className="relative z-10 text-center py-20 px-6">
            <span className={`font-bold text-xs tracking-[0.2em] uppercase mb-4 block ${designSettings.blogHeaderImage ? 'text-white/80' : 'text-brand-crimson'}`}>The Journal</span>
            <h1 className={`font-serif text-5xl md:text-7xl mb-8 ${designSettings.blogHeaderImage ? 'text-white' : 'text-brand-black'}`}>Stories of Scent</h1>
            
            {/* Category Filter Pills */}
            <div className="flex flex-wrap justify-center gap-4">
                {categories.map(cat => (
                    <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all duration-300 ${
                            selectedCategory === cat 
                            ? 'bg-brand-black text-white shadow-md transform scale-105' 
                            : 'bg-white/80 backdrop-blur border border-stone-200 text-stone-500 hover:border-brand-black hover:text-brand-black'
                        }`}
                    >
                        {cat}
                    </button>
                ))}
            </div>
          </div>
      </div>

      <motion.div 
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10"
      >
        <AnimatePresence mode="popLayout">
            {filteredPosts.length > 0 ? (
                filteredPosts.map(post => (
                <motion.article 
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.3 }}
                    key={post.id} 
                    className="group cursor-pointer h-full"
                >
                    <Link to={`/blog/${post.id}`} className="block h-full flex flex-col">
                    <div className="aspect-[4/3] overflow-hidden bg-stone-100 mb-6 rounded-2xl relative">
                        <img 
                        src={post.image} 
                        alt={post.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-brand-black/0 group-hover:bg-brand-black/5 transition-colors duration-500" />
                    </div>
                    <div className="flex items-center space-x-3 text-[10px] font-black uppercase tracking-widest text-stone-400 mb-3">
                        <span className="text-brand-crimson">{post.category}</span>
                        <span>•</span>
                        <span>{post.readTime}</span>
                    </div>
                    <h2 className="font-serif text-2xl text-brand-black mb-3 group-hover:text-brand-crimson transition-colors leading-tight">
                        {post.title}
                    </h2>
                    <p className="text-stone-500 leading-relaxed mb-6 line-clamp-3 text-sm font-light">
                        {post.excerpt}
                    </p>
                    <div className="mt-auto">
                        <span className="text-[10px] font-black uppercase tracking-widest border-b border-brand-black pb-1 inline-block hover:text-brand-crimson hover:border-brand-crimson transition-colors">
                            Read Story
                        </span>
                    </div>
                    </Link>
                </motion.article>
                ))
            ) : (
                <motion.div 
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="col-span-full text-center py-20 bg-stone-50 rounded-xl border border-dashed border-stone-200"
                >
                    <p className="text-stone-500 font-serif text-xl mb-4">No stories found in this category.</p>
                    <button 
                        onClick={() => setSelectedCategory('All')} 
                        className="text-brand-black underline font-bold uppercase tracking-widest text-xs hover:text-brand-crimson"
                    >
                        View all stories
                    </button>
                </motion.div>
            )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};