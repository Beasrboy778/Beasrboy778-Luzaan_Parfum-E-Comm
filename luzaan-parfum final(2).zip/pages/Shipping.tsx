
import React from 'react';
import { useShop } from '../context/ShopContext';

export const Shipping: React.FC = () => {
  const { siteContent } = useShop();

  const formatText = (text: string) => {
    return text.split('\n\n').map((para, i) => (
      <p key={i} className="mb-8 last:mb-0">
        {para.split('\n').map((line, j) => (
          <React.Fragment key={j}>
            {line}
            <br />
          </React.Fragment>
        ))}
      </p>
    ));
  };

  return (
    <div className="pt-32 pb-24 px-6 max-w-4xl mx-auto animate-fade-in text-brand-black">
      <div className="text-center mb-16 border-b border-stone-200 pb-12">
        <h1 className="font-serif text-4xl md:text-5xl mb-4 italic text-brand-black">Logistics & Returns</h1>
        <p className="text-stone-500 font-bold uppercase tracking-[0.3em] text-xs">Global Fulfillment Protocols</p>
      </div>

      <div className="font-serif text-xl leading-relaxed text-stone-700 italic max-w-2xl mx-auto">
         {formatText(siteContent.shipping)}
      </div>
    </div>
  );
};
