
import React, { useMemo, useRef, useState, useEffect } from 'react';
// @ts-ignore
import { Link } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { 
  ArrowRight, Sparkles, Clock, Star, Heart, 
  RotateCcw, Truck, Award, Shield,
  Flame, Diamond, FileCheck, FlaskConical, Leaf, Rabbit, MousePointer2, Mouse, Droplet, Layers
} from 'lucide-react';
import { ProductCard } from '../components/ProductCard';
import { AIMuse } from '../components/AIMuse';

// Enhanced Hero Card with Glassmorphism "Pop" - Fixed Rendering and Z-Index
const QuickAccessCard = ({ product, label, icon: Icon }: { product: any, label: string, icon: any }) => (
    <Link to={`/product/${product.id}`} className="block h-full">
        <motion.div 
            layout
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.02, y: -2 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
            className="flex items-center gap-4 bg-white/20 backdrop-blur-xl p-4 rounded-3xl shadow-[0_10px_30px_rgba(0,0,0,0.1)] border border-white/40 group transition-all h-full hover:shadow-xl hover:bg-white/30"
        >
            <div className="w-12 h-12 bg-white/40 rounded-xl p-2 flex items-center justify-center shrink-0 border border-white/20 group-hover:bg-white/60 transition-colors shadow-inner backdrop-blur-md">
                <img src={product.images[0]} alt="" className="w-full h-full object-contain drop-shadow-md" />
            </div>
            <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                    <Icon size={10} className="text-brand-black animate-pulse" />
                    <span className="text-[7px] font-black uppercase tracking-[0.2em] text-brand-black">{label}</span>
                </div>
                <h4 className="text-brand-black font-serif text-base leading-tight italic line-clamp-1 drop-shadow-sm">{product.name}</h4>
            </div>
        </motion.div>
    </Link>
);

const TrustIconCard = ({ icon: Icon, title, desc }: any) => (
    <div className="flex flex-col items-center text-center p-6 bg-white rounded-[2rem] border border-stone-100 shadow-sm transition-all hover:shadow-md hover:-translate-y-1 duration-500 group h-full">
        <div className="w-14 h-14 bg-stone-50 text-brand-crimson rounded-2xl flex items-center justify-center mb-4 group-hover:bg-brand-black group-hover:text-brand-gold transition-all duration-500 shadow-inner">
            <Icon size={24} strokeWidth={1} />
        </div>
        <h4 className="font-serif text-lg font-bold mb-2 italic text-brand-black">{title}</h4>
        <p className="text-[10px] text-stone-400 font-medium leading-relaxed max-w-[180px] opacity-80 uppercase tracking-wide">{desc}</p>
    </div>
);

const ScrollIndicator = () => (
    <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-stone-400 z-20"
    >
        <span className="text-[7px] font-black uppercase tracking-[0.3em]">Scroll</span>
        <motion.div 
            animate={{ y: [0, 6, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
            <Mouse size={18} />
        </motion.div>
    </motion.div>
);

export const Home: React.FC = () => {
  const { products, designSettings, blogPosts, categories, storeSettings } = useShop();
  const heroRef = useRef(null);
  const [heroIndex, setHeroIndex] = useState(0);
  
  // Use editable slides from settings or fallback to array if empty
  const heroSlides = designSettings.heroSlides && designSettings.heroSlides.length > 0 
    ? designSettings.heroSlides 
    : [
        { id: '1', line1: "Olfactory", line2: "Art.", quote: "\"We create scents that last.\"", image: "" }
    ];

  useEffect(() => {
      const interval = setInterval(() => {
          setHeroIndex((prev) => (prev + 1) % heroSlides.length);
      }, 5000); 
      return () => clearInterval(interval);
  }, [heroSlides.length]);
  
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const heroY = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const popProductScale = useTransform(scrollYProgress, [0, 0.5], [1, 1.1]);
  const popProductY = useTransform(scrollYProgress, [0, 0.8], [0, -30]);
  const popProductRotate = useTransform(scrollYProgress, [0, 1], [0, 10]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  
  // Smart Selection: Prioritize distinct products for each slot
  const newArrival = useMemo(() => 
    products.find(p => p.isNew && p.isActive), 
  [products]);

  const signatureScent = useMemo(() => 
    products.find(p => p.isBestSeller && p.isActive && p.id !== newArrival?.id), 
  [products, newArrival]);

  // Main Lists for Sections (Ensuring enough items)
  const newArrivalsList = useMemo(() => products.filter(p => p.isNew && p.isActive).slice(0, 4), [products]);
  const signatureScentsList = useMemo(() => products.filter(p => p.isBestSeller && p.isActive).slice(0, 4), [products]);
  const limitedEditionsList = useMemo(() => products.filter(p => p.isLimitedEdition && p.isActive).slice(0, 4), [products]);
  
  // Filter out "Shop All" for the collection grid
  const displayCategories = useMemo(() => categories.filter(c => c.id !== 'all').slice(0, 4), [categories]);
  const recentStories = useMemo(() => blogPosts.slice(0, 3), [blogPosts]);

  const hasHeroVisual = !!designSettings.heroVideo;
  const isVideo = designSettings.heroVideo?.includes('.mp4') || designSettings.heroVideo?.includes('video');

  const currentContent = heroSlides[heroIndex];

  // Visual Fallback - Static Image from First Slide or Default Products
  // NOTE: Image does not rotate with heroIndex anymore to ensure stability
  const staticHeroImage = heroSlides.length > 0 && heroSlides[0].image
    ? heroSlides[0].image
    : (signatureScent?.images[0] || newArrival?.images[0] || products[0]?.images[0]);

  return (
    <div className="bg-brand-cream text-brand-black font-sans">
      <AIMuse />
      
      {/* 1. HERO */}
      <section ref={heroRef} className="relative min-h-[90vh] flex flex-col justify-center px-6 lg:px-16 pt-10 overflow-hidden bg-brand-paper">
        
        {/* HERO BACKGROUND - Configurable */}
        <motion.div style={{ y: heroY, opacity: heroOpacity }} className="absolute inset-0 z-0 overflow-hidden">
             {hasHeroVisual ? (
                 <>
                    {isVideo ? (
                        <video src={designSettings.heroVideo} className="absolute inset-0 w-full h-full object-cover" autoPlay muted loop playsInline />
                    ) : (
                        <img src={designSettings.heroVideo} className="absolute inset-0 w-full h-full object-cover" alt="Hero Background" />
                    )}
                    <div className="absolute inset-0 transition-colors duration-700" style={{ backgroundColor: designSettings.heroOverlayColor, opacity: designSettings.heroOverlayOpacity }} />
                 </>
             ) : (
                 <>
                    <div className="absolute top-[5%] left-[5%] w-[600px] h-[600px] bg-brand-gold/15 rounded-full blur-[120px] animate-pulse-soft" />
                    <div className="absolute bottom-[10%] right-[5%] w-[700px] h-[700px] bg-brand-crimson/10 rounded-full blur-[140px] animate-pulse-soft" />
                 </>
             )}
        </motion.div>

        <div className="max-w-7xl mx-auto w-full grid grid-cols-1 xl:grid-cols-12 gap-10 items-center relative z-10">
          <motion.div 
            style={{ opacity: heroOpacity }}
            className="xl:col-span-6 space-y-6 text-center xl:text-left flex flex-col justify-center h-full"
          >
            <motion.div 
              initial={{ opacity: 0, x: -30 }} 
              animate={{ opacity: 1, x: 0 }} 
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="flex items-center justify-center xl:justify-start gap-3 mb-4">
                  <div className="h-px w-8 bg-brand-crimson" />
                  <span className="text-brand-crimson font-black uppercase tracking-[0.6em] text-[8px] block font-sans">{storeSettings.storeName} Perfumes</span>
              </div>
              
              {/* ROTATING HEADLINE - Reduced Size */}
              <div className="h-[120px] sm:h-[140px] md:h-[160px] relative overflow-hidden flex flex-col justify-center xl:justify-start">
                  <AnimatePresence mode="wait">
                    <motion.h1 
                        key={currentContent.id}
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -30, opacity: 0 }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className="font-serif text-5xl sm:text-6xl md:text-7xl font-bold leading-[0.95] tracking-tighter text-brand-black absolute w-full left-0 right-0 xl:text-left text-center"
                    >
                        {currentContent.line1} <br/>
                        <span className="text-brand-gold italic font-light">{currentContent.line2}</span>
                    </motion.h1>
                  </AnimatePresence>
              </div>
            </motion.div>

            {/* SUBTITLE */}
            <div className="h-16 sm:h-12 relative">
                {designSettings.heroSubtitle ? (
                    <motion.p 
                      initial={{ opacity: 0 }} 
                      animate={{ opacity: 0.8 }} 
                      className="text-stone-500 text-sm md:text-base font-serif italic max-w-md leading-relaxed mx-auto xl:mx-0 font-light text-center xl:text-left"
                    >
                      {designSettings.heroSubtitle}
                    </motion.p>
                ) : (
                    <AnimatePresence mode="wait">
                        <motion.p 
                          key={currentContent.id}
                          initial={{ opacity: 0, x: -10 }} 
                          animate={{ opacity: 0.8, x: 0 }} 
                          exit={{ opacity: 0, x: 10 }}
                          transition={{ duration: 0.5 }} 
                          className="text-stone-500 text-sm md:text-base font-serif italic max-w-md leading-relaxed mx-auto xl:mx-0 font-light absolute w-full text-center xl:text-left"
                        >
                          {currentContent.quote}
                        </motion.p>
                    </AnimatePresence>
                )}
            </div>

            {/* FLOATING CARDS */}
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.8 }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md mx-auto xl:mx-0 pt-2 relative z-30"
            >
                <AnimatePresence mode="wait">
                    {designSettings.heroShowSpotlight && (
                        <>
                            {newArrival && (
                                <div className="h-full">
                                    <QuickAccessCard product={newArrival} label="New Arrival" icon={Sparkles} />
                                </div>
                            )}
                            {signatureScent && (
                                <div className="h-full">
                                    <QuickAccessCard product={signatureScent} label="Signature Scent" icon={Star} />
                                </div>
                            )}
                        </>
                    )}
                </AnimatePresence>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center xl:justify-start pt-4"
            >
              <Link to="/shop" className="bg-brand-black text-white px-8 py-4 rounded-full text-[9px] font-black uppercase tracking-[0.25em] hover:bg-brand-crimson transition-all shadow-xl flex items-center justify-center gap-3 group active:scale-95">
                {designSettings.heroBtnText || "Shop Collection"} <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              {designSettings.heroSecondaryBtnText && (
                  <Link to={designSettings.heroSecondaryBtnLink || "/discovery"} className="bg-white/80 backdrop-blur-md text-brand-black border border-white/20 px-8 py-4 rounded-full text-[9px] font-black uppercase tracking-[0.25em] hover:bg-white transition-all shadow-md flex items-center justify-center gap-3 group active:scale-95">
                    {designSettings.heroSecondaryBtnText}
                  </Link>
              )}
            </motion.div>
          </motion.div>

          <div className="xl:col-span-6 relative flex items-center justify-center h-[400px] xl:h-[600px] overflow-visible">
             <motion.div 
                style={{ 
                    scale: popProductScale, 
                    y: popProductY, 
                    rotate: popProductRotate 
                }}
                className="relative z-20 w-full max-w-sm aspect-square"
             >
                <div className="absolute inset-0 bg-brand-gold/10 rounded-full blur-[80px] scale-75 animate-pulse" />
                <motion.img 
                    initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
                    animate={{ opacity: 1, scale: 1, rotate: 0 }}
                    transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                    src={staticHeroImage} 
                    className="w-full h-full object-contain drop-shadow-[0_40px_60px_rgba(0,0,0,0.2)] relative z-10"
                    alt="Featured Scent"
                />
             </motion.div>
          </div>
        </div>
        
        <ScrollIndicator />
      </section>

      {/* 2. THE SPOTLIGHT - CORE ESSENCE */}
      <section className="py-24 bg-white relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
              <div className="text-center mb-20 space-y-4">
                  <span className="text-brand-crimson font-black uppercase tracking-[0.8em] text-[10px] block">Curated Focus</span>
                  <h2 className="font-serif text-4xl md:text-5xl italic text-brand-black">{designSettings.homeSection1Title || "The Core Essence."}</h2>
                  <p className="text-stone-500 text-base font-serif italic max-w-xl mx-auto leading-relaxed opacity-80">
                      {designSettings.homeSection1Subtitle || "\"A selection of olfactory masterpieces defined by rare ingredients.\""}
                  </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
                  <AnimatePresence mode="wait">
                    {newArrival && (
                        <motion.div 
                            key={`spotlight-new-${newArrival.id}`}
                            whileInView={{ x: [-30, 0], opacity: [0, 1] }}
                            viewport={{ once: true }}
                            className="relative group cursor-pointer"
                        >
                            <div className="aspect-[3/4] bg-stone-50 rounded-[2.5rem] overflow-hidden relative border border-stone-100 flex items-center justify-center p-0 transition-all duration-700 group-hover:bg-brand-paper/40 group-hover:shadow-[0_40px_80px_-10px_rgba(0,0,0,0.05)]">
                                <div className="absolute top-8 left-8 flex items-center gap-3 z-20">
                                    <div className="w-10 h-10 bg-brand-black text-white rounded-xl flex items-center justify-center shadow-lg border border-white/10">
                                        <Sparkles size={20} className="text-brand-gold" />
                                    </div>
                                    <span className="text-[9px] font-black uppercase tracking-[0.4em] text-brand-black bg-white/80 backdrop-blur px-3 py-1.5 rounded-full">Just Arrived</span>
                                </div>
                                <motion.img 
                                    initial={{ scale: 0.95, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    transition={{ duration: 0.8 }}
                                    whileHover={{ scale: 1.05 }}
                                    src={designSettings.featureNewImage || newArrival.images[0]} 
                                    className={`w-full h-full ${designSettings.featureNewImage ? 'object-cover' : 'object-contain p-16'} drop-shadow-[0_30px_50px_rgba(0,0,0,0.1)] relative z-10 transition-all duration-700`} 
                                />
                            </div>
                            <div className="mt-8 space-y-4">
                                <div className="flex gap-3">
                                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-stone-50 rounded-full text-[8px] font-black uppercase tracking-widest text-stone-500">
                                        <Clock size={10} /> Long Lasting
                                    </span>
                                </div>
                                <h3 className="font-serif text-3xl text-brand-black hover:text-brand-crimson transition-colors italic">{newArrival.name}</h3>
                                <p className="text-stone-500 text-lg font-serif italic leading-relaxed max-w-sm">"{newArrival.tagline}"</p>
                                <Link to={`/product/${newArrival.id}`} className="inline-flex items-center gap-3 text-[9px] font-black uppercase tracking-[0.4em] text-brand-black border-b border-brand-gold pb-1 hover:gap-5 transition-all group">
                                    Discover Now <ArrowRight size={14} />
                                </Link>
                            </div>
                        </motion.div>
                    )}
                  </AnimatePresence>

                  <AnimatePresence mode="wait">
                    {signatureScent && (
                        <motion.div 
                            key={`spotlight-sig-${signatureScent.id}`}
                            initial={{ opacity: 0, scale: 0.95, x: 30 }}
                            whileInView={{ opacity: 1, scale: 1, x: 0 }}
                            viewport={{ once: true, margin: "-50px" }}
                            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                            className="relative group cursor-pointer lg:mt-32"
                        >
                            <div className="aspect-[3/4] bg-brand-black rounded-[2.5rem] overflow-hidden relative border border-white/5 flex items-center justify-center p-0 transition-all duration-700 group-hover:shadow-[0_40px_80px_-10px_rgba(102,15,26,0.2)]">
                                <div className="absolute top-8 left-8 flex items-center gap-3 z-20">
                                    <div className="w-10 h-10 bg-brand-gold text-brand-black rounded-xl flex items-center justify-center shadow-lg">
                                        <Star size={20} fill="currentColor" />
                                    </div>
                                    <span className="text-[9px] font-black uppercase tracking-[0.4em] text-brand-gold bg-black/40 backdrop-blur px-3 py-1.5 rounded-full border border-brand-gold/20">Signature</span>
                                </div>
                                <motion.img 
                                    initial={{ scale: 0.95, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    transition={{ duration: 0.8 }}
                                    whileHover={{ scale: 1.05 }}
                                    src={designSettings.featureBestSellerImage || signatureScent.images[0]} 
                                    className={`w-full h-full ${designSettings.featureBestSellerImage ? 'object-cover' : 'object-contain p-16'} drop-shadow-[0_30px_50px_rgba(255,255,255,0.05)] relative z-10 transition-all duration-700`} 
                                />
                            </div>
                            <div className="mt-8 space-y-4">
                                <div className="flex gap-3">
                                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-stone-50 rounded-full text-[8px] font-black uppercase tracking-widest text-stone-500">
                                        <Award size={10} /> Award Winner
                                    </span>
                                </div>
                                <h3 className="font-serif text-3xl text-brand-black hover:text-brand-crimson transition-colors italic">{signatureScent.name}</h3>
                                <p className="text-stone-500 text-lg font-serif italic leading-relaxed max-w-sm">"{signatureScent.tagline}"</p>
                                <Link to={`/product/${signatureScent.id}`} className="inline-flex items-center gap-3 text-[9px] font-black uppercase tracking-[0.4em] text-brand-black border-b border-brand-gold pb-1 hover:gap-5 transition-all">
                                    Experience Luxury <ArrowRight size={14} />
                                </Link>
                            </div>
                        </motion.div>
                    )}
                  </AnimatePresence>
              </div>
          </div>
      </section>

      {/* 3. NEW ARRIVALS */}
      <section className="py-24 bg-brand-cream relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
              <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
                  <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Sparkles size={16} className="text-brand-crimson" />
                        <span className="text-brand-crimson font-black uppercase tracking-[0.6em] text-[10px] block">Fresh Scents</span>
                      </div>
                      <h2 className="font-serif text-4xl md:text-5xl font-bold text-brand-black tracking-tight uppercase">{designSettings.homeSection2Title || "New Arrivals."}</h2>
                      <p className="text-stone-400 text-lg font-serif italic max-w-sm">{designSettings.homeSection2Subtitle || "\"Discover the latest additions.\""}</p>
                  </div>
                  <Link to="/shop?cat=new" className="text-[9px] font-black uppercase tracking-[0.3em] border-b border-brand-black pb-1 hover:text-brand-crimson hover:border-brand-crimson transition-all mb-2">View All New</Link>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
                  {newArrivalsList.map((product, idx) => (
                      <motion.div 
                        key={`new-${product.id}-${idx}`}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.1 }}
                      >
                          <ProductCard product={product} />
                      </motion.div>
                  ))}
              </div>
          </div>
      </section>

      {/* NEW: COLLECTIONS GRID (Shop by Category) */}
      <section className="py-24 bg-white border-y border-stone-100">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
              <div className="text-center mb-16">
                  <span className="text-[9px] font-black uppercase tracking-[0.6em] text-stone-400 block mb-3">{storeSettings.storeName} Archives</span>
                  <h2 className="font-serif text-4xl italic text-brand-black">Browse by Category</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {displayCategories.map((cat, idx) => (
                      <Link to={`/shop?cat=${cat.id}`} key={cat.id} className="group relative aspect-[3/4] overflow-hidden rounded-[2rem] bg-stone-100">
                          {cat.image ? (
                              <img src={cat.image} alt={cat.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                          ) : (
                              <div className="w-full h-full flex items-center justify-center text-stone-300 bg-stone-50">
                                  <Layers size={32} />
                              </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-brand-black/70 to-transparent flex flex-col justify-end p-6">
                              <h3 className="text-white font-serif text-xl italic mb-1">{cat.name}</h3>
                              <p className="text-[8px] font-black uppercase tracking-[0.25em] text-white/80 group-hover:text-white transition-colors">Explore <ArrowRight size={10} className="inline ml-1" /></p>
                          </div>
                      </Link>
                  ))}
              </div>
          </div>
      </section>

      {/* 4. MARQUEE & HERITAGE (Configurable) */}
      <div className="w-full overflow-hidden bg-brand-black py-3 border-y border-white/10 relative z-20">
         <div className="flex animate-marquee whitespace-nowrap text-white text-[10px] font-black uppercase tracking-[0.4em] items-center">
             {[...Array(8)].map((_, i) => (
                <span key={i} className="mx-8">{designSettings.marqueeText || "Handmade in small batches • 100% Pure Essential Oils • No synthetic chemicals • aged 180 days •"}</span>
             ))}
         </div>
      </div>

      <section className="bg-brand-paper py-24 border-b border-stone-200">
          <div className="max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div className="order-2 lg:order-1">
                  <span className="text-brand-gold font-black uppercase tracking-[0.6em] text-[9px] block mb-4">Our Philosophy</span>
                  <h2 className="font-serif text-4xl md:text-5xl italic text-brand-black mb-6 leading-tight">Rooted in <br/>Ancient Rituals</h2>
                  <p className="text-stone-600 text-base leading-loose font-light max-w-lg mb-8">
                      {designSettings.heroDescription || "We believe that perfume is not just a scent, but a memory. Every bottle is crafted with patience, using only the finest natural extracts sourced from sustainable farms around the globe."}
                  </p>
                  <Link to="/about" className="inline-flex items-center gap-3 text-[9px] font-black uppercase tracking-[0.25em] bg-brand-black text-white px-8 py-3.5 rounded-full hover:bg-brand-crimson transition-all shadow-lg">
                      Read Our Story
                  </Link>
              </div>
              <div className="order-1 lg:order-2 relative aspect-[4/5] rounded-[3rem] overflow-hidden shadow-xl">
                  {designSettings.philosophyImage ? (
                      <img src={designSettings.philosophyImage} className="w-full h-full object-cover transition-transform duration-[10s] hover:scale-105" alt="Philosophy" />
                  ) : (
                      <div className="w-full h-full bg-stone-200 flex items-center justify-center">
                          <p className="text-stone-400 font-black uppercase tracking-widest text-[9px]">Image Configurable in Admin</p>
                      </div>
                  )}
              </div>
          </div>
      </section>

      {/* 5. SIGNATURE SCENTS */}
      <section className="py-24 bg-white relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
              <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
                  <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Flame size={16} className="text-brand-gold" />
                        <span className="text-brand-gold font-black uppercase tracking-[0.6em] text-[10px] block">Signature Selection</span>
                      </div>
                      <h2 className="font-serif text-4xl md:text-5xl font-bold text-brand-black tracking-tight uppercase">{designSettings.homeSection3Title || "Signature Scents."}</h2>
                      <p className="text-stone-500 text-lg font-serif italic max-w-sm">{designSettings.homeSection3Subtitle || "\"Our most loved scents.\""}</p>
                  </div>
                  <Link to="/shop" className="text-[9px] font-black uppercase tracking-[0.3em] border-b border-brand-black pb-1 hover:text-brand-crimson hover:border-brand-crimson transition-all mb-2">Shop Classics</Link>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
                  {signatureScentsList.map((product, idx) => (
                      <motion.div 
                        key={`sig-${product.id}-${idx}`}
                        initial={{ opacity: 0, scale: 0.98 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.1, duration: 0.8 }}
                      >
                          <ProductCard product={product} />
                      </motion.div>
                  ))}
              </div>
          </div>
      </section>

      {/* 6. LIMITED EDITION */}
      <section className="py-24 bg-brand-cream relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
              <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
                  <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Diamond size={16} className="text-brand-crimson" />
                        <span className="text-brand-crimson font-black uppercase tracking-[0.6em] text-[10px] block">Rare Batch</span>
                      </div>
                      <h2 className="font-serif text-4xl md:text-5xl font-bold text-brand-black tracking-tight uppercase">{designSettings.homeSection4Title || "Limited Edition."}</h2>
                      <p className="text-stone-400 text-lg font-serif italic max-w-sm">{designSettings.homeSection4Subtitle || "\"Exclusive perfumes made in very small batches.\""}</p>
                  </div>
                  <Link to="/shop" className="text-[9px] font-black uppercase tracking-[0.3em] border-b border-brand-black pb-1 hover:text-brand-crimson hover:border-brand-crimson transition-all mb-2">View Limited</Link>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
                  {limitedEditionsList.map((product, idx) => (
                      <motion.div 
                        key={`lim-${product.id}-${idx}`}
                        initial={{ opacity: 0, y: 30 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.1, duration: 0.9 }}
                      >
                          <ProductCard product={product} />
                      </motion.div>
                  ))}
              </div>
          </div>
      </section>

      {/* 7. AI MUSE */}
      <section className="bg-brand-black py-32 text-white overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_80%_20%,rgba(102,15,26,0.15),transparent_50%)]" />
          <div className="max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-2 gap-24 items-center relative z-10">
              <div className="space-y-10">
                  <div className="inline-flex items-center gap-4 bg-white/5 border border-white/10 px-6 py-3 rounded-full shadow-lg">
                      <Sparkles size={16} className="text-brand-gold animate-pulse" />
                      <span className="text-brand-gold font-black uppercase tracking-[0.4em] text-[9px] font-sans">{storeSettings.storeName} AI Scent Finder</span>
                  </div>
                  <h2 className="font-serif text-6xl md:text-7xl italic leading-[0.95] tracking-tighter">
                    {designSettings.homeMuseTitle?.split(' ').slice(0, -1).join(' ') || "Consult"} <br/>
                    <span className="text-brand-gold">{designSettings.homeMuseTitle?.split(' ').pop() || "Muse"}</span>
                  </h2>
                  <p className="text-stone-400 text-xl md:text-2xl font-serif italic leading-relaxed max-w-md font-light opacity-80">
                    {designSettings.homeMuseSubtitle || "\"Tell me about a memory or feeling, and I will help you find your perfect scent.\""}
                  </p>
                  <div className="flex flex-col sm:flex-row gap-8 items-center pt-4">
                    <Link to="/discovery" className="bg-white text-brand-black px-12 py-5 rounded-full text-[10px] font-black uppercase tracking-[0.25em] hover:bg-brand-gold hover:text-white transition-all shadow-xl active:scale-95 font-sans">
                        Begin Ritual
                    </Link>
                    <div className="flex items-center gap-4 text-stone-500 italic font-serif text-2xl">
                        <Award size={24} className="text-brand-gold" /> 
                        <span>Matched with Intelligence</span>
                    </div>
                  </div>
              </div>
              <motion.div 
                whileInView={{ scale: [0.95, 1], opacity: [0, 1] }} 
                viewport={{ once: true }}
                transition={{ duration: 2.5 }}
                className="relative aspect-square max-w-xl mx-auto"
              >
                 <div className="absolute inset-0 bg-brand-gold/10 blur-[100px] rounded-full scale-110" />
                 <img src={designSettings.museImage || "https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=1200&q=80"} className="w-full h-full object-cover rounded-[3rem] shadow-2xl border border-white/10 grayscale hover:grayscale-0 transition-all duration-2000" alt="The Muse" />
              </motion.div>
          </div>
      </section>

      {/* NEW: LATEST STORIES (Dynamic from Admin) */}
      <section className="py-24 bg-stone-50 border-t border-stone-200">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
              <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
                  <div className="space-y-4">
                      <span className="text-brand-crimson font-black uppercase tracking-[0.6em] text-[9px] block">The Journal</span>
                      <h2 className="font-serif text-4xl md:text-5xl text-brand-black">Stories of Scent.</h2>
                  </div>
                  <Link to="/blog" className="text-[9px] font-black uppercase tracking-[0.3em] border-b border-brand-black pb-1 hover:text-brand-crimson hover:border-brand-crimson transition-all mb-2">Read Archive</Link>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {recentStories.map((post, idx) => (
                      <Link to={`/blog/${post.id}`} key={post.id} className="group cursor-pointer">
                          <div className="aspect-[4/3] overflow-hidden rounded-[2rem] bg-white mb-6 relative">
                              <img src={post.image} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" alt={post.title} />
                              <div className="absolute inset-0 bg-brand-black/10 group-hover:bg-transparent transition-colors" />
                          </div>
                          <div className="flex items-center gap-3 text-[8px] font-black uppercase tracking-widest text-stone-400 mb-2">
                              <span className="text-brand-crimson">{post.category}</span>
                              <span>•</span>
                              <span>{post.readTime}</span>
                          </div>
                          <h3 className="font-serif text-xl text-brand-black group-hover:text-brand-crimson transition-colors leading-tight">{post.title}</h3>
                      </Link>
                  ))}
              </div>
          </div>
      </section>

      {/* 8. BRAND PROMISE */}
      <section className="bg-brand-paper py-24 border-t border-stone-100 relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
              <div className="text-center mb-16">
                  <span className="text-[10px] font-black uppercase tracking-[0.8em] text-brand-crimson mb-6 block font-sans">Our Commitment</span>
                  <h2 className="font-serif text-5xl md:text-6xl italic text-brand-black tracking-tight leading-none">Built for Connoisseurs</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
                  <TrustIconCard 
                    icon={Truck} 
                    title="Global Shipping" 
                    desc="Free shipping worldwide on all orders over $200." 
                  />
                  <TrustIconCard 
                    icon={Shield} 
                    title="Pure Extracts" 
                    desc="100% natural oils ethically sourced." 
                  />
                  <TrustIconCard 
                    icon={Heart} 
                    title="Handcrafted" 
                    desc="Small batch perfumes made with care." 
                  />
                  <TrustIconCard 
                    icon={RotateCcw} 
                    title="Refillable" 
                    desc="Sustainable bottles designed to last." 
                  />
                  <TrustIconCard 
                    icon={FileCheck} 
                    title="IFRA Compliant" 
                    desc="Strict adherence to international safety standards." 
                  />
                  <TrustIconCard 
                    icon={FlaskConical} 
                    title="Lab Tested" 
                    desc="Rigorously tested for stability and skin safety." 
                  />
                  <TrustIconCard 
                    icon={Leaf} 
                    title="Clean Beauty" 
                    desc="Free from phthalates, parabens, and sulfates." 
                  />
                  <TrustIconCard 
                    icon={Rabbit} 
                    title="Cruelty Free" 
                    desc="Never tested on animals, forever ethical." 
                  />
              </div>
          </div>
      </section>
    </div>
  );
};
