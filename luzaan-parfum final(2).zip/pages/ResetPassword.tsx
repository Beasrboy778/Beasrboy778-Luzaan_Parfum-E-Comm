
import React, { useState, useEffect } from 'react';
// @ts-ignore
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { GlassCard } from '../components/GlassCard';
import { Loader2, Lock, CheckCircle, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { AuraLoader } from '../components/AuraLoader';
import { AnimatePresence } from 'framer-motion';

export const ResetPassword: React.FC = () => {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  
  const { confirmPasswordReset, isLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Extract query params
  const searchParams = new URLSearchParams(location.search);
  const email = searchParams.get('email');
  const token = searchParams.get('token');

  useEffect(() => {
      if (!email || !token) {
          setStatus('error');
          setErrorMsg('Invalid or expired ritual token.');
      }
  }, [email, token]);

  const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!email) return;

      if (newPassword.length < 6) {
          setErrorMsg('Password must be at least 6 characters.');
          setStatus('error');
          return;
      }

      if (newPassword !== confirmPassword) {
          setErrorMsg('Passwords do not match.');
          setStatus('error');
          return;
      }

      const success = await confirmPasswordReset(email, newPassword);
      if (success) {
          setStatus('success');
          setTimeout(() => navigate('/login'), 3000);
      } else {
          setErrorMsg('Failed to update credentials. Please try again.');
          setStatus('error');
      }
  };

  const glassInputClass = "w-full bg-white/40 backdrop-blur-md border border-stone-200/50 p-4 text-sm text-brand-black font-sans focus:bg-white/70 focus:border-brand-black outline-none transition-all rounded-xl shadow-inner placeholder-stone-400";

  return (
    <div className="min-h-screen pt-32 pb-24 px-6 flex items-center justify-center relative bg-brand-cream">
      <AnimatePresence>
        {isLoading && <AuraLoader text="Encrypting New Protocol..." fullScreen={true} />}
      </AnimatePresence>

      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-gold/5 rounded-full blur-[128px]" />

      <GlassCard className="p-12 max-w-md w-full relative z-10 border border-white/40 shadow-2xl rounded-[3rem]">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-brand-black text-brand-cream rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
             <Lock size={28} />
          </div>
          <h1 className="font-serif font-bold text-3xl text-brand-black mb-3">Secure Reset</h1>
          <p className="text-stone-500 text-[10px] font-black uppercase tracking-[0.2em]">Define your new access key</p>
        </div>

        {status === 'success' ? (
            <div className="text-center space-y-6">
                <div className="bg-green-50 border border-green-100 p-6 rounded-2xl">
                    <CheckCircle className="mx-auto text-green-600 mb-2" size={32} />
                    <h3 className="font-bold text-green-800">Protocol Updated</h3>
                    <p className="text-sm text-green-700 mt-1">Your password has been reset successfully.</p>
                </div>
                <p className="text-xs text-stone-400 uppercase tracking-widest animate-pulse">Redirecting to Login...</p>
            </div>
        ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
                {status === 'error' && (
                    <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3 text-red-600">
                        <AlertCircle size={20} />
                        <p className="text-xs font-bold uppercase tracking-tight">{errorMsg}</p>
                    </div>
                )}

                <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Identity</label>
                    <input type="text" value={email || ''} disabled className="w-full bg-stone-100 border border-stone-200 p-4 rounded-xl text-sm text-stone-500 cursor-not-allowed" />
                </div>

                <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">New Password</label>
                    <div className="relative">
                        <input 
                            type={showPassword ? 'text' : 'password'} 
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            className={`${glassInputClass} pr-12`}
                            placeholder="Min. 6 characters"
                            required
                        />
                        <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-300 hover:text-brand-black transition-colors"
                        >
                            {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                        </button>
                    </div>
                </div>

                <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Confirm Password</label>
                    <input 
                        type={showPassword ? 'text' : 'password'} 
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className={glassInputClass}
                        placeholder="Re-enter password"
                        required
                    />
                </div>

                <button 
                    type="submit" 
                    disabled={isLoading || !email}
                    className="w-full bg-brand-black text-white py-5 font-black uppercase tracking-[0.4em] text-[10px] hover:bg-brand-crimson transition-all duration-500 rounded-xl shadow-xl flex items-center justify-center active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                    {isLoading ? <Loader2 className="animate-spin" size={20} /> : 'Update Protocol'}
                </button>
                
                <div className="text-center mt-6">
                    <Link to="/login" className="text-[10px] font-black uppercase tracking-widest text-stone-400 hover:text-brand-black transition-colors">Cancel</Link>
                </div>
            </form>
        )}
      </GlassCard>
    </div>
  );
};
