
import React, { useMemo, useState, useEffect } from 'react';
// @ts-ignore
import { useLocation, Link } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { motion, Variants, AnimatePresence } from 'framer-motion';
import { SlidersHorizontal, ChevronDown, Search, RotateCcw } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';

type SortOption = 'Newest' | 'Price: Low' | 'Price: High' | 'Rating';

export const Shop: React.FC = () => {
  const { products, categories, toggleSearch, designSettings } = useShop();
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const categoryFilter = queryParams.get('cat') || 'all';

  const [sortBy, setSortBy] = useState<SortOption>('Newest');
  const [isSortOpen, setIsSortOpen] = useState(false);

  const filteredProducts = useMemo(() => {
    let result = [...products];
    
    if (categoryFilter !== 'all') {
        result = result.filter(p => p.category.toLowerCase() === categoryFilter.toLowerCase());
    }

    switch (sortBy) {
        case 'Price: Low': result.sort((a, b) => a.price - b.price); break;
        case 'Price: High': result.sort((a, b) => b.price - a.price); break;
        case 'Rating': result.sort((a, b) => (b.rating || 0) - (a.rating || 0)); break;
        case 'Newest': default: result.sort((a, b) => (a.isNew ? -1 : 1)); break;
    }

    return result;
  }, [categoryFilter, products, sortBy]);

  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
  };

  const itemVariants: Variants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <div className="pb-24 px-6 md:px-12 max-w-[1700px] mx-auto min-h-screen bg-brand-cream animate-fade-in">
      {/* Header with Dynamic Image - Reduced Height */}
      <div className="relative rounded-[2.5rem] overflow-hidden mb-12 mt-28 min-h-[30vh] flex items-center justify-center text-center">
          {designSettings.shopBannerImage && (
              <div className="absolute inset-0 z-0">
                  <img src={designSettings.shopBannerImage} alt="Shop Banner" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/30" />
              </div>
          )}
          <div className="relative z-10 p-8">
            <span className={`font-black uppercase tracking-[0.4em] text-[9px] mb-3 block ${designSettings.shopBannerImage ? 'text-white/80' : 'text-brand-crimson'}`}>Private Archive</span>
            <h1 className={`font-serif text-4xl md:text-5xl capitalize mb-4 italic tracking-tight ${designSettings.shopBannerImage ? 'text-white' : 'text-brand-black'}`}>
              {categoryFilter === 'all' ? (designSettings.shopTitle || 'All Scents') : `${categoryFilter} Fragments`}
            </h1>
            <p className={`max-w-lg mx-auto text-xs md:text-sm font-serif italic leading-relaxed opacity-80 ${designSettings.shopBannerImage ? 'text-white' : 'text-stone-400'}`}>
              Discover a curated library of handcrafted olfactory expressions.
            </p>
          </div>
      </div>

      {/* Refined Toolbar */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-10 border-b border-brand-black/5 pb-6 sticky top-20 z-30 bg-brand-cream/95 backdrop-blur-sm py-3 rounded-xl">
          <div className="flex flex-wrap justify-center md:justify-start gap-2">
            {categories.map(cat => (
                <Link
                    key={cat.id}
                    to={cat.id === 'all' ? '/shop' : `/shop?cat=${cat.id}`}
                    className={`px-5 py-2 rounded-full text-[8px] font-black uppercase tracking-[0.2em] transition-all border ${
                        categoryFilter === cat.id || (categoryFilter === 'all' && cat.id === 'all')
                        ? 'bg-brand-black text-white border-brand-black shadow-md' 
                        : 'bg-white border-stone-200 text-stone-400 hover:border-brand-black'
                    }`}
                >
                    {cat.name}
                </Link>
            ))}
          </div>

          <div className="flex items-center gap-4">
              <button onClick={toggleSearch} className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-stone-400 hover:text-brand-black transition-colors">
                  <Search size={14} /> Search
              </button>

              <div className="relative">
                  <button 
                    onClick={() => setIsSortOpen(!isSortOpen)}
                    className="flex items-center gap-2 px-5 py-2 bg-white border border-stone-200 rounded-full text-[9px] font-black uppercase tracking-widest hover:border-brand-black transition-all"
                  >
                      <SlidersHorizontal size={12} className="text-brand-gold" />
                      <span>{sortBy}</span>
                  </button>

                  <AnimatePresence>
                      {isSortOpen && (
                          <motion.div 
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 5 }}
                            className="absolute top-full right-0 mt-2 w-44 bg-white border border-stone-100 rounded-xl shadow-2xl overflow-hidden p-1.5 z-50"
                          >
                              {['Newest', 'Price: Low', 'Price: High', 'Rating'].map((opt) => (
                                  <button
                                      key={opt}
                                      onClick={() => { setSortBy(opt as any); setIsSortOpen(false); }}
                                      className={`w-full text-left px-4 py-2 rounded-lg text-[8px] font-bold uppercase tracking-widest transition-all ${sortBy === opt ? 'bg-brand-black text-white' : 'hover:bg-brand-cream text-brand-black/60'}`}
                                  >
                                      {opt}
                                  </button>
                              ))}
                          </motion.div>
                      )}
                  </AnimatePresence>
              </div>
          </div>
      </div>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        key={`${categoryFilter}-${sortBy}`}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10"
      >
        {filteredProducts.map(product => (
          <ProductCard key={product.id} product={product} variants={itemVariants} />
        ))}
      </motion.div>

      {filteredProducts.length === 0 && (
          <div className="text-center py-24 bg-white/50 rounded-[2.5rem] border border-dashed border-stone-200">
              <p className="font-serif text-xl text-stone-400 italic mb-4">No scents match this corridor.</p>
              <Link to="/shop" className="text-[9px] font-black uppercase tracking-widest border-b border-brand-black pb-1">Reset Filters</Link>
          </div>
      )}
    </div>
  );
};
