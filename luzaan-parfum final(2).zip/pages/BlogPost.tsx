
import React, { useEffect, useState } from 'react';
// @ts-ignore
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { useAuth } from '../context/AuthContext';
import { ArrowLeft, Calendar, Clock, Tag, FileQuestion, Facebook, Twitter, Link as LinkIcon, Check, Linkedin, MessageSquare, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { BlogComment } from '../types';

export const BlogPost: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { blogPosts, blogComments, addBlogComment } = useShop();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  
  // Comment Form State
  const [authorName, setAuthorName] = useState(user ? user.name : '');
  const [authorEmail, setAuthorEmail] = useState(user ? user.email : '');
  const [commentText, setCommentText] = useState('');
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success'>('idle');

  // Robustly find post
  const post = blogPosts.find(p => String(p.id).trim() === String(id).trim());
  
  // Filter only approved comments for this post
  const activeComments = blogComments.filter(c => String(c.postId).trim() === String(id).trim() && c.status === 'approved');

  useEffect(() => {
    window.scrollTo(0, 0);
    if(user) {
        setAuthorName(user.name);
        setAuthorEmail(user.email);
    }
  }, [id, user]);

  const handleCopy = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!authorName.trim() || !commentText.trim()) return;

      const newComment: BlogComment = {
          id: Date.now().toString(),
          postId: post!.id,
          postTitle: post!.title,
          userName: authorName,
          email: authorEmail,
          comment: commentText,
          date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          status: 'pending' // Pending moderation
      };

      addBlogComment(newComment);
      setSubmitStatus('success');
      setCommentText('');
      // Reset status after 3 seconds
      setTimeout(() => setSubmitStatus('idle'), 3000);
  };

  if (!post) {
    return (
        <div className="pt-32 pb-24 text-center px-6 min-h-[70vh] flex flex-col justify-center items-center bg-brand-cream animate-fade-in">
            <div className="mb-6 text-stone-300">
                <FileQuestion size={64} strokeWidth={1} />
            </div>
            <h1 className="font-serif text-4xl mb-4 text-brand-black">Story Not Found</h1>
            <p className="text-stone-500 mb-8 max-w-md mx-auto leading-relaxed">
                We couldn't locate the story you're looking for (ID: {id}). It may have been removed, or the link might be incorrect.
            </p>
            <div className="flex gap-4">
                <button 
                    onClick={() => navigate(-1)}
                    className="px-8 py-3 border border-brand-black text-brand-black rounded-full text-xs font-bold uppercase tracking-widest hover:bg-stone-100 transition-colors"
                >
                    Go Back
                </button>
                <Link 
                    to="/blog" 
                    className="px-8 py-3 bg-brand-black text-white rounded-full text-xs font-bold uppercase tracking-widest hover:bg-stone-800 transition-colors"
                >
                    View All Stories
                </Link>
            </div>
        </div>
    );
  }

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  return (
    <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-32 pb-24 px-6 max-w-4xl mx-auto bg-brand-cream min-h-screen"
    >
      <button 
        onClick={() => navigate('/blog')} 
        className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-stone-500 hover:text-brand-black mb-8 transition-colors group"
      >
        <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" /> Back to Journal
      </button>

      <div className="text-center mb-12">
         <div className="flex justify-center items-center gap-4 md:gap-6 text-[10px] md:text-xs text-stone-500 font-bold mb-6 uppercase tracking-widest flex-wrap">
            <span className="flex items-center gap-2 text-brand-crimson bg-brand-crimson/5 px-3 py-1 rounded-full"><Tag size={12} /> {post.category}</span>
            <span className="flex items-center gap-2"><Calendar size={12} /> {post.date}</span>
            <span className="flex items-center gap-2"><Clock size={12} /> {post.readTime}</span>
         </div>
         <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-brand-black mb-8 leading-[1.1]">{post.title}</h1>
      </div>

      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="aspect-[21/9] w-full overflow-hidden mb-16 rounded-2xl shadow-xl relative bg-stone-200"
      >
         <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
         <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
      </motion.div>

      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="prose prose-lg prose-stone mx-auto font-light leading-loose tracking-wide prose-headings:font-serif prose-headings:text-brand-black prose-h2:text-3xl prose-h3:text-2xl prose-a:text-brand-crimson prose-img:rounded-xl" 
        dangerouslySetInnerHTML={{ __html: post.content }} 
      />

      {/* Social Sharing Section */}
      <div className="max-w-3xl mx-auto mt-16 pt-8 border-t border-stone-200">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <span className="font-serif text-lg text-brand-black italic">Share this story</span>
            <div className="flex items-center gap-4">
                <a 
                    href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(currentUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full border border-stone-200 flex items-center justify-center text-stone-500 hover:bg-brand-black hover:text-white hover:border-brand-black transition-all"
                    title="Share on Twitter"
                >
                    <Twitter size={18} />
                </a>
                <a 
                    href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full border border-stone-200 flex items-center justify-center text-stone-500 hover:bg-brand-black hover:text-white hover:border-brand-black transition-all"
                    title="Share on Facebook"
                >
                    <Facebook size={18} />
                </a>
                <a 
                    href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(currentUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full border border-stone-200 flex items-center justify-center text-stone-500 hover:bg-brand-black hover:text-white hover:border-brand-black transition-all"
                    title="Share on LinkedIn"
                >
                    <Linkedin size={18} />
                </a>
                <a 
                    href={`https://pinterest.com/pin/create/button/?url=${encodeURIComponent(currentUrl)}&media=${encodeURIComponent(post.image)}&description=${encodeURIComponent(post.title)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full border border-stone-200 flex items-center justify-center text-stone-500 hover:bg-brand-black hover:text-white hover:border-brand-black transition-all"
                    title="Share on Pinterest"
                >
                   {/* Pinterest SVG */}
                   <svg role="img" viewBox="0 0 24 24" fill="currentColor" stroke="none" className="w-[18px] h-[18px]"><path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.399.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.951-7.252 4.173 0 7.41 2.967 7.41 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.367 18.62 0 12.017 0z"/></svg>
                </a>
                <button 
                    onClick={handleCopy}
                    className="w-10 h-10 rounded-full border border-stone-200 flex items-center justify-center text-stone-500 hover:bg-brand-black hover:text-white hover:border-brand-black transition-all"
                    title="Copy Link"
                >
                    {copied ? <Check size={18} /> : <LinkIcon size={18} />}
                </button>
            </div>
        </div>
      </div>

      {/* COMMENTS SECTION */}
      <div className="max-w-3xl mx-auto mt-24">
          <h3 className="font-serif text-3xl text-brand-black mb-10 flex items-center gap-3 border-b border-brand-black/5 pb-4">
              Discussion <span className="text-lg text-stone-400 font-sans">({activeComments.length})</span>
          </h3>

          <div className="space-y-12 mb-16">
              {activeComments.length === 0 ? (
                  <p className="text-stone-400 italic text-center py-8">Be the first to share your thoughts on this story.</p>
              ) : (
                  activeComments.map(comment => (
                      <div key={comment.id} className="flex gap-6">
                          <div className="w-12 h-12 bg-white rounded-full border border-stone-200 flex items-center justify-center font-serif text-lg font-bold text-brand-black shadow-sm shrink-0">
                              {comment.userName.charAt(0)}
                          </div>
                          <div>
                              <div className="flex items-center gap-3 mb-1">
                                  <span className="font-bold text-brand-black text-sm uppercase tracking-wide">{comment.userName}</span>
                                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">{comment.date}</span>
                              </div>
                              <p className="text-stone-600 leading-relaxed font-light">{comment.comment}</p>
                          </div>
                      </div>
                  ))
              )}
          </div>

          <div className="bg-white p-8 md:p-10 rounded-[2rem] border border-stone-100 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-6 opacity-[0.03] pointer-events-none text-brand-black">
                  <MessageSquare size={120} />
              </div>
              
              <h4 className="font-bold text-brand-black text-lg mb-6">Leave a Comment</h4>
              
              {submitStatus === 'success' ? (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-green-50 border border-green-100 p-6 rounded-2xl flex items-center gap-4 text-green-700">
                      <Check size={24} />
                      <div>
                          <p className="font-bold text-sm uppercase tracking-widest mb-1">Submission Received</p>
                          <p className="text-xs">Your comment has been sent for moderation and will appear shortly.</p>
                      </div>
                  </motion.div>
              ) : (
                  <form onSubmit={handleCommentSubmit} className="space-y-6 relative z-10">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                              <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Name</label>
                              <input 
                                  required 
                                  type="text" 
                                  value={authorName}
                                  onChange={(e) => setAuthorName(e.target.value)}
                                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-brand-black transition-colors"
                                  placeholder="Your Name"
                              />
                          </div>
                          <div>
                              <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Email (Private)</label>
                              <input 
                                  type="email" 
                                  value={authorEmail}
                                  onChange={(e) => setAuthorEmail(e.target.value)}
                                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-brand-black transition-colors"
                                  placeholder="email@example.com"
                              />
                          </div>
                      </div>
                      <div>
                          <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Message</label>
                          <textarea 
                              required 
                              rows={4}
                              value={commentText}
                              onChange={(e) => setCommentText(e.target.value)}
                              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-brand-black transition-colors resize-none leading-relaxed"
                              placeholder="Share your perspective..."
                          />
                      </div>
                      <button 
                          type="submit" 
                          className="px-8 py-3 bg-brand-black text-white rounded-xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-brand-crimson transition-all shadow-lg active:scale-95 flex items-center gap-3"
                      >
                          Post Comment <Send size={14} />
                      </button>
                  </form>
              )}
          </div>
      </div>
      
      <div className="mt-24 pt-10 border-t border-stone-200 text-center">
         <h3 className="font-serif text-2xl mb-6">Enjoyed this story?</h3>
         <Link to="/blog" className="inline-block border-b-2 border-brand-black pb-1 text-sm font-bold uppercase tracking-widest hover:text-brand-crimson hover:border-brand-crimson transition-all">
            Read More Stories
         </Link>
      </div>
    </motion.div>
  );
};
