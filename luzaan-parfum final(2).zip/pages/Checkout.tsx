
import React, { useState, useEffect, useMemo } from 'react';
import { useShop } from '../context/ShopContext';
// @ts-ignore
import { Link, useNavigate } from 'react-router-dom';
import { 
  CheckCircle2, CreditCard, Wallet, Smartphone, Landmark,
  Ticket, ChevronLeft, CreditCard as CreditCardIcon, ShieldCheck, Banknote,
  ShoppingBag, ArrowRight, Loader2, Truck, Zap, Gift, AlertCircle,
  Lock, LogIn, Hourglass
} from 'lucide-react';
import { useCurrency } from '../context/CurrencyContext';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { AuraLoader } from '../components/AuraLoader';
import { AnimatedCheckmark } from '../components/AnimatedIcons';

const InputField = ({ label, error, ...props }: any) => (
    <div className="w-full">
        <label className="block text-[9px] font-black uppercase tracking-widest text-stone-400 mb-1.5 font-sans">{label}</label>
        <input 
            className={`w-full bg-white text-brand-black border rounded-xl px-4 py-3 text-sm outline-none transition-all placeholder-stone-300 focus:ring-2 focus:ring-brand-black/5 ${error ? 'border-red-500' : 'border-stone-200 focus:border-brand-black'}`}
            {...props}
        />
        {error && <p className="text-[10px] text-red-500 mt-1">{error}</p>}
    </div>
);

export const Checkout: React.FC = () => {
  const { cart, cartTotal, addOrder, clearCart, shippingSettings, storeSettings, validateCoupon } = useShop();
  const { user, isAuthenticated } = useAuth();
  const { formatPrice, country } = useCurrency();
  const navigate = useNavigate();
  
  const [currentStep, setCurrentStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [shippingMethodId, setShippingMethodId] = useState<string>(shippingSettings.zones[0].id);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'apple' | 'bnpl' | 'cod'>('card');
  const [isGiftWrapped, setIsGiftWrapped] = useState(false);
  
  const [cardDetails, setCardDetails] = useState({ number: '', expiry: '', cvc: '', name: '' });
  const [promoCode, setPromoCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState(false);

  // Redirect Admins away from Checkout - STRICT CHECK
  useEffect(() => {
      if (user?.role === 'admin') {
          navigate('/admin', { replace: true });
      }
  }, [user, navigate]);

  // Don't render anything for admin while redirecting to avoid flash of content
  if (user?.role === 'admin') return null;

  const [details, setDetails] = useState(() => {
      const addr = user?.addresses?.find(a => a.isDefault) || user?.addresses?.[0];
      const names = user?.name ? user.name.split(' ') : [];
      return {
          email: user?.email || '', 
          firstName: addr?.firstName || names[0] || '', 
          lastName: addr?.lastName || names.slice(1).join(' ') || '', 
          address: addr?.street || '', 
          city: addr?.city || '', 
          state: addr?.state || '',
          zip: addr?.zip || '', 
          country: addr?.country || country || 'United States'
      };
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
      if (!user?.addresses || user.addresses.length === 0) {
          setDetails(prev => ({ ...prev, country }));
      }
      if (user) {
          setDetails(prev => ({ ...prev, email: user.email }));
      }
  }, [country, user]);

  const selectedMethod = useMemo(() => shippingSettings.zones.find(z => z.id === shippingMethodId) || shippingSettings.zones[0], [shippingMethodId, shippingSettings]);
  
  // LOGIC: COD Fee Calculation
  const COD_FEE = 150; // Flat fee in base currency (approx)
  const codCharge = paymentMethod === 'cod' ? COD_FEE : 0;

  const shippingCost = useMemo(() => cartTotal >= shippingSettings.freeShippingThreshold ? 0 : selectedMethod.rate, [cartTotal, shippingSettings.freeShippingThreshold, selectedMethod]);
  const taxAmount = useMemo(() => (cartTotal - appliedDiscount) * (storeSettings.taxRate / 100), [cartTotal, appliedDiscount, storeSettings]);
  const grandTotal = Math.max(0, cartTotal - appliedDiscount + shippingCost + taxAmount + codCharge);

  const validateLogistics = () => {
      const newErrors: Record<string, string> = {};
      if (!details.firstName) newErrors.firstName = 'Required';
      if (!details.lastName) newErrors.lastName = 'Required';
      if (!details.email || !details.email.includes('@')) newErrors.email = 'Valid email required';
      if (!details.address) newErrors.address = 'Required';
      if (!details.city) newErrors.city = 'Required';
      if (!details.zip) newErrors.zip = 'Required';
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  };

  const validatePayment = () => {
      if (paymentMethod === 'card') {
          const newErrors: Record<string, string> = {};
          if (cardDetails.number.length < 15) newErrors.cardNumber = 'Invalid number';
          if (!cardDetails.expiry) newErrors.expiry = 'Required';
          if (cardDetails.cvc.length < 3) newErrors.cvc = 'Invalid CVC';
          if (!cardDetails.name) newErrors.cardName = 'Required';
          setErrors(newErrors);
          return Object.keys(newErrors).length === 0;
      }
      return true;
  };

  const handleNextStep = () => {
      if (currentStep === 1) {
          if (validateLogistics()) setCurrentStep(2);
      } else if (currentStep === 2) {
          if (validatePayment()) setCurrentStep(3);
      }
  };

  const handleBackStep = () => {
      if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const handleApplyCoupon = () => {
      setPromoError('');
      setPromoSuccess(false);
      if (!promoCode.trim()) return;

      const result = validateCoupon(promoCode, cartTotal);
      if (result.isValid) {
          setAppliedDiscount(result.discount);
          setPromoSuccess(true);
      } else {
          setPromoError(result.error || 'Invalid code.');
          setAppliedDiscount(0);
      }
  };

  const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsProcessing(true);
      
      const shippingAddress = {
          id: `ADDR-${Date.now()}`,
          type: 'Shipping' as const,
          firstName: details.firstName,
          lastName: details.lastName,
          street: details.address,
          city: details.city,
          state: details.state,
          zip: details.zip,
          country: details.country
      };

      const newOrder: any = {
          id: `ORD-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
          date: new Date().toLocaleDateString(),
          total: grandTotal,
          status: 'Processing',
          items: cart,
          customer: { name: `${details.firstName} ${details.lastName}`, email: details.email },
          shippingAddress: shippingAddress,
          shippingMethod: selectedMethod.name,
          paymentMethod: paymentMethod === 'cod' ? 'Cash on Delivery' : paymentMethod === 'card' ? 'Credit Card' : 'Online Payment',
          paymentIntentId: paymentMethod === 'card' ? `pi_${Math.random().toString(36).substr(2, 10)}` : (paymentMethod === 'cod' ? 'COD' : 'external_gateway'),
          breakdown: {
              subtotal: cartTotal,
              shipping: shippingCost,
              tax: taxAmount,
              discount: appliedDiscount,
              codFee: codCharge
          }
      };
      await addOrder(newOrder);
      setTimeout(() => { clearCart(); navigate('/order-confirmation', { state: { order: newOrder } }); }, 2500);
  };

  const steps = [
      { id: 1, label: 'Address' },
      { id: 2, label: 'Payment' },
      { id: 3, label: 'Confirm' }
  ];

  if (cart.length === 0) {
      return (
          <div className="min-h-screen pt-40 text-center bg-brand-cream px-6">
              <ShoppingBag size={64} className="mx-auto text-stone-200 mb-6" />
              <h1 className="font-serif text-3xl mb-4">Your bag is empty</h1>
              <Link to="/shop" className="text-brand-crimson underline uppercase text-xs font-bold tracking-widest font-sans">Shop Now</Link>
          </div>
      );
  }

  if (!isAuthenticated) {
      return (
          <div className="min-h-screen bg-brand-cream flex items-center justify-center p-6 animate-fade-in">
              <div className="max-w-md w-full bg-white p-12 rounded-[2.5rem] shadow-2xl border border-stone-100 text-center space-y-8">
                  <div className="w-16 h-16 bg-brand-black text-brand-gold rounded-3xl flex items-center justify-center mx-auto shadow-xl">
                      <Lock size={32} />
                  </div>
                  <div>
                      <h2 className="font-serif text-3xl italic text-brand-black mb-3">Please Sign In</h2>
                      <p className="text-stone-500 text-sm leading-relaxed font-light">To complete your order, please log in or create an account.</p>
                  </div>
                  <div className="space-y-4">
                      <button 
                        onClick={() => navigate('/login', { state: { from: '/checkout' } })}
                        className="w-full bg-brand-black text-white py-5 rounded-2xl font-black uppercase text-[10px] tracking-[0.4em] shadow-xl hover:bg-brand-crimson transition-all flex items-center justify-center gap-3"
                      >
                          <LogIn size={18} /> Login
                      </button>
                      <button 
                        onClick={() => navigate('/register', { state: { from: '/checkout' } })}
                        className="text-stone-400 font-black uppercase text-[9px] tracking-[0.3em] hover:text-brand-black transition-colors underline underline-offset-8"
                      >
                          Create Account
                      </button>
                  </div>
              </div>
          </div>
      )
  }

  return (
    <div className="min-h-screen bg-white animate-fade-in pb-20 font-sans">
        {isProcessing && <AuraLoader text="Placing Order..." />}
        
        <header className="pt-8 pb-6 border-b border-stone-100 px-8 lg:px-20 flex flex-col items-center sticky top-0 bg-white/95 backdrop-blur-md z-30">
            <Link to="/" className="font-display font-black text-2xl tracking-[0.2em] text-brand-black mb-6 hover:opacity-80 transition-all uppercase">{storeSettings.storeName}<span className="text-brand-crimson">.</span></Link>
            
            <div className="flex items-center gap-6 text-[10px] font-black uppercase tracking-widest">
                {steps.map((step, idx) => (
                    <React.Fragment key={step.id}>
                        <div className={`flex items-center gap-3 transition-all ${currentStep >= step.id ? 'text-brand-black' : 'text-stone-300'}`}>
                            <div className={`w-7 h-7 rounded-full border flex items-center justify-center transition-all ${currentStep >= step.id ? 'border-brand-black bg-brand-black text-white' : 'border-stone-200'}`}>
                                {currentStep > step.id ? <AnimatedCheckmark size={18} className="text-white" /> : <span className="font-display">{step.id}</span>}
                            </div>
                            <span className={currentStep === step.id ? 'opacity-100' : 'opacity-60'}>{step.label}</span>
                        </div>
                        {idx < steps.length - 1 && <div className={`w-10 h-px transition-colors duration-500 ${currentStep > step.id ? 'bg-brand-black' : 'bg-stone-200'}`} />}
                    </React.Fragment>
                ))}
            </div>
        </header>

        <div className="lg:flex flex-row-reverse max-w-[1400px] mx-auto">
            {/* Summary */}
            <div className="w-full lg:w-[40%] bg-stone-50 border-l border-stone-200 p-8 xl:p-12 h-fit lg:min-h-[calc(100vh-140px)]">
                <div className="flex justify-between items-center mb-10">
                    <h2 className="text-xs font-black uppercase tracking-[0.4em] text-stone-400">Order Summary</h2>
                    <Link to="/shop" className="text-[9px] font-black uppercase text-brand-crimson underline underline-offset-4">Change items</Link>
                </div>
                
                <div className="space-y-6 mb-8 max-h-[350px] overflow-y-auto pr-3 custom-scrollbar">
                    {cart.map(item => (
                        <div key={item.cartItemId} className="flex items-center justify-between gap-6 group">
                            <div className="flex items-center gap-5">
                                <div className="w-16 h-16 bg-white border border-stone-100 rounded-xl p-2 flex items-center justify-center shadow-sm group-hover:shadow-md transition-all">
                                    <img src={item.images[0]} alt="" className="w-full h-full object-contain" />
                                </div>
                                <div>
                                    <h4 className="font-bold text-sm text-brand-black font-serif italic text-base">{item.name}</h4>
                                    <p className="text-[10px] uppercase font-bold text-stone-400 tracking-widest">{item.size} • Qty {item.quantity}</p>
                                </div>
                            </div>
                            <p className="text-sm font-bold text-brand-black">{formatPrice(item.price * item.quantity)}</p>
                        </div>
                    ))}
                </div>

                <div className="mb-10 p-6 bg-white rounded-2xl border border-stone-200 shadow-sm relative overflow-hidden">
                    <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-3 flex items-center gap-2">
                         Apply Discount Code
                    </label>
                    <div className="flex gap-3 relative z-10">
                        <div className="relative flex-1">
                            <input 
                                type="text" 
                                value={promoCode} 
                                onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                                placeholder="PROMO CODE" 
                                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 text-xs font-bold tracking-widest outline-none focus:border-brand-black transition-all shadow-inner uppercase"
                            />
                            {promoSuccess && <div className="absolute right-4 top-1/2 -translate-y-1/2 text-green-500"><CheckCircle2 size={16} /></div>}
                        </div>
                        <button 
                            type="button" 
                            onClick={handleApplyCoupon}
                            className="bg-brand-black text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-brand-crimson transition-all shadow-xl active:scale-95"
                        >
                            Apply
                        </button>
                    </div>
                </div>

                <div className="bg-white p-8 rounded-[2rem] border border-stone-200 shadow-sm mb-8 space-y-4">
                    <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-stone-400">
                        <span>Items Total</span>
                        <span className="text-brand-black">{formatPrice(cartTotal)}</span>
                    </div>
                    {appliedDiscount > 0 && (
                        <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-green-600">
                            <span>Discount</span>
                            <span>-{formatPrice(appliedDiscount)}</span>
                        </div>
                    )}
                    <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-stone-400">
                        <span>Shipping</span>
                        <span className="text-brand-black font-black">{shippingCost === 0 ? 'FREE' : formatPrice(shippingCost)}</span>
                    </div>
                    <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-stone-400">
                        <span>Tax ({storeSettings.taxRate}%)</span>
                        <span className="text-brand-black">{formatPrice(taxAmount)}</span>
                    </div>
                    {paymentMethod === 'cod' && (
                        <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-stone-400">
                            <span>COD Fee</span>
                            <span className="text-brand-black">{formatPrice(codCharge)}</span>
                        </div>
                    )}
                    <div className="h-px bg-stone-100 my-4" />
                    <div className="flex justify-between items-center">
                        <span className="text-xs font-serif font-bold italic uppercase tracking-[0.2em] text-stone-500">Order Total</span>
                        <span className="text-3xl font-serif font-bold text-brand-crimson tracking-tighter">{formatPrice(grandTotal)}</span>
                    </div>
                </div>
            </div>

            {/* Steps */}
            <div className="flex-1 p-8 lg:p-12 xl:p-16">
                <form onSubmit={handleSubmit} className="max-w-xl mx-auto min-h-[500px] flex flex-col justify-between h-full">
                    <AnimatePresence mode="wait">
                        {currentStep === 1 && (
                            <motion.div 
                                key="step1" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}
                                className="space-y-10"
                            >
                                <div>
                                    <h3 className="text-3xl font-serif font-bold text-brand-black mb-6 italic">Shipping Address</h3>
                                    <div className="space-y-5">
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                            <InputField label="First Name" value={details.firstName} onChange={(e: any) => setDetails({...details, firstName: e.target.value})} error={errors.firstName} />
                                            <InputField label="Last Name" value={details.lastName} onChange={(e: any) => setDetails({...details, lastName: e.target.value})} error={errors.lastName} />
                                        </div>
                                        <InputField label="Email Address" type="email" value={details.email} onChange={(e: any) => setDetails({...details, email: e.target.value})} error={errors.email} />
                                        <InputField label="Street Address" value={details.address} onChange={(e: any) => setDetails({...details, address: e.target.value})} error={errors.address} />
                                        <div className="grid grid-cols-2 gap-5">
                                            <InputField label="City" value={details.city} onChange={(e: any) => setDetails({...details, city: e.target.value})} error={errors.city} />
                                            <InputField label="Zip Code" value={details.zip} onChange={(e: any) => setDetails({...details, zip: e.target.value})} error={errors.zip} />
                                        </div>
                                        <div className="grid grid-cols-2 gap-5">
                                            <InputField label="State" value={details.state} onChange={(e: any) => setDetails({...details, state: e.target.value})} />
                                            <InputField label="Country" value={details.country} onChange={(e: any) => setDetails({...details, country: e.target.value})} />
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <h3 className="text-xl font-serif font-bold text-brand-black mb-6 italic">Shipping Method</h3>
                                    <div className="space-y-3">
                                        {shippingSettings.zones.map(method => (
                                            <button key={method.id} type="button" onClick={() => setShippingMethodId(method.id)}
                                                className={`w-full text-left p-6 border-2 rounded-[1.5rem] transition-all duration-500 flex items-center justify-between group relative overflow-hidden ${shippingMethodId === method.id ? 'border-brand-black bg-stone-50 shadow-md scale-[1.01]' : 'border-stone-100 bg-white hover:border-stone-300'}`}
                                            >
                                                <div className="flex items-center gap-5 relative z-10">
                                                    <div className={`p-3 rounded-xl transition-colors duration-500 ${method.isExpress ? (shippingMethodId === method.id ? 'bg-orange-500 text-white' : 'bg-orange-50 text-orange-600') : (shippingMethodId === method.id ? 'bg-brand-black text-white' : 'bg-stone-50 text-stone-400')}`}>
                                                        {method.isExpress ? <Zap size={20} /> : <Truck size={20} />}
                                                    </div>
                                                    <div>
                                                        <p className="text-[11px] font-black uppercase tracking-[0.2em] text-brand-black">{method.name}</p>
                                                        <p className="text-[9px] text-stone-400 font-bold uppercase tracking-widest mt-1 italic">{method.deliveryTime}</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-6 relative z-10">
                                                    <span className="font-serif font-bold text-lg text-brand-black">{method.rate === 0 ? 'FREE' : formatPrice(method.rate)}</span>
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {currentStep === 2 && (
                            <motion.div 
                                key="step2" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}
                                className="space-y-10"
                            >
                                <div>
                                    <h3 className="text-3xl font-serif font-bold text-brand-black mb-8 italic">Payment Details</h3>
                                    <div className="grid grid-cols-2 gap-4 mb-8">
                                        {[
                                            { id: 'card', label: 'Credit Card', icon: CreditCard, sub: 'Secure' },
                                            { id: 'cod', label: 'Cash on Delivery', icon: Banknote, sub: '+ ' + formatPrice(COD_FEE) },
                                            { id: 'paypal', label: 'PayPal', icon: Wallet, sub: 'Express' },
                                            { id: 'bnpl', label: 'Klarna / Afterpay', icon: Hourglass, sub: '4 Interest-Free' },
                                        ].map((opt) => (
                                            <div 
                                                key={opt.id}
                                                onClick={() => setPaymentMethod(opt.id as any)}
                                                className={`p-5 border-2 rounded-[1.5rem] cursor-pointer transition-all duration-500 flex flex-col gap-2 relative overflow-hidden ${paymentMethod === opt.id ? 'border-brand-black bg-white ring-4 ring-brand-black/5 shadow-xl scale-[1.02]' : 'border-stone-100 bg-white hover:border-stone-300'}`}
                                            >
                                                <opt.icon size={20} className={paymentMethod === opt.id ? 'text-brand-crimson' : 'text-stone-300'} />
                                                <div>
                                                    <p className="text-[10px] font-black uppercase tracking-widest text-brand-black leading-tight">{opt.label}</p>
                                                    <p className="text-[8px] text-stone-400 uppercase tracking-widest mt-1">{opt.sub}</p>
                                                </div>
                                                {paymentMethod === opt.id && (
                                                    <motion.div layoutId="pay-check" className="absolute top-4 right-4 text-brand-black">
                                                        <CheckCircle2 size={16} />
                                                    </motion.div>
                                                )}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="bg-stone-50 border border-stone-200 p-8 rounded-[2rem] min-h-[300px] flex flex-col justify-center overflow-hidden shadow-inner relative">
                                        {paymentMethod === 'card' && (
                                            <div className="space-y-6 w-full">
                                                <div className="relative">
                                                    <CreditCard className="absolute left-5 top-1/2 -translate-y-1/2 text-stone-300" size={18} />
                                                    <input 
                                                        type="text" placeholder="Card Number" 
                                                        className="w-full bg-white border border-stone-200 rounded-xl px-12 py-3.5 text-sm"
                                                        value={cardDetails.number}
                                                        onChange={(e) => setCardDetails({...cardDetails, number: e.target.value.replace(/\D/g, '').substring(0, 16)})}
                                                    />
                                                </div>
                                                <div className="grid grid-cols-2 gap-5">
                                                    <InputField label="Expiry" placeholder="MM / YY" value={cardDetails.expiry} onChange={(e: any) => setCardDetails({...cardDetails, expiry: e.target.value})} error={errors.expiry} />
                                                    <InputField label="CVC" placeholder="123" maxLength={4} value={cardDetails.cvc} onChange={(e: any) => setCardDetails({...cardDetails, cvc: e.target.value})} error={errors.cvc} />
                                                </div>
                                                <InputField label="Cardholder Name" placeholder="Name on card" value={cardDetails.name} onChange={(e: any) => setCardDetails({...cardDetails, name: e.target.value.toUpperCase()})} error={errors.cardName} />
                                            </div>
                                        )}
                                        {paymentMethod === 'cod' && (
                                            <div className="text-center w-full py-6">
                                                <Banknote size={40} className="mx-auto text-brand-black mb-4 opacity-20" />
                                                <h4 className="font-serif italic text-2xl text-brand-black mb-2">Pay with Cash</h4>
                                                <p className="text-xs text-stone-500 mb-2 max-w-xs mx-auto">Please have exactly {formatPrice(grandTotal)} ready for the courier.</p>
                                                <p className="text-[10px] font-bold uppercase tracking-widest text-brand-crimson">Includes {formatPrice(COD_FEE)} handling fee</p>
                                            </div>
                                        )}
                                        {paymentMethod === 'paypal' && (
                                            <div className="text-center w-full py-6">
                                                <Wallet size={40} className="mx-auto text-blue-500 mb-4 opacity-20" />
                                                <h4 className="font-serif italic text-2xl text-brand-black mb-2">Secure PayPal Redirect</h4>
                                                <p className="text-xs text-stone-500 mb-8 max-w-xs mx-auto">You will be redirected to PayPal to complete your purchase securely.</p>
                                            </div>
                                        )}
                                        {paymentMethod === 'bnpl' && (
                                            <div className="text-center w-full py-6">
                                                <Hourglass size={40} className="mx-auto text-purple-500 mb-4 opacity-20" />
                                                <h4 className="font-serif italic text-2xl text-brand-black mb-2">Flexible Payments</h4>
                                                <p className="text-xs text-stone-500 mb-8 max-w-xs mx-auto">Pay in 4 interest-free installments of {formatPrice(grandTotal / 4)}.</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {currentStep === 3 && (
                            <motion.div 
                                key="step3" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}
                                className="space-y-10"
                            >
                                <h3 className="text-3xl font-serif font-bold text-brand-black mb-8 italic">Final Review</h3>
                                
                                <div className="bg-stone-50 border border-stone-200 rounded-[2.5rem] p-8 space-y-8 shadow-inner relative overflow-hidden">
                                    <div className="flex justify-between items-start border-b border-stone-200/50 pb-8 relative z-10">
                                        <div>
                                            <p className="text-[9px] font-black uppercase text-stone-400 tracking-[0.5em] mb-3 font-sans">Shipping To</p>
                                            <p className="font-serif font-bold text-xl text-brand-black italic">{details.firstName} {details.lastName}</p>
                                            <p className="text-xs text-stone-500 leading-relaxed italic mt-1">{details.address}, {details.city}, {details.zip}</p>
                                        </div>
                                        <button type="button" onClick={() => setCurrentStep(1)} className="text-[10px] font-bold text-brand-crimson underline uppercase tracking-widest">Edit</button>
                                    </div>
                                    
                                    <div className="flex justify-between items-start relative z-10">
                                        <div>
                                            <p className="text-[9px] font-black uppercase text-stone-400 tracking-[0.5em] mb-3 font-sans">Payment Method</p>
                                            <p className="font-serif font-bold text-xl text-brand-black italic">
                                                {paymentMethod === 'card' && 'Credit Card'}
                                                {paymentMethod === 'cod' && 'Cash on Delivery'}
                                                {paymentMethod === 'paypal' && 'PayPal'}
                                                {paymentMethod === 'bnpl' && 'Installments (BNPL)'}
                                                {paymentMethod === 'apple' && 'Apple Pay'}
                                            </p>
                                        </div>
                                        <button type="button" onClick={() => setCurrentStep(2)} className="text-[10px] font-bold text-brand-crimson underline uppercase tracking-widest">Edit</button>
                                    </div>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>

                    <div className="mt-12 pt-10 border-t border-stone-100 flex gap-4">
                        {currentStep > 1 && (
                            <button type="button" onClick={handleBackStep} className="px-10 py-5 border-2 border-stone-100 rounded-full text-[9px] font-black uppercase tracking-[0.3em] hover:border-brand-black transition-all">Back</button>
                        )}
                        
                        {currentStep < 3 ? (
                            <button type="button" onClick={handleNextStep} className="flex-1 bg-brand-black text-white py-5 rounded-full font-black uppercase tracking-[0.4em] text-[10px] shadow-lg hover:bg-brand-crimson transition-all">Next Step</button>
                        ) : (
                            <button type="submit" disabled={isProcessing} className="flex-1 bg-brand-black text-white py-5 rounded-full font-black uppercase tracking-[0.4em] text-[10px] shadow-lg hover:bg-brand-crimson transition-all">
                                {isProcessing ? <Loader2 className="animate-spin" size={20} /> : `Place Order — ${formatPrice(grandTotal)}`}
                            </button>
                        )}
                    </div>
                </form>
            </div>
        </div>
    </div>
  );
};
