
# 🚀 Aura Official Store: Deployment Guide

Follow these steps to take your store live for your business.

### 1. Infrastructure Setup
*   **Database**: Provision a Managed PostgreSQL database (e.g., on Railway, Render, or AWS RDS).
*   **Backend Hosting**: Deploy the Node.js server to a platform like Render.com, Railway.app, or Heroku.
*   **Frontend Hosting**: Deploy the React build to Vercel or Netlify.

### 2. Environment Variables (The "Must-Haves")
In your hosting provider's dashboard, set the following variables:
*   `DATABASE_URL`: Your production Postgres connection string.
*   `JWT_SECRET`: A long, unique string to secure user sessions.
*   `STRIPE_SECRET_KEY`: Your real 'Live' key from the Stripe Dashboard.
*   `FRONTEND_URL`: The final URL of your website (e.g., `https://aura-perfumes.com`).

### 3. Database Initialization
Once the backend is connected to the real DB, the `init.sql` script will run automatically. 
**To create your first Admin:**
1. Register normally on your new site.
2. Access your Database (via pgAdmin or your host's CLI).
3. Run: `UPDATE users SET role = 'admin' WHERE email = 'your-email@here.com';`

### 4. Branding & Content
*   Log in to your new site as an Admin.
*   Go to **Admin > Store Design** to update the video/image assets with your professional branding.
*   Go to **Admin > Products** to delete the mock data and bulk-upload your real inventory using the CSV template.

### 5. Domains & SSL
*   Ensure your domain is connected via CNAME/A records provided by your host.
*   Verify that HTTPS (SSL) is active. Aura is configured to only work over secure connections for payments.

---
*For technical support during the launch, contact the architect team.*
