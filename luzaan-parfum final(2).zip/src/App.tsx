
import React, { useState, useEffect } from 'react';
// @ts-ignore
import { HashRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Shop } from './pages/Shop';
import { ProductDetail } from './pages/ProductDetail';
import { Checkout } from './pages/Checkout';
import { CartDrawer } from './components/CartDrawer';
import { ShopProvider } from './context/ShopContext';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { ThemeProvider } from './context/ThemeContext';
import { CurrencyProvider } from './context/CurrencyContext'; 
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { ResetPassword } from './pages/ResetPassword';
import { Account } from './pages/Account';
import { OrderConfirmation } from './pages/OrderConfirmation';
import { About } from './pages/About';
import { Contact } from './pages/Contact';
import { Blog } from './pages/Blog';
import { BlogPost } from './pages/BlogPost'; 
import { Wishlist } from './pages/Wishlist';
import { SearchOverlay } from './components/SearchOverlay';
import { NewsletterModal } from './components/NewsletterModal';
import { SEOManager } from './components/SEOManager';
import { ScentDiscovery } from './pages/ScentDiscovery';
import { AuraLoader } from './components/AuraLoader';
import { LoginWelcomeModal } from './components/LoginWelcomeModal';
import { AnimatePresence } from 'framer-motion';

// Static Pages
import { Shipping } from './pages/Shipping';
import { FAQ } from './pages/FAQ';
import { Privacy } from './pages/Privacy';
import { Terms } from './pages/Terms';

// Admin Imports
import { AdminLayout } from './pages/admin/AdminLayout';
import { Dashboard } from './pages/admin/Dashboard';
import { Products as AdminProducts } from './pages/admin/Products';
import { Orders as AdminOrders } from './pages/admin/Orders';
import { Customers as AdminCustomers } from './pages/admin/Customers';
import { Inventory } from './pages/admin/Inventory';
import { Coupons } from './pages/admin/Coupons';
import { Reviews } from './pages/admin/Reviews';
import { SEO } from './pages/admin/SEO';
import { Analytics } from './pages/admin/Analytics';
import { Security } from './pages/admin/Security';
import { Backup } from './pages/admin/Backup';
import { Settings as AdminSettings } from './pages/admin/Settings';
import { Content as AdminContent } from './pages/admin/Content';
import { Categories } from './pages/admin/Categories';
import { Shipping as AdminShipping } from './pages/admin/Shipping';
import { Transactions } from './pages/admin/Transactions';
import { Stories as AdminStories } from './pages/admin/Stories';
import { Inbox as AdminInbox } from './pages/admin/Inbox';
import { Design as AdminDesign } from './pages/admin/Design';
import { Marketing as AdminMarketing } from './pages/admin/Marketing';
import { Comments as AdminComments } from './pages/admin/Comments';
import { Sales as AdminSales } from './pages/admin/Sales';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  React.useEffect(() => { 
    if (!pathname.startsWith('/admin')) {
      window.scrollTo(0, 0); 
    }
  }, [pathname]);
  return null;
};

const NavigationLoader = () => {
  const location = useLocation();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (location.pathname.startsWith('/admin')) {
      setLoading(false);
      return;
    }
    setLoading(true);
    const timer = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(timer);
  }, [location.pathname]);

  return (
    <AnimatePresence>
      {loading && <AuraLoader fullScreen={true} />}
    </AnimatePresence>
  );
};

const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const path = location.pathname.toLowerCase();
  
  const isAdminRoute = path.startsWith('/admin');
  const isCheckoutRoute = path.startsWith('/checkout');

  const showGlobalNav = !isAdminRoute && !isCheckoutRoute;

  return (
    <div className="flex flex-col min-h-screen font-sans transition-colors duration-500 bg-brand-cream text-brand-black selection:bg-brand-black selection:text-white">
      <SEOManager />
      <NavigationLoader />
      <LoginWelcomeModal />
      {showGlobalNav && <Navbar />}
      {showGlobalNav && <CartDrawer />}
      {showGlobalNav && <SearchOverlay />}
      {showGlobalNav && <NewsletterModal />}
      <main className="flex-grow">{children}</main>
      {showGlobalNav && <Footer />}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <LanguageProvider>
          <CurrencyProvider>
            <ShopProvider>
              <Router>
                <ScrollToTop />
                <MainLayout>
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/shop" element={<Shop />} />
                    <Route path="/welcome" element={<Navigate to="/" replace />} />
                    <Route path="/product/:id" element={<ProductDetail />} />
                    <Route path="/checkout" element={<Checkout />} />
                    <Route path="/order-confirmation" element={<OrderConfirmation />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/reset-password" element={<ResetPassword />} />
                    <Route path="/account" element={<Account />} />
                    <Route path="/wishlist" element={<Wishlist />} />
                    <Route path="/discovery" element={<ScentDiscovery />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/blog/:id" element={<BlogPost />} /> 
                    <Route path="/blog" element={<Blog />} />
                    <Route path="/shipping" element={<Shipping />} />
                    <Route path="/faq" element={<FAQ />} />
                    <Route path="/privacy" element={<Privacy />} />
                    <Route path="/terms" element={<Terms />} />
                    
                    <Route path="/admin" element={<AdminLayout />}>
                      <Route index element={<Dashboard />} />
                      <Route path="sales" element={<AdminSales />} />
                      <Route path="inbox" element={<AdminInbox />} />
                      <Route path="products" element={<AdminProducts />} />
                      <Route path="categories" element={<Categories />} />
                      <Route path="orders" element={<AdminOrders />} />
                      <Route path="customers" element={<AdminCustomers />} />
                      <Route path="design" element={<AdminDesign />} /> 
                      <Route path="marketing" element={<AdminMarketing />} />
                      <Route path="inventory" element={<Inventory />} />
                      <Route path="coupons" element={<Coupons />} />
                      <Route path="transactions" element={<Transactions />} />
                      <Route path="shipping" element={<AdminShipping />} />
                      <Route path="reviews" element={<Reviews />} />
                      <Route path="stories" element={<AdminStories />} />
                      <Route path="comments" element={<AdminComments />} />
                      <Route path="content" element={<AdminContent />} />
                      <Route path="seo" element={<SEO />} />
                      <Route path="analytics" element={<Analytics />} />
                      <Route path="security" element={<Security />} />
                      <Route path="backups" element={<Backup />} />
                      <Route path="settings" element={<AdminSettings />} />
                    </Route>
                    
                    <Route path="*" element={<div className="h-screen flex items-center justify-center font-serif text-xl">404 | Page Not Found</div>} />
                  </Routes>
                </MainLayout>
              </Router>
            </ShopProvider>
          </CurrencyProvider>
        </LanguageProvider>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;
