
export interface ProductVariant {
  size: string;
  price: number;
  compareAtPrice?: number;
  sku?: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface SeoConfig {
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string[];
  canonicalUrl?: string;
  noIndex?: boolean;
  faqs?: FAQItem[];
}

export interface Product {
  id: string;
  sku: string; // Archive Identifier
  name: string;
  tagline: string;
  price: number;
  compareAtPrice?: number;
  description: string;
  notes: {
    top: string[];
    heart: string[];
    base: string[];
  };
  size: string;
  sizes?: string[]; 
  variants?: ProductVariant[];
  images: string[];
  category: string; 
  isNew?: boolean;
  isBestSeller?: boolean;
  isLimitedEdition?: boolean;
  badge?: string;
  stock?: number;
  rating?: number;
  reviewCount?: number;
  color?: string;
  highlights?: string[];
  tags?: string[];
  isActive?: boolean;
  seo?: SeoConfig; // New SEO Field
  specs?: {
    concentration?: string; // e.g. "Eau de Parfum (20% Oil)"
    longevity?: string; // e.g. "8-10 Hours"
    sillage?: string; // e.g. "Moderate to Heavy"
    season?: string; // e.g. "Winter, Evening"
  };
}

export interface InventoryLog {
  id: string;
  productName: string;
  change: number;
  reason: string;
  date: string;
}

export interface Backup {
  id: string;
  filename: string;
  date: string;
  size: string;
  type: string;
}

export interface SecuritySettings {
  twoFactor: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image?: string;
  productCount?: number;
}

export interface CartItem extends Product {
  quantity: number;
  cartItemId: string; 
}

export interface Address {
  id: string;
  type: 'Billing' | 'Shipping';
  firstName: string;
  lastName: string;
  street: string;
  city: string;
  state?: string;
  zip: string;
  country: string;
  isDefault?: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role?: 'admin' | 'user';
  totalSpent?: number;
  ordersCount?: number;
  photoURL?: string;
  provider?: 'google' | 'email';
  joinDate?: string;
  addresses?: Address[];
  isSubscribed?: boolean;
  region?: string; 
}

export interface Order {
  id: string;
  date: string;
  total: number;
  status: 'Processing' | 'Shipped' | 'Delivered' | 'Pending' | 'Cancelled';
  items: CartItem[];
  customer: {
    name: string;
    email: string;
  };
  shippingAddress?: Address;
  paymentIntentId?: string;
  trackingNumber?: string;
  paymentMethod?: string;
  breakdown?: {
      subtotal: number;
      shipping: number;
      tax: number;
      discount: number;
      codFee: number;
  };
}

export interface NewsletterConfig {
  enabled: boolean;
  title: string;
  subtitle: string;
  image: string;
  offerText: string;
  buttonText: string;
  code: string;
}

export interface SiteContent {
  shipping: string;
  privacy: string;
  terms: string;
  newsletter: NewsletterConfig;
}

export interface ContactDetails {
  addressLine1: string;
  addressLine2: string;
  phone: string;
  hours: string;
  hoursSat: string;
}

export interface StoreSettings {
  storeName: string;
  supportEmail: string;
  currency: string;
  taxRate: number;
  enableReviews: boolean;
  enableGuestCheckout: boolean;
  stripePublicKey?: string;
  stripeSecretKey?: string;
  geminiApiKey?: string;
  emailProviderApiKey?: string;
  shippingApiKey?: string;
  shippingProvider?: 'shippo' | 'easypost' | 'manual';
  contactDetails: ContactDetails;
  socialLinks: {
    instagram: string;
    facebook: string;
    twitter: string;
  };
}

export interface HeroSlide {
  id: string;
  line1: string;
  line2: string;
  quote: string;
  image: string;
}

export interface DesignSettings {
  siteLogo?: string;
  siteFavicon?: string;
  siteGrainIntensity?: number;
  announcementBarText: string;
  announcementBarActive: boolean;
  announcementBarLink?: string;
  heroVideo: string;
  heroOverlayOpacity: number;
  heroOverlayColor: string;
  heroShowAnimation: boolean;
  heroShowSpotlight: boolean;
  heroSpotlightColor: string;
  marqueeText: string;
  heroSlides?: HeroSlide[]; 
  featureNewImage?: string;
  featureBestSellerImage?: string;
  museImage?: string;
  philosophyImage?: string;
  homeJournalImage?: string;
  heroBtnText: string;
  heroSecondaryBtnText: string;
  heroSecondaryBtnLink?: string;
  heroSubtitle?: string;
  heroDescription: string;
  homeSection1Title?: string;
  homeSection1Subtitle?: string;
  homeSection2Title?: string;
  homeSection2Subtitle?: string;
  homeSection3Title?: string;
  homeSection3Subtitle?: string;
  homeSection4Title?: string;
  homeSection4Subtitle?: string;
  homeMuseTitle?: string;
  homeMuseSubtitle?: string;
  footerImage?: string;
  shopBannerImage?: string;
  shopTitle?: string;
  aboutHeroImage?: string;
  aboutTitle?: string;
  aboutText?: string;
  contactBgImage?: string;
  blogHeaderImage?: string;
  contactTitle?: string;
  contactSubtitle?: string;
  contactSection1Title?: string;
  contactSection2Title?: string;
  contactSection3Title?: string;
}

// NEW TYPES FOR SEO/AEO
export interface KeywordMetric {
  keyword: string;
  volume: number; // Avg monthly searches
  difficulty: number; // 0-100
  position: number; // Current ranking
  intent: 'Transactional' | 'Informational' | 'Navigational';
  history?: number[]; // Array of daily search volumes for chart
}

export interface CustomMetaTag {
  id: string;
  name: string; // e.g., "google-site-verification"
  content: string;
}

export interface AEOSettings {
  brandAlternateNames: string[]; // e.g. ["Luzaan Scents", "Luzaan India"]
  founderName: string;
  foundingDate: string;
  priceRange: string; // e.g. "$$$"
  areaServed: string;
  knowsAbout: string[]; // e.g. ["Perfumery", "Oud", "Attar"]
}

export interface SeoSettings {
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  ogImage: string;
  twitterHandle: string;
  robotsTxt: string;
  // New Fields
  targetKeywords: KeywordMetric[];
  customMetaTags: CustomMetaTag[];
  aeoSettings: AEOSettings;
}

export interface ShippingConfig {
  freeShippingThreshold: number;
  enableInternational: boolean;
  apiProvider?: 'shippo' | 'easypost' | 'fedex_api' | 'manual';
  apiKey?: string;
  returnLabelEnabled?: boolean;
  carriers: {
    fedex: boolean;
    dhl: boolean;
    ups: boolean;
    usps: boolean;
  };
  zones: {
    id: string;
    name: string;
    rate: number;
    deliveryTime: string;
    isExpress?: boolean;
  }[];
}

export interface AdminActivity {
  id: string;
  userName: string;
  action: string;
  details: string;
  ipAddress: string;
  date: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  date: string;
  status: 'unread' | 'read';
}

export interface Coupon {
  id: string;
  code: string;
  description?: string;
  discountType: 'percent' | 'fixed';
  value: number;
  minOrderValue: number;
  expiryDate: string;
  status: 'active' | 'expired';
  usageCount: number;
}

export interface GSCData {
  clicks: number;
  impressions: number;
  ctr: number;
  position: number;
  queries: { query: string; clicks: number; impressions: number; position: number }[];
  pages: { url: string; clicks: number; impressions: number; position: number }[];
}

export interface ShopContextType {
  products: Product[];
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  bulkUpdateStock: (productIds: string[], newStock: number) => Promise<void>;
  categories: Category[];
  addCategory: (category: Category) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (id: string) => void;
  cart: CartItem[];
  wishlist: Product[];
  isCartOpen: boolean;
  isSearchOpen: boolean;
  addToCart: (product: Product, quantity?: number, openDrawer?: boolean, variantSize?: string) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, quantity: number) => void;
  toggleCart: () => void;
  toggleSearch: () => void;
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  addOrder: (order: Order) => Promise<boolean>;
  reviews: Review[];
  addReview: (review: Review) => void;
  updateReviewStatus: (id: string, status: Review['status']) => void;
  getProductReviews: (productId: string) => Review[];
  blogComments: BlogComment[];
  addBlogComment: (comment: BlogComment) => void;
  updateBlogCommentStatus: (id: string, status: BlogComment['status']) => void;
  deleteBlogComment: (id: string) => void;
  adminProducts: Product[]; 
  adminOrders: Order[];
  adminCustomers: User[];
  addCustomer: (user: User) => void;
  updateCustomer: (user: User) => void;
  updateOrderStatus: (orderId: string, status: Order['status'], trackingNumber?: string) => void;
  adminActivityLogs: AdminActivity[];
  logAdminActivity: (action: string, details: string) => void;
  adminMessages: ContactMessage[];
  sendContactMessage: (msg: Omit<ContactMessage, 'id' | 'date' | 'status'>) => Promise<boolean>;
  markMessageAsRead: (id: string) => void;
  coupons: Coupon[];
  addCoupon: (coupon: Coupon) => void;
  updateCoupon: (coupon: Coupon) => void;
  deleteCoupon: (id: string) => void;
  validateCoupon: (code: string, orderTotal: number) => { isValid: boolean; discount: number; error?: string };
  claimPendingCart: () => void;
  storeSettings: StoreSettings;
  updateStoreSettings: (settings: Partial<StoreSettings>) => void;
  designSettings: DesignSettings;
  updateDesignSettings: (settings: Partial<DesignSettings>) => void;
  seoSettings: SeoSettings;
  updateSeoSettings: (settings: Partial<SeoSettings>) => void;
  shippingSettings: ShippingConfig;
  updateShippingSettings: (settings: Partial<ShippingConfig>) => void;
  blogPosts: BlogPost[];
  addBlogPost: (post: BlogPost) => void;
  updateBlogPost: (post: BlogPost) => void;
  deleteBlogPost: (id: string) => void;
  siteContent: SiteContent;
  updateSiteContent: (section: keyof SiteContent, content: string | NewsletterConfig) => void;
  securitySettings: SecuritySettings;
  updateSecuritySettings: (settings: Partial<SecuritySettings>) => void;
  blockedIPs: string[];
  addBlockedIP: (ip: string) => void;
  removeBlockedIP: (ip: string) => void;
  restoreSystem: (data: any) => Promise<boolean>;
  gscData: GSCData;
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password?: string) => Promise<User | null>;
  loginWithGoogle: () => Promise<User>;
  register: (name: string, email: string, region?: string, password?: string) => Promise<User>;
  updateUser: (data: Partial<User>) => Promise<void>;
  requestPasswordReset: (email: string) => Promise<{ success: boolean; message: string }>;
  confirmPasswordReset: (email: string, newPassword: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
  showWelcomeModal: boolean;
  setShowWelcomeModal: (show: boolean) => void;
}

export interface Review {
  id: string;
  productId: string;
  productName: string;
  userName: string;
  rating: number;
  comment: string;
  status: 'approved' | 'pending' | 'rejected';
  date: string;
}

export interface BlogComment {
  id: string;
  postId: string;
  postTitle?: string;
  userName: string;
  email: string;
  comment: string;
  date: string;
  status: 'approved' | 'pending' | 'rejected';
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string; 
  date: string;
  image: string;
  category: string;
  readTime: string;
}
