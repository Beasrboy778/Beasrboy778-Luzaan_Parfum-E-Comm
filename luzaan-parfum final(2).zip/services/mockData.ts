
import { Product, BlogPost, Order, Category } from '../types';

export const CATEGORIES: Category[] = [
  { id: 'all', name: 'Shop All', slug: 'all', productCount: 23 },
  { id: 'men', name: 'Men', slug: 'men', productCount: 6 },
  { id: 'women', name: 'Women', slug: 'women', productCount: 6 },
  { id: 'unisex', name: 'Unisex', slug: 'unisex', productCount: 6 },
  { id: 'attar', name: 'Attar', slug: 'attar', productCount: 5 },
];

export const PRODUCTS: Product[] = [
  // --- FEATURED ---
  {
    id: 'f1', sku: 'LZ-OUD-FEAT', name: 'Purple Oud', tagline: 'Where Mystery Meets Elegance', price: 245, compareAtPrice: 280,
    description: 'A deep, resinous oud lightened by spiced violet and dark plum. A scent of absolute authority.',
    notes: { top: ['Black Pepper', 'Plum'], heart: ['Violet', 'Saffron'], base: ['Aged Oud', 'Leather'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1583445013765-48c2201c8144?auto=format&fit=crop&w=800&q=80'],
    category: 'Unisex', isNew: true, isBestSeller: false, isLimitedEdition: true, stock: 25, rating: 5.0, color: '#4B0082', tags: ['Oud-based', 'Limited Edition']
  },
  // --- MEN ---
  {
    id: 'm1', sku: 'LZ-WOOD-01', name: 'Midnight Wood', tagline: 'Deep and spicy for the night', price: 185, compareAtPrice: 225,
    description: 'A strong scent that feels like a warm night. It mixes rich wood with spicy incense.',
    notes: { top: ['Bergamot', 'Saffron'], heart: ['Rose', 'Oud Wood'], base: ['Amber', 'Musk'] },
    size: '100ml', sizes: ['50ml', '100ml'], images: ['https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=800&q=80'],
    category: 'Men', isBestSeller: true, stock: 120, rating: 4.8, reviewCount: 42, color: '#2D2926', tags: ['Woody', 'Spicy', 'Signature']
  },
  {
    id: 'm2', sku: 'LZ-PEPR-01', name: 'Obsidian Pepper', tagline: 'Sharp, electric, and cold', price: 145,
    description: 'A bracing combination of black pepper and frosted mint over a cedar base.',
    notes: { top: ['Black Pepper'], heart: ['Mint', 'Geranium'], base: ['Cedar', 'Vetiver'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80'],
    category: 'Men', isNew: true, stock: 85, rating: 4.6, color: '#1A1A1A', tags: ['Fresh', 'Spicy', 'New Arrival']
  },
  {
    id: 'm3', sku: 'LZ-TOBC-01', name: 'Tobacco Reserve', tagline: 'Smoky library vibes', price: 210,
    description: 'Hand-cured tobacco leaves infused with vanilla and rare spices.',
    notes: { top: ['Ginger'], heart: ['Tobacco', 'Cocoa'], base: ['Vanilla', 'Dried Fruits'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1583445013765-48c2201c8144?auto=format&fit=crop&w=800&q=80'],
    category: 'Men', isBestSeller: true, stock: 40, rating: 4.9, color: '#4E3629', tags: ['Smoky', 'Oriental', 'Signature']
  },
  {
    id: 'm4', sku: 'LZ-LTHR-01', name: 'Aegean Leather', tagline: 'Salted skin and luxury', price: 195,
    description: 'Sea salt spray meeting Italian leather on a private yacht.',
    notes: { top: ['Sea Salt'], heart: ['Leather', 'Juniper'], base: ['Ambergris'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1547887538-e3a2f32cb1cc?auto=format&fit=crop&w=800&q=80'],
    category: 'Men', stock: 15, rating: 4.7, color: '#2B3D4F', tags: ['Leather', 'Fresh']
  },
  {
    id: 'm5', sku: 'LZ-SANT-01', name: 'Santal Noir', tagline: 'The king of woods', price: 230,
    description: 'A creamy, meditative sandalwood with a hint of dark cardamom.',
    notes: { top: ['Cardamom'], heart: ['Iris', 'Violet'], base: ['Sandalwood', 'Papyrus'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=800&q=80'],
    category: 'Men', isLimitedEdition: true, stock: 22, rating: 5.0, color: '#3C2F2F', tags: ['Woody', 'Bestseller', 'Limited']
  },
  {
    id: 'm6', sku: 'LZ-BIRH-01', name: 'Silver Birch', tagline: 'Mountain air in a bottle', price: 150,
    description: 'Crisp, clean air from a birch forest high in the Alps.',
    notes: { top: ['Grapefruit'], heart: ['Birch Leaves'], base: ['White Oakmoss'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80'],
    category: 'Men', stock: 65, rating: 4.5, color: '#E5E4E2', tags: ['Fresh', 'Floral']
  },

  // --- WOMEN ---
  {
    id: 'w1', sku: 'LZ-ROSE-01', name: 'Crimson Rose', tagline: 'A sweet flower scent', price: 160, compareAtPrice: 190,
    description: 'A smooth version of a classic rose smell. Romantic and dark.',
    notes: { top: ['Mandarin'], heart: ['Damask Rose'], base: ['Vanilla', 'Cedarwood'] },
    size: '50ml', sizes: ['30ml', '50ml', '100ml'], images: ['https://images.unsplash.com/photo-1557170334-a9632e77c6e4?auto=format&fit=crop&w=800&q=80'],
    category: 'Women', isNew: true, stock: 45, rating: 4.5, reviewCount: 28, color: '#660F1A', tags: ['Floral', 'New Arrival']
  },
  {
    id: 'w2', sku: 'LZ-JASM-01', name: 'Velvet Jasmine', tagline: 'Midnight in Grasse', price: 175,
    description: 'Opulent white florals blooming under the moonlight.',
    notes: { top: ['Neroli'], heart: ['Jasmine Sambac'], base: ['White Musk'] },
    size: '50ml', images: ['https://images.unsplash.com/photo-1590736704728-f4730bb30770?auto=format&fit=crop&w=800&q=80'],
    category: 'Women', isBestSeller: true, stock: 60, rating: 4.8, color: '#FDF5E6', tags: ['Floral', 'Signature']
  },
  {
    id: 'w3', sku: 'LZ-AMBR-01', name: 'Ambre d\'Or', tagline: 'Liquid sunlight', price: 190,
    description: 'A warm, resinous amber with honeyed facets and soft spice.',
    notes: { top: ['Cinnamon'], heart: ['Labdanum'], base: ['Amber', 'Benzoin'] },
    size: '50ml', images: ['https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=800&q=80'],
    category: 'Women', stock: 30, rating: 4.7, color: '#CFA75E', tags: ['Oriental', 'Woody']
  },
  {
    id: 'w4', sku: 'LZ-PONY-01', name: 'Peony Silk', tagline: 'Soft, airy radiance', price: 135,
    description: 'Delicate peonies and red apple crispness on a bed of suede.',
    notes: { top: ['Red Apple'], heart: ['Peony', 'Gillyflower'], base: ['Suede'] },
    size: '50ml', images: ['https://images.unsplash.com/photo-1590736704728-f4730bb30770?auto=format&fit=crop&w=800&q=80'],
    category: 'Women', stock: 55, rating: 4.4, color: '#FFB7C5', tags: ['Fresh', 'Floral']
  },
  {
    id: 'w5', sku: 'LZ-ORCH-01', name: 'Mystic Orchid', tagline: 'Rare, dark, and seductive', price: 215,
    description: 'Black orchids and plum over an earthy patchouli base.',
    notes: { top: ['Plum'], heart: ['Black Orchid'], base: ['Patchouli', 'Incense'] },
    size: '50ml', images: ['https://images.unsplash.com/photo-1557170334-a9632e77c6e4?auto=format&fit=crop&w=800&q=80'],
    category: 'Women', isLimitedEdition: true, stock: 12, rating: 4.9, color: '#4B0082', tags: ['Oriental', 'Floral', 'Limited']
  },
  {
    id: 'w6', sku: 'LZ-AZUR-01', name: 'Azure Nectar', tagline: 'Sweet coastal breeze', price: 165,
    description: 'Honeysuckle and nectarine mixing with the cool air of the French Riviera.',
    notes: { top: ['Nectarine'], heart: ['Honeysuckle'], base: ['Acacia Honey'] },
    size: '50ml', images: ['https://images.unsplash.com/photo-1590736704728-f4730bb30770?auto=format&fit=crop&w=800&q=80'],
    category: 'Women', stock: 42, rating: 4.6, color: '#F0FFFF', tags: ['Fresh', 'Floral']
  },

  // --- UNISEX ---
  {
    id: 'u1', sku: 'LZ-RSNT-01', name: 'Royal Santal', tagline: 'Calm and woody', price: 210,
    description: 'Creamy sandalwood mixed with warm spices.',
    notes: { top: ['Cardamom'], heart: ['Iris'], base: ['Sandalwood'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80'],
    category: 'Unisex', isBestSeller: true, stock: 8, rating: 4.9, reviewCount: 15, color: '#D2B48C', tags: ['Woody', 'Signature']
  },
  {
    id: 'u2', sku: 'LZ-LINN-01', name: 'Linen Vibe', tagline: 'Freshly laundered luxury', price: 120,
    description: 'The smell of clean white sheets drying in a citrus grove.',
    notes: { top: ['Lemon'], heart: ['Cotton Flower'], base: ['Clean Musk'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1200&q=95'],
    category: 'Unisex', isNew: true, stock: 110, rating: 4.3, color: '#E0FFFF', tags: ['Fresh', 'Bestseller', 'New Arrival']
  },
  {
    id: 'u3', sku: 'LZ-FIGG-01', name: 'Wild Fig', tagline: 'The whole tree captured', price: 155,
    description: 'Green leaves, milky fruit, and dry wood.',
    notes: { top: ['Fig Leaf'], heart: ['Fig Fruit'], base: ['Cedarwood'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80'],
    category: 'Unisex', isNew: true, stock: 40, rating: 4.6, color: '#228B22', tags: ['Fresh', 'Woody', 'New Arrival']
  },
  {
    id: 'u4', sku: 'LZ-DTEA-01', name: 'Desert Tea', tagline: 'Smoky, herbal, and dry', price: 180,
    description: 'Black tea infused with cardamom and light smoke.',
    notes: { top: ['Bergamot'], heart: ['Black Tea'], base: ['Tobacco'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1200&q=95'],
    category: 'Unisex', isLimitedEdition: true, stock: 25, rating: 4.7, color: '#A0522D', tags: ['Smoky', 'Fresh', 'Limited']
  },
  {
    id: 'u5', sku: 'LZ-OZNE-01', name: 'Ozone Bloom', tagline: 'After the storm', price: 165,
    description: 'The smell of lightning-charged air and crushed herbs.',
    notes: { top: ['Aldehydes'], heart: ['Rain Notes'], base: ['Moss'] },
    size: '100ml', images: ['https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80'],
    category: 'Unisex', stock: 33, rating: 4.5, color: '#708090', tags: ['Fresh', 'Woody']
  },

  // --- ATTAR ---
  {
    id: 'a1', sku: 'LZ-ATT-OUD', name: 'Oud Al-Majed', tagline: 'Traditional pure oil', price: 295, compareAtPrice: 350,
    description: 'A pure, thick perfume oil that lasts for days.',
    notes: { top: ['Aged Oud'], heart: ['Saffron'], base: ['Musk'] },
    size: '12ml', images: ['https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1200&q=95'],
    category: 'Attar', isBestSeller: true, stock: 20, rating: 4.7, reviewCount: 31, color: '#3D3A36', tags: ['Alcohol-Free', 'Oud-based', 'Signature']
  },
  {
    id: 'a2', sku: 'LZ-ATT-MUSK', name: 'White Musk Royal', tagline: 'Purity in a drop', price: 95,
    description: 'The cleanest, softest musk available. Highly concentrated.',
    notes: { top: ['Lily'], heart: ['White Musk'], base: ['Powder'] },
    size: '12ml', images: ['https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1200&q=95'],
    category: 'Attar', stock: 200, rating: 4.8, color: '#F8F8FF', tags: ['Alcohol-Free', 'Floral']
  },
  {
    id: 'a3', sku: 'LZ-ATT-SAFR', name: 'Saffron Mukhallat', tagline: 'Spicy Arabian blend', price: 140,
    description: 'A rich mixture of rose, saffron, and deer musk (ethical alternative).',
    notes: { top: ['Saffron'], heart: ['Turkish Rose'], base: ['Sandalwood'] },
    size: '12ml', images: ['https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1200&q=95'],
    category: 'Attar', isNew: true, stock: 15, rating: 4.6, color: '#DAA520', tags: ['Alcohol-Free', 'Spicy', 'New Arrival']
  },
  {
    id: 'a4', sku: 'LZ-ATT-AMBR', name: 'Ambergris Pure', tagline: 'The ocean\'s treasure', price: 350,
    description: 'Extremely rare and aged ambergris oil. Salty and sweet.',
    notes: { top: ['Brine'], heart: ['Ambergris'], base: ['Marine'] },
    size: '3ml', images: ['https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1200&q=95'],
    category: 'Attar', stock: 5, rating: 5.0, isLimitedEdition: true, color: '#BDB76B', tags: ['Alcohol-Free', 'Limited Edition']
  },
  {
    id: 'a5', sku: 'LZ-ATT-VETY', name: 'Vetyver Absolute', tagline: 'Rooted and earthy', price: 110,
    description: 'The finest distillation of Haitian vetyver roots.',
    notes: { top: ['Citrus'], heart: ['Roots'], base: ['Soil', 'Wood'] },
    size: '12ml', images: ['https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1200&q=95'],
    category: 'Attar', stock: 18, rating: 4.7, color: '#556B2F', tags: ['Alcohol-Free', 'Woody']
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: '1',
    title: 'The Art of Layering',
    excerpt: 'Learn how to combine scents to create a unique olfactory signature that is purely your own.',
    content: `<p>Scents are personal, but layering takes that to a new level...</p>`,
    date: 'Oct 28, 2023',
    image: 'https://images.unsplash.com/photo-1615529452077-cfc99480a716?auto=format&fit=crop&w=800&q=80',
    category: 'Guides',
    readTime: '4 min read'
  },
  {
    id: '2',
    title: 'Sourcing the Sacred: Oud',
    excerpt: 'Journey with us to the forests of Southeast Asia to discover the origin of the "Liquid Gold" of perfumery.',
    content: `<p>Oud, or Agarwood, is one of the most expensive raw materials in the world...</p>`,
    date: 'Oct 15, 2023',
    image: 'https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=800&q=80',
    category: 'Behind the Scenes',
    readTime: '6 min read'
  },
  {
    id: '3',
    title: 'The Alchemy of Distillation',
    excerpt: 'How raw botanicals are transformed into pure essence through the ancient practice of steam distillation.',
    content: `<p>The transformation from petal to oil is a ritual of heat and time...</p>`,
    date: 'Nov 02, 2023',
    image: 'https://images.unsplash.com/photo-1605613309494-844bca01e741?auto=format&fit=crop&w=800&q=80',
    category: 'Heritage',
    readTime: '8 min read'
  },
  {
    id: '4',
    title: 'The Grasse Rebellion',
    excerpt: 'Why modern perfumery is returning to its roots in the floral fields of southern France.',
    content: `<p>In the hills of Grasse, a new generation of artisans is fighting to preserve tradition...</p>`,
    date: 'Dec 12, 2023',
    image: 'https://images.unsplash.com/photo-1590736704728-f4730bb30770?auto=format&fit=crop&w=800&q=80',
    category: 'Stories',
    readTime: '5 min read'
  },
  {
    id: '5',
    title: 'The Scent of Memory',
    excerpt: 'How certain molecules can unlock vivid recollections from our deepest consciousness.',
    content: `<p>Olfaction is the only sense directly wired to the amygdala...</p>`,
    date: 'Jan 05, 2024',
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80',
    category: 'Philosophy',
    readTime: '7 min read'
  },
  {
    id: '6',
    title: 'Sustainable Luxury',
    excerpt: 'Exploring the ethical challenges of sourcing rare natural ingredients in a changing world.',
    content: `<p>At Luzaan, we believe that true luxury must be kind to the earth...</p>`,
    date: 'Feb 14, 2024',
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80',
    category: 'Heritage',
    readTime: '9 min read'
  }
];

export const MOCK_ORDERS: Order[] = [
  {
    id: 'ORD-1001',
    date: 'Oct 24, 2023',
    total: 185.00,
    status: 'Processing',
    items: [{ ...PRODUCTS[0], quantity: 1, cartItemId: 'm1-100ml' }],
    customer: { name: 'Archivist Prime', email: 'admin@luzaan.com' }
  }
];
