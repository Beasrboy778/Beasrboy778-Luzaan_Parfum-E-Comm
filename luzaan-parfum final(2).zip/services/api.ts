
// Automatically determine the API endpoint
const getBaseUrl = () => {
    // Check if explicitly provided in environment
    const envUrl = (import.meta as any).env?.VITE_API_URL;
    if (envUrl) return envUrl;

    // Default to production domain logic or localhost
    if (typeof window !== 'undefined') {
        const hostname = window.location.hostname;
        if (hostname === 'localhost' || hostname === '127.0.0.1') {
            return 'http://localhost:4000/api';
        }
        // Assume API is on a subdomain 'api.yourdomain.com' or relative path
        return `${window.location.origin}/api`;
    }
    return 'http://localhost:4000/api';
};

const API_URL = getBaseUrl();

export const api = {
  // --- AUTH ---
  login: async (credentials: any) => {
    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials)
      });
      const data = await res.json();
      return { status: res.status, data };
    } catch (e) {
      return { status: 500, data: { error: 'Connection failure to Aura servers.' } };
    }
  },

  register: async (userData: any) => {
    try {
      const res = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData)
      });
      const data = await res.json();
      return { status: res.status, data };
    } catch (e) {
      return { status: 500, data: { error: 'Registration service unavailable.' } };
    }
  },

  // --- PRODUCTS ---
  getProducts: async () => {
    try {
      const res = await fetch(`${API_URL}/products`);
      if (!res.ok) throw new Error();
      return await res.json();
    } catch (e) { return null; }
  },
  
  createProduct: async (product: any) => {
    try {
      const res = await fetch(`${API_URL}/products`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
      });
      return await res.json();
    } catch (e) { return null; }
  },

  updateProduct: async (product: any) => {
    try {
      const res = await fetch(`${API_URL}/products/${product.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
      });
      return await res.json();
    } catch (e) { return null; }
  },

  deleteProduct: async (id: string) => {
    try {
      const res = await fetch(`${API_URL}/products/${id}`, { method: 'DELETE' });
      return res.ok;
    } catch (e) { return false; }
  },

  // --- CATEGORIES ---
  getCategories: async () => {
    try {
      const res = await fetch(`${API_URL}/categories`);
      if (!res.ok) throw new Error();
      return await res.json();
    } catch (e) { return null; }
  },

  createCategory: async (category: any) => {
    try {
      const res = await fetch(`${API_URL}/categories`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(category)
      });
      return await res.json();
    } catch (e) { return null; }
  },

  deleteCategory: async (id: string) => {
    try {
      const res = await fetch(`${API_URL}/categories/${id}`, { method: 'DELETE' });
      return res.ok;
    } catch (e) { return false; }
  },

  // --- ORDERS ---
  getOrders: async () => {
    try {
      const res = await fetch(`${API_URL}/admin/orders`);
      if (!res.ok) throw new Error();
      return await res.json();
    } catch (e) { return null; }
  },

  createOrder: async (orderData: any) => {
    try {
        const res = await fetch(`${API_URL}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        return await res.json();
    } catch (e) { return null; }
  },

  updateOrderStatus: async (id: string, status: string) => {
    try {
      await fetch(`${API_URL}/orders/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
    } catch (e) { console.error('Order status sync failed.'); }
  },

  // --- REVIEWS (REAL WORLD) ---
  getAllReviews: async () => {
    try {
      const res = await fetch(`${API_URL}/admin/reviews`);
      if (!res.ok) throw new Error();
      return await res.json();
    } catch (e) { return null; }
  },

  getProductReviews: async (productId: string) => {
    try {
      const res = await fetch(`${API_URL}/products/${productId}/reviews`);
      if (!res.ok) throw new Error();
      return await res.json();
    } catch (e) { return []; }
  },

  createReview: async (review: any) => {
    try {
      const res = await fetch(`${API_URL}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(review)
      });
      return res.ok;
    } catch (e) { return false; }
  },

  updateReviewStatus: async (id: string, status: string) => {
    try {
      await fetch(`${API_URL}/admin/reviews/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
    } catch (e) { console.error('Review status sync failed.'); }
  },

  // --- MESSAGES ---
  sendMessage: async (msg: any) => {
    try {
      const res = await fetch(`${API_URL}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg)
      });
      return res.ok;
    } catch (e) { return false; }
  },

  getMessages: async () => {
    try {
      const res = await fetch(`${API_URL}/admin/messages`);
      if (!res.ok) throw new Error();
      return await res.json();
    } catch (e) { return null; }
  },

  markMessageRead: async (id: string) => {
    try {
      await fetch(`${API_URL}/admin/messages/${id}/read`, { method: 'PUT' });
    } catch (e) { console.error('Message status sync failed.'); }
  },

  // --- PAYMENTS ---
  createPaymentIntent: async (amount: number) => {
    try {
      const res = await fetch(`${API_URL}/create-payment-intent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount })
      });
      return await res.json();
    } catch (e) { return { error: 'Payment gateway initialization failed.' }; }
  },

  // --- ACTIVITY ---
  getAdminActivity: async () => {
    try {
      const res = await fetch(`${API_URL}/admin/activity`);
      if (!res.ok) return null;
      return await res.json();
    } catch (e) { return null; }
  },

  logAdminActivity: async (userName: string, action: string, details: string) => {
    try {
      await fetch(`${API_URL}/admin/activity`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userName, action, details }),
      });
    } catch (e) {}
  }
};
