export const translations = {
  en: {
    nav: {
      shop: 'Shop All',
      men: 'Men',
      women: 'Women',
      journal: 'Journal',
      story: 'Story',
      account: 'Account',
      search: 'Search',
    },
    hero: {
      subtitle: 'Introducing The New Collection',
      title: 'Scent of',
      titleAccent: 'Elegance',
      cta: 'Discover Now',
    },
    auth: {
      welcome: 'Welcome Back',
      subtitle: 'Please sign in to access your account.',
      email: 'Email',
      password: 'Password',
      signIn: 'Sign In',
      noAccount: 'New to Aura?',
      register: 'Create an Account',
      join: 'Join the Aura community.',
      name: 'Full Name',
      signUp: 'Create Account',
      haveAccount: 'Already have an account?',
    }
  },
  fr: {
    nav: {
      shop: 'Boutique',
      men: 'Hommes',
      women: 'Femmes',
      journal: 'Journal',
      story: 'Histoire',
      account: 'Compte',
      search: 'Recherche',
    },
    hero: {
      subtitle: 'Présentation de la nouvelle collection',
      title: 'Parfum',
      titleAccent: 'd\'Élégance',
      cta: 'Découvrir',
    },
    auth: {
      welcome: 'Bon retour',
      subtitle: 'Veuillez vous connecter pour accéder à votre compte.',
      email: 'Email',
      password: 'Mot de passe',
      signIn: 'Se connecter',
      noAccount: 'Nouveau chez Aura ?',
      register: 'Créer un compte',
      join: 'Rejoignez la communauté Aura.',
      name: 'Nom complet',
      signUp: 'S\'inscrire',
      haveAccount: 'Vous avez déjà un compte ?',
    }
  },
  ar: {
    nav: {
      shop: 'تسوق الكل',
      men: 'رجال',
      women: 'نساء',
      journal: 'المجلة',
      story: 'قصتنا',
      account: 'حسابي',
      search: 'بحث',
    },
    hero: {
      subtitle: 'نقدم لكم المجموعة الجديدة',
      title: 'عطر',
      titleAccent: 'الأناقة',
      cta: 'اكتشف الآن',
    },
    auth: {
      welcome: 'مرحبًا بعودتك',
      subtitle: 'الرجاء تسجيل الدخول للوصول إلى حسابك.',
      email: 'البريد الإلكتروني',
      password: 'كلمة المرور',
      signIn: 'تسجيل الدخول',
      noAccount: 'جديد في أورا؟',
      register: 'إنشاء حساب',
      join: 'انضم إلى مجتمع أورا.',
      name: 'الاسم الكامل',
      signUp: 'إنشاء حساب',
      haveAccount: 'لديك حساب بالفعل؟',
    }
  }
};

export type Language = 'en' | 'fr' | 'ar';