
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User, AuthContextType } from '../types';
import { GoogleGenAI } from '@google/genai';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Internal Mock DB helper for persistent frontend-only testing
const getLocalUsers = (): any[] => {
  if (typeof window === 'undefined') return [];
  try {
    const data = localStorage.getItem('luzaan_users_db');
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error parsing user database:", error);
    // Reset corrupted DB to prevent persistent login failures
    localStorage.removeItem('luzaan_users_db');
    return [];
  }
};

const saveLocalUser = (user: any, password?: string) => {
  const users = getLocalUsers();
  // Ensure we compare emails safely
  const existingIndex = users.findIndex(u => u.email.toLowerCase().trim() === user.email.toLowerCase().trim());
  
  const userDataWithCreds = { 
    ...user, 
    password: password || 'Luzaan123!',
    verifiedAt: new Date().toISOString()
  };
  
  if (existingIndex !== -1) {
    users[existingIndex] = userDataWithCreds;
  } else {
    users.push(userDataWithCreds);
  }
  
  localStorage.setItem('luzaan_users_db', JSON.stringify(users));
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('luzaan_user');
    const token = localStorage.getItem('luzaan_token');
    if (savedUser && token) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        localStorage.removeItem('luzaan_user');
        localStorage.removeItem('luzaan_token');
      }
    }
  }, []);

  const saveUserToStorage = (userData: User | null, token?: string) => {
    setUser(userData);
    if (userData) {
      localStorage.setItem('luzaan_user', JSON.stringify(userData));
      if (token) localStorage.setItem('luzaan_token', token);
    } else {
      localStorage.removeItem('luzaan_user');
      localStorage.removeItem('luzaan_token');
    }
  };

  const login = async (email: string, password?: string): Promise<User | null> => {
    setIsLoading(true);
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        setIsLoading(false);
        const normalizedEmail = email.toLowerCase().trim();
        
        // 1. Admin Master Protocol
        if (normalizedEmail === 'admin@luzaan.com') {
           if (password === 'Luzaan_2003') {
               const admin: User = {
                  id: 'admin_001',
                  name: 'Administrator',
                  email: 'admin@luzaan.com',
                  role: 'admin',
                  joinDate: new Date().toISOString().split('T')[0],
                  region: 'Global'
               };
               saveUserToStorage(admin, 'master_gate_token_2025');
               setShowWelcomeModal(true);
               resolve(admin);
               return;
           } else {
               // Admin exists but wrong password
               reject(new Error("Invalid Administrative Credentials"));
               return;
           }
        }

        // 2. Archive Database Validation (Mock DB)
        const localUsers = getLocalUsers();
        const found = localUsers.find(u => u.email.toLowerCase() === normalizedEmail);
        
        if (!found) {
            // User not found
            reject(new Error("No account found with this email address."));
            return;
        }

        // Strictly check password
        if (found.password === password) {
            const { password: _, ...userSafe } = found;
            saveUserToStorage(userSafe, 'ritual_session_' + Math.random().toString(36).substr(2, 10));
            setShowWelcomeModal(true);
            resolve(userSafe);
        } else {
            // Found but wrong password
            reject(new Error("Incorrect password. Please try again."));
        }
      }, 1500);
    });
  };

  const register = async (name: string, email: string, region?: string, password?: string): Promise<User> => {
    setIsLoading(true);
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        setIsLoading(false);
        const normalizedEmail = email.toLowerCase().trim();
        
        // Final structural verification
        if (!normalizedEmail.includes('@') || !password || password.length < 6 || name.trim().split(' ').length < 2) {
           reject(new Error("Architect Security: Protocol requirements not met. Please check all information."));
           return;
        }

        const localUsers = getLocalUsers();
        if (localUsers.some(u => u.email.toLowerCase() === normalizedEmail)) {
          reject(new Error("Security Alert: Identity already archived in our system."));
          return;
        }

        const newUser: User = {
          id: 'luzaan_u_' + Math.random().toString(36).substr(2, 9),
          name: name.trim(),
          email: normalizedEmail,
          role: 'user',
          joinDate: new Date().toISOString().split('T')[0],
          region: region || 'United States',
          isSubscribed: false,
          addresses: [],
          ordersCount: 0,
          totalSpent: 0
        };

        saveLocalUser(newUser, password);
        saveUserToStorage(newUser, 'registration_session_' + Date.now());
        setShowWelcomeModal(true);
        resolve(newUser);
      }, 2200);
    });
  };

  const updateUser = async (data: Partial<User>) => {
    if (user) {
        const updatedUser = { ...user, ...data };
        // Update Session
        saveUserToStorage(updatedUser, localStorage.getItem('luzaan_token') || undefined);
        
        // Update "Database"
        const db = getLocalUsers();
        const index = db.findIndex(u => u.id === user.id);
        if (index !== -1) {
            db[index] = { ...db[index], ...data };
            localStorage.setItem('luzaan_users_db', JSON.stringify(db));
        }
    }
  };

  // Simulate Password Reset Request with AI Enhancement
  const requestPasswordReset = async (email: string): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true);
    const users = getLocalUsers();
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    const name = user?.name || 'Guest';

    try {
        // Attempt to get key from env var first, then from local storage settings (configured via Admin)
        let apiKey = process.env.API_KEY;
        
        if (!apiKey) {
            const storedSettings = localStorage.getItem('luzaan_settings');
            if (storedSettings) {
                try {
                    const parsed = JSON.parse(storedSettings);
                    if (parsed.geminiApiKey) {
                        apiKey = parsed.geminiApiKey;
                    }
                } catch(e) { console.error("Error reading stored API key"); }
            }
        }

        if (!apiKey) throw new Error("No API Key");

        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: `Write a very short, elegant, and mysterious 1-sentence notification for a luxury perfume brand called 'Luzaan'. Tell the user '${name}' that their 'Access Ritual' (password reset) scroll has been dispatched. Use words like 'archive', 'key', 'protocol', 'essence'. Do not mention 'email' directly, call it a 'dispatch' or 'scroll'.`,
        });
        
        setIsLoading(false);
        return { success: true, message: response.text || "The Archivist has dispatched a recovery scroll to your coordinates." };
    } catch (error) {
        // Fallback if AI fails or no key is present
        setIsLoading(false);
        return { success: true, message: "A secure recovery key has been dispatched to your provided coordinates." };
    }
  };

  // Simulate Confirm Password Reset
  const confirmPasswordReset = async (email: string, newPassword: string): Promise<boolean> => {
      setIsLoading(true);
      return new Promise((resolve) => {
          setTimeout(() => {
              const users = getLocalUsers();
              const index = users.findIndex(u => u.email.toLowerCase() === email.toLowerCase());
              
              if (index !== -1) {
                  // Update password in mock DB
                  users[index].password = newPassword;
                  localStorage.setItem('luzaan_users_db', JSON.stringify(users));
                  setIsLoading(false);
                  resolve(true);
              } else {
                  setIsLoading(false);
                  resolve(false);
              }
          }, 1500);
      });
  };

  const loginWithGoogle = async (): Promise<User> => {
    setIsLoading(true);
    return new Promise<User>((resolve) => {
      setTimeout(() => {
        const googleUser: User = {
          id: 'g_luzaan_' + Date.now(),
          name: 'Business Client',
          email: 'client@luzaan.com',
          role: 'user',
          photoURL: 'https://ui-avatars.com/api/?name=Business+Client&background=2B1E16&color=CFA75E',
          provider: 'google',
          joinDate: new Date().toISOString().split('T')[0],
          region: 'United States'
        };
        saveLocalUser(googleUser, 'oauth_reserved');
        saveUserToStorage(googleUser, 'google_session_authenticated');
        setShowWelcomeModal(true);
        setIsLoading(false);
        resolve(googleUser);
      }, 1000);
    });
  };

  const logout = () => {
    saveUserToStorage(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        loginWithGoogle,
        register,
        updateUser,
        requestPasswordReset,
        confirmPasswordReset,
        logout,
        isAuthenticated: !!user,
        isLoading,
        showWelcomeModal,
        setShowWelcomeModal
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
