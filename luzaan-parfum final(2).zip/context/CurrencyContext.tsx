
import React, { createContext, useContext, useState, ReactNode } from 'react';

type Currency = 'USD' | 'EUR' | 'INR' | 'GBP' | 'CAD' | 'AUD';
type Country = 'United States' | 'United Kingdom' | 'Europe' | 'India' | 'Canada' | 'Australia';

interface CurrencyContextType {
  currency: Currency;
  country: Country;
  setCountry: (c: Country) => void;
  setCurrency: (c: Currency) => void;
  formatPrice: (price: number) => string;
  symbol: string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};

const RATES = {
  USD: 1,
  EUR: 0.92,
  INR: 83.50,
  GBP: 0.79,
  CAD: 1.36,
  AUD: 1.54
};

const SYMBOLS = {
  USD: '$',
  EUR: '€',
  INR: '₹',
  GBP: '£',
  CAD: 'C$',
  AUD: 'A$'
};

const COUNTRY_CURRENCY_MAP: Record<Country, Currency> = {
  'United States': 'USD',
  'United Kingdom': 'GBP',
  'Europe': 'EUR',
  'India': 'INR',
  'Canada': 'CAD',
  'Australia': 'AUD'
};

export const CurrencyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Defaulting to India / INR as requested
  const [currency, setCurrencyState] = useState<Currency>('INR');
  const [country, setCountryState] = useState<Country>('India');

  const setCountry = (c: Country) => {
    setCountryState(c);
    setCurrencyState(COUNTRY_CURRENCY_MAP[c]);
  };

  const setCurrency = (c: Currency) => {
    setCurrencyState(c);
  };

  const formatPrice = (priceInUSD: number) => {
    const rate = RATES[currency];
    const converted = priceInUSD * rate;
    
    const localeMap = {
        USD: 'en-US',
        EUR: 'de-DE',
        INR: 'en-IN',
        GBP: 'en-GB',
        CAD: 'en-CA',
        AUD: 'en-AU'
    };

    return new Intl.NumberFormat(localeMap[currency], {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0, // Removed decimals for cleaner look in Rupee/high denominations
      maximumFractionDigits: 2,
    }).format(converted);
  };

  return (
    <CurrencyContext.Provider value={{ currency, country, setCountry, setCurrency, formatPrice, symbol: SYMBOLS[currency] }}>
      {children}
    </CurrencyContext.Provider>
  );
};
