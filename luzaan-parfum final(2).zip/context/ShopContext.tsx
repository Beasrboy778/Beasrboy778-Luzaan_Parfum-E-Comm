
import React, { createContext, useContext, useState, ReactNode, useMemo, useEffect } from 'react';
import { CartItem, Product, ShopContextType, Order, User, Review, SiteContent, AdminActivity, BlogPost, StoreSettings, Category, SeoSettings, ShippingConfig, ContactMessage, Coupon, NewsletterConfig, DesignSettings, BlogComment, SecuritySettings } from '../types';
import { PRODUCTS, MOCK_ORDERS, BLOG_POSTS, CATEGORIES } from '../services/mockData';
import { api } from '../services/api';

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) throw new Error('useShop must be used within a ShopProvider');
  return context;
};

const INITIAL_COUPONS: Coupon[] = [
  { id: 'c1', code: 'LUZAAN15', discountType: 'percent', value: 15, minOrderValue: 100, expiryDate: '2025-12-31', status: 'active', usageCount: 42 },
  { id: 'c2', code: 'WELCOME-LUZAAN', discountType: 'fixed', value: 25, minOrderValue: 150, expiryDate: '2025-06-30', status: 'active', usageCount: 12 },
  { id: 'c3', code: 'VIP_ONYX', discountType: 'percent', value: 30, minOrderValue: 500, expiryDate: '2026-01-01', status: 'active', usageCount: 5 }
];

const INITIAL_DESIGN: DesignSettings = {
  // Global
  siteLogo: '',
  siteFavicon: '',
  siteGrainIntensity: 0.02,
  announcementBarText: "Complimentary Shipping on Global Orders Over $200",
  announcementBarActive: true,
  announcementBarLink: '/shop',

  // Home
  heroVideo: "", 
  heroDescription: "Experience the essence of luxury with Luzaan Parfum, crafted with 100% pure organic oils and aged for 180 days to reach olfactory perfection.",
  heroBtnText: "Shop Collection",
  heroSecondaryBtnText: "Explore Luzaan Privé",
  heroSecondaryBtnLink: "/discovery",
  heroSubtitle: "Handcrafted in limited quantities for the modern connoisseur.",
  heroOverlayOpacity: 0.2,
  heroOverlayColor: '#F5F2EF',
  heroShowAnimation: true,
  heroShowSpotlight: true,
  heroSpotlightColor: 'rgba(207, 167, 94, 0.15)',
  marqueeText: "Handmade in small batches • 100% Pure Essential Oils • No synthetic chemicals • Luzaan Parfum •",
  philosophyImage: "https://images.unsplash.com/photo-1615529452077-cfc99480a716?auto=format&fit=crop&w=1200&q=80",
  footerImage: '',
  museImage: 'https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=1200&q=80',
  homeJournalImage: 'https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?auto=format&fit=crop&w=1600&q=80',
  
  // Default Hero Slides
  heroSlides: [
    { id: '1', line1: "Olfactory", line2: "Art.", quote: "\"We create scents that last.\"", image: "" },
    { id: '2', line1: "Sensory", line2: "Ritual.", quote: "\"Fragrance is the language of memory.\"", image: "" },
    { id: '3', line1: "Timeless", line2: "Essence.", quote: "\"Capturing the spirit of nature.\"", image: "" }
  ],
  featureNewImage: '',
  featureBestSellerImage: '',

  // Home Section Texts
  homeSection1Title: "The Core Essence.",
  homeSection1Subtitle: "\"A selection of olfactory masterpieces defined by rare ingredients and timeless allure. Explore the duality of innovation and tradition in every drop.\"",
  homeSection2Title: "New Arrivals.",
  homeSection2Subtitle: "\"Discover the latest additions to our collection.\"",
  homeSection3Title: "Signature Scents.",
  homeSection3Subtitle: "\"Our most loved scents from around the world.\"",
  homeSection4Title: "Limited Edition.",
  homeSection4Subtitle: "\"Exclusive perfumes made in very small batches.\"",
  homeMuseTitle: "Consult The Muse",
  homeMuseSubtitle: "\"Tell me about a memory or feeling, and I will help you find your perfect scent.\"",

  // Pages
  shopBannerImage: '',
  shopTitle: 'All Scents',
  aboutHeroImage: 'https://images.unsplash.com/photo-1555529733-0e670560f7e1?auto=format&fit=crop&w=1600&q=80',
  aboutTitle: 'Our Story',
  aboutText: "Luzaan started with a vision to redefine perfumery. We use old ways and new ideas to make smells that people love and remember. We are not in a rush. Every bottle stays in our shop for 6 months until it is perfect. We want our perfumes to be a part of who you are.",
  contactBgImage: '',
  blogHeaderImage: '',

  // Contact Defaults
  contactTitle: 'Get in Touch',
  contactSubtitle: '"Scent is the most intense form of memory." Allow us to help you find yours.',
  contactSection1Title: 'Flagship Atelier',
  contactSection2Title: 'Digital Concierge',
  contactSection3Title: 'Operating Hours'
};

const INITIAL_CONTENT: SiteContent = {
  shipping: `Shipping Policy\n\nWe ship worldwide via carbon-neutral couriers. Free shipping on orders over $200. Orders usually arrive in 5-7 business days.`,
  privacy: `Privacy Policy\n\nYour privacy is our utmost priority. We use advanced encryption to protect your data.`,
  terms: `Terms of Service\n\nWelcome to Luzaan. By engaging with our site, you agree to our artistic governance rules.`,
  newsletter: {
    enabled: true,
    title: 'Join Luzaan Privé',
    subtitle: 'Register for exclusive access to limited-edition drops and a 15% honorarium on your first purchase.',
    offerText: 'Private 15% Access',
    buttonText: 'Acquire Access',
    code: 'LUZAAN15',
    image: 'https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=800&q=80'
  }
};

const INITIAL_SETTINGS: StoreSettings = {
  storeName: 'Luzaan',
  supportEmail: 'concierge@luzaan.com',
  currency: 'USD',
  taxRate: 5,
  enableReviews: true,
  enableGuestCheckout: true,
  stripePublicKey: '',
  geminiApiKey: '',
  emailProviderApiKey: '',
  contactDetails: {
    addressLine1: '123 Perfume Lane, Le Marais',
    addressLine2: 'Paris, France 75001',
    phone: '+33 1 23 45 67 89',
    hours: 'Mon-Fri: 9am - 6pm CET',
    hoursSat: 'Sat: By Appointment Only'
  },
  socialLinks: { instagram: '', facebook: '', twitter: '' }
};

const INITIAL_SEO: SeoSettings = {
  metaTitle: 'Luzaan | Haute Parfumerie & Luxury Attars',
  metaDescription: 'Artisanal perfumes made with 100% pure oils and aged to perfection for the modern connoisseur.',
  keywords: ['natural perfume', 'handmade fragrance', 'luxury scent', 'organic oud'],
  ogImage: '',
  twitterHandle: '@luzaanparfum',
  robotsTxt: 'User-agent: *\nAllow: /',
  targetKeywords: [
      { keyword: "luxury oud perfume", volume: 12000, difficulty: 45, position: 12, intent: 'Transactional' },
      { keyword: "long lasting attar", volume: 8500, difficulty: 30, position: 4, intent: 'Transactional' },
      { keyword: "best perfume for men india", volume: 45000, difficulty: 80, position: 22, intent: 'Informational' },
  ],
  customMetaTags: [],
  aeoSettings: {
      brandAlternateNames: ["Luzaan Scents", "Luzaan India"],
      founderName: "The Alchemist",
      foundingDate: "2003-01-01",
      priceRange: "$$$",
      areaServed: "Global",
      knowsAbout: ["Perfumery", "Distillation", "Oud", "Natural Musk"]
  }
};

const INITIAL_SHIPPING: ShippingConfig = {
  freeShippingThreshold: 200,
  enableInternational: true,
  carriers: { fedex: true, dhl: true, ups: false, usps: false },
  zones: [
    { id: '1', name: 'Standard Global', rate: 15, deliveryTime: '5-7 Business Days' },
    { id: '2', name: 'Concierge Priority', rate: 35, deliveryTime: '2-3 Business Days', isExpress: true }
  ]
};

// ... (Rest of the logic remains the same, just keeping the structure for context)
const getStorageItem = (key: string, fallback: any) => {
  if (typeof window === 'undefined') return fallback;
  try {
    const item = localStorage.getItem(key);
    if (!item) return fallback;
    const parsed = JSON.parse(item);
    if (Array.isArray(fallback)) return Array.isArray(parsed) ? parsed : fallback;
    if (typeof fallback === 'object' && fallback !== null) return { ...fallback, ...parsed };
    return parsed;
  } catch (error) {
    return fallback;
  }
};

// GSC Data Generation
const generateGSCData = () => {
    return {
        clicks: 12450,
        impressions: 450000,
        ctr: 2.8,
        position: 12.4,
        queries: [
            { query: 'long lasting oud perfume', clicks: 850, impressions: 12000, position: 3.2 },
            { query: 'best attar for men india', clicks: 620, impressions: 8500, position: 4.1 },
            { query: 'luxury perfume online', clicks: 410, impressions: 15000, position: 8.5 },
            { query: 'midnight wood perfume', clicks: 390, impressions: 4000, position: 1.1 },
        ],
        pages: [
            { url: 'https://luzaan.com/product/m1', clicks: 1200, impressions: 25000, position: 5.2 },
            { url: 'https://luzaan.com/shop', clicks: 950, impressions: 30000, position: 9.1 },
        ]
    };
};

export const ShopProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => getStorageItem('luzaan_products', PRODUCTS));
  const [cart, setCart] = useState<CartItem[]>(() => getStorageItem('luzaan_cart', []));
  const [wishlist, setWishlist] = useState<Product[]>(() => getStorageItem('luzaan_wishlist', []));
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(() => getStorageItem('luzaan_blog_posts', BLOG_POSTS));
  const [blogComments, setBlogComments] = useState<BlogComment[]>(() => getStorageItem('luzaan_blog_comments', []));
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(() => getStorageItem('luzaan_settings', INITIAL_SETTINGS));
  const [designSettings, setDesignSettings] = useState<DesignSettings>(() => getStorageItem('luzaan_design', INITIAL_DESIGN));
  const [categories, setCategories] = useState<Category[]>(() => getStorageItem('luzaan_categories', CATEGORIES));
  const [siteContent, setSiteContent] = useState<SiteContent>(() => getStorageItem('luzaan_content', INITIAL_CONTENT));
  const [seoSettings, setSeoSettings] = useState<SeoSettings>(() => getStorageItem('luzaan_seo', INITIAL_SEO));
  const [shippingSettings, setShippingSettings] = useState<ShippingConfig>(() => getStorageItem('luzaan_shipping', INITIAL_SHIPPING));
  const [coupons, setCoupons] = useState<Coupon[]>(() => getStorageItem('luzaan_coupons', INITIAL_COUPONS));
  const [reviews, setReviews] = useState<Review[]>([]); // Reviews now live in DB
  const [adminOrders, setAdminOrders] = useState<Order[]>(() => getStorageItem('luzaan_orders', MOCK_ORDERS));
  const [adminCustomers, setAdminCustomers] = useState<User[]>(() => getStorageItem('luzaan_customers', []));
  const [adminActivityLogs, setAdminActivityLogs] = useState<AdminActivity[]>([]);
  const [adminMessages, setAdminMessages] = useState<ContactMessage[]>(() => getStorageItem('luzaan_messages', []));
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>(() => getStorageItem('luzaan_security', { twoFactor: false }));
  const [blockedIPs, setBlockedIPs] = useState<string[]>(() => getStorageItem('luzaan_blocked_ips', []));
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [gscData, setGscData] = useState(generateGSCData());

  // ... (Effects for storage and initData) ... 
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'luzaan_products') {
        const updated = JSON.parse(e.newValue || '[]');
        setProducts(updated);
      }
      if (e.key === 'luzaan_design') setDesignSettings(JSON.parse(e.newValue || '{}'));
      if (e.key === 'luzaan_settings') setStoreSettings(JSON.parse(e.newValue || '{}'));
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  useEffect(() => {
    const initData = async () => {
      try {
        const p = await api.getProducts();
        if (p && Array.isArray(p)) setProducts(p);
        const c = await api.getCategories();
        if (c && Array.isArray(c)) setCategories(c);
        const r = await api.getAllReviews();
        if (r && Array.isArray(r)) setReviews(r);
      } catch (err) {
        console.warn("API Offline - Local storage enabled.");
      }
    };
    initData();
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('luzaan_products', JSON.stringify(products));
      localStorage.setItem('luzaan_cart', JSON.stringify(cart));
      localStorage.setItem('luzaan_wishlist', JSON.stringify(wishlist));
      localStorage.setItem('luzaan_blog_posts', JSON.stringify(blogPosts));
      localStorage.setItem('luzaan_blog_comments', JSON.stringify(blogComments));
      localStorage.setItem('luzaan_settings', JSON.stringify(storeSettings));
      localStorage.setItem('luzaan_design', JSON.stringify(designSettings));
      localStorage.setItem('luzaan_content', JSON.stringify(siteContent));
      localStorage.setItem('luzaan_seo', JSON.stringify(seoSettings));
      localStorage.setItem('luzaan_shipping', JSON.stringify(shippingSettings));
      localStorage.setItem('luzaan_orders', JSON.stringify(adminOrders));
      localStorage.setItem('luzaan_customers', JSON.stringify(adminCustomers));
      localStorage.setItem('luzaan_messages', JSON.stringify(adminMessages));
      localStorage.setItem('luzaan_coupons', JSON.stringify(coupons));
      localStorage.setItem('luzaan_categories', JSON.stringify(categories));
      localStorage.setItem('luzaan_security', JSON.stringify(securitySettings));
      localStorage.setItem('luzaan_blocked_ips', JSON.stringify(blockedIPs));
    } catch (e) {
      console.error("Local Storage Quota Exceeded! Some data may not persist.", e);
    }
  }, [products, cart, wishlist, blogPosts, blogComments, storeSettings, designSettings, siteContent, seoSettings, shippingSettings, adminOrders, adminCustomers, adminMessages, coupons, categories, securitySettings, blockedIPs]);

  // ... (Rest of helper functions: addToCart, etc.) ...
  const addToCart = (product: Product, quantity: number = 1, openDrawer: boolean = true, variantSize?: string) => {
    const size = variantSize || product.sizes?.[0] || product.size;
    const cartItemId = `${product.id}-${size}`;
    setCart(prev => {
      const existing = prev.find(i => i.cartItemId === cartItemId);
      if (existing) return prev.map(i => i.cartItemId === cartItemId ? { ...i, quantity: i.quantity + quantity } : i);
      return [...prev, { ...product, size, quantity, cartItemId }];
    });
    if (openDrawer) {
        setIsSearchOpen(false); 
        setIsCartOpen(true);
    }
  };

  const removeFromCart = (cartItemId: string) => setCart(prev => prev.filter(i => i.cartItemId !== cartItemId));
  const updateQuantity = (cartItemId: string, q: number) => setCart(prev => prev.map(i => i.cartItemId === cartItemId ? { ...i, quantity: Math.max(1, q) } : i));
  const toggleCart = () => { if (!isCartOpen) setIsSearchOpen(false); setIsCartOpen(!isCartOpen); };
  const toggleSearch = () => { if (!isSearchOpen) setIsCartOpen(false); setIsSearchOpen(!isSearchOpen); };
  const clearCart = () => setCart([]);
  const addToWishlist = (p: Product) => setWishlist(prev => prev.find(i => i.id === p.id) ? prev : [...prev, p]);
  const removeFromWishlist = (id: string) => setWishlist(prev => prev.filter(p => p.id !== id));
  const isInWishlist = (id: string) => wishlist.some(p => p.id === id);
  const cartTotal = useMemo(() => cart.reduce((t, i) => t + i.price * i.quantity, 0), [cart]);
  const cartCount = useMemo(() => cart.reduce((c, i) => c + i.quantity, 0), [cart]);

  const addProduct = async (p: Product) => { setProducts(prev => [...prev, p]); api.createProduct(p); };
  const updateProduct = async (p: Product) => { setProducts(prev => prev.map(item => item.id === p.id ? p : item)); api.updateProduct(p); };
  const deleteProduct = async (id: string) => { setProducts(prev => prev.filter(p => p.id !== id)); api.deleteProduct(id); };
  const bulkUpdateStock = async (ids: string[], stock: number) => { setProducts(prev => prev.map(p => ids.includes(p.id) ? { ...p, stock } : p)); };
  
  const addCategory = async (c: Category) => { setCategories(prev => [...prev, c]); api.createCategory(c); };
  const updateCategory = async (c: Category) => { setCategories(prev => prev.map(cat => cat.id === c.id ? c : cat)); };
  const deleteCategory = async (id: string) => { setCategories(prev => prev.filter(c => c.id !== id)); api.deleteCategory(id); };

  const updateStoreSettings = (s: Partial<StoreSettings>) => setStoreSettings(prev => ({ ...prev, ...s }));
  const updateDesignSettings = (s: Partial<DesignSettings>) => setDesignSettings(prev => ({ ...prev, ...s }));
  const updateSeoSettings = (s: Partial<SeoSettings>) => setSeoSettings(prev => ({ ...prev, ...s }));
  const updateShippingSettings = (s: Partial<ShippingConfig>) => setShippingSettings(prev => ({ ...prev, ...s }));
  const updateSiteContent = (section: keyof SiteContent, content: any) => setSiteContent(prev => ({ ...prev, [section]: content }));
  const addOrder = async (order: Order) => { setAdminOrders(prev => [order, ...prev]); api.createOrder(order); return true; };
  const addReview = async (r: Review) => { setReviews(prev => [r, ...prev]); await api.createReview(r); };
  const updateReviewStatus = async (id: string, s: Review['status']) => { setReviews(prev => prev.map(r => r.id === id ? { ...r, status: s } : r)); await api.updateReviewStatus(id, s); };
  const getProductReviews = (id: string) => reviews.filter(r => r.productId === id);
  const addBlogComment = (c: BlogComment) => setBlogComments(prev => [c, ...prev]);
  const updateBlogCommentStatus = (id: string, s: BlogComment['status']) => setBlogComments(prev => prev.map(c => c.id === id ? { ...c, status: s } : c));
  const deleteBlogComment = (id: string) => setBlogComments(prev => prev.filter(c => c.id !== id));
  
  const addCustomer = (u: User) => { if (u.role === 'admin' || u.email.toLowerCase() === 'admin@luzaan.com') return; setAdminCustomers(prev => { if (prev.find(c => c.email === u.email)) return prev; return [...prev, u]; }); };
  const updateCustomer = (u: User) => setAdminCustomers(prev => prev.map(user => user.id === u.id ? u : user));
  const updateOrderStatus = (id: string, s: Order['status'], trackingNumber?: string) => { setAdminOrders(prev => prev.map(o => o.id === id ? { ...o, status: s, trackingNumber: trackingNumber || o.trackingNumber } : o)); api.updateOrderStatus(id, s); };
  const logAdminActivity = (a: string, d: string) => setAdminActivityLogs(prev => [{ id: Date.now().toString(), userName: 'Admin', action: a, details: d, ipAddress: '127.0.0.1', date: new Date().toLocaleString() }, ...prev]);
  const sendContactMessage = async (m: any) => { setAdminMessages(prev => [{ ...m, id: Date.now().toString(), date: new Date().toLocaleString(), status: 'unread' }, ...prev]); return true; };
  const markMessageAsRead = (id: string) => setAdminMessages(prev => prev.map(m => m.id === id ? { ...m, status: 'read' } : m));
  const addCoupon = (c: Coupon) => setCoupons(prev => [...prev, c]);
  const updateCoupon = (c: Coupon) => setCoupons(prev => prev.map(item => item.id === c.id ? c : item));
  const deleteCoupon = (id: string) => setCoupons(prev => prev.filter(c => c.id !== id));
  const validateCoupon = (code: string, total: number) => { const c = coupons.find(i => i.code.toUpperCase() === code.toUpperCase() && i.status === 'active'); if (!c) return { isValid: false, discount: 0 }; return { isValid: true, discount: c.discountType === 'percent' ? total * (c.value / 100) : c.value }; };
  const claimPendingCart = () => {};
  const addBlogPost = (p: BlogPost) => setBlogPosts(prev => [...prev, p]);
  const updateBlogPost = (p: BlogPost) => setBlogPosts(prev => prev.map(item => item.id === p.id ? p : item));
  const deleteBlogPost = (id: string) => setBlogPosts(prev => prev.filter(p => p.id !== id));
  const updateSecuritySettings = (s: Partial<SecuritySettings>) => setSecuritySettings(prev => ({ ...prev, ...s }));
  const addBlockedIP = (ip: string) => setBlockedIPs(prev => prev.includes(ip) ? prev : [...prev, ip]);
  const removeBlockedIP = (ip: string) => setBlockedIPs(prev => prev.filter(i => i !== ip));
  const restoreSystem = async (data: any): Promise<boolean> => { try { if (data.products) setProducts(data.products); if (data.orders) setAdminOrders(data.orders); if (data.customers) setAdminCustomers(data.customers); if (data.settings) setStoreSettings(data.settings); if (data.design) setDesignSettings(data.design); if (data.content) setSiteContent(data.content); if (data.shipping) setShippingSettings(data.shipping); if (data.blogPosts) setBlogPosts(data.blogPosts); if (data.coupons) setCoupons(data.coupons); if (data.reviews) setReviews(data.reviews); if (data.categories) setCategories(data.categories); if (data.messages) setAdminMessages(data.messages); if (data.security) setSecuritySettings(data.security); return true; } catch (e) { console.error("Restore Failed:", e); return false; } };

  return (
    <ShopContext.Provider value={{
      products, addProduct, updateProduct, deleteProduct, bulkUpdateStock,
      categories, addCategory, deleteCategory, updateCategory,
      cart, wishlist, isCartOpen, isSearchOpen,
      addToCart, removeFromCart, updateQuantity, toggleCart, toggleSearch,
      addToWishlist, removeFromWishlist, isInWishlist, clearCart,
      cartTotal, cartCount, addOrder, reviews, addReview, updateReviewStatus, getProductReviews,
      blogComments, addBlogComment, updateBlogCommentStatus, deleteBlogComment,
      adminProducts: products, adminOrders, adminCustomers, addCustomer, updateCustomer, updateOrderStatus,
      adminActivityLogs, logAdminActivity, adminMessages, sendContactMessage, markMessageAsRead,
      coupons, addCoupon, updateCoupon, deleteCoupon, validateCoupon, claimPendingCart,
      storeSettings, updateStoreSettings, designSettings, updateDesignSettings,
      seoSettings, updateSeoSettings, shippingSettings, updateShippingSettings,
      blogPosts, addBlogPost, updateBlogPost, deleteBlogPost, siteContent, updateSiteContent,
      securitySettings, updateSecuritySettings, blockedIPs, addBlockedIP, removeBlockedIP,
      restoreSystem, gscData
    }}>
      {children}
    </ShopContext.Provider>
  );
};
